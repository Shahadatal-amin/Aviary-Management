import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  GitFork, 
  Heart, 
  ShieldAlert, 
  Weight, 
  Calendar, 
  Tag, 
  User, 
  FileText, 
  Edit3, 
  Trash2, 
  Check, 
  Plus,
  ArrowRight,
  Sparkles,
  DollarSign
} from 'lucide-react';
import { Bird, BirdSex, BirdStatus, DnaStatus, LovebirdSpecies } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

interface BirdProfileModalProps {
  birdId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: string) => void;
  onSelectBirdForPedigree: (birdId: string) => void;
}

const STATUS_OPTIONS: BirdStatus[] = [
  'Home Bred',
  'Purchased',
  'Loan',
  'Sold',
  'Breeding Pair',
  'Quarantine',
  'Deceased',
];

const DNA_OPTIONS: DnaStatus[] = [
  'DNA Certified Male',
  'DNA Certified Female',
  'Sex-Linked Confirmed',
  'Breeding Proven',
  'Pending / Unknown',
];

const SPECIES_OPTIONS: LovebirdSpecies[] = [
  'Agapornis roseicollis (Peach-faced)',
  'Agapornis fischeri (Fischer\'s)',
  'Agapornis personatus (Masked)',
  'Agapornis lilianae (Nyasa)',
  'Agapornis taranta (Abyssinian)',
];

export const BirdProfileModal: React.FC<BirdProfileModalProps> = ({
  birdId,
  isOpen,
  onClose,
  onNavigateTab,
  onSelectBirdForPedigree,
}) => {
  const { 
    birds, 
    pairs, 
    clutches, 
    healthRecords, 
    updateBird, 
    deleteBird, 
    addHealthRecord,
    config 
  } = useAviary();

  const bird = birds.find(b => b.id === birdId);

  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'pedigree' | 'offspring' | 'health'>('details');

  // Edit form state
  const [formData, setFormData] = useState<Partial<Bird>>({});
  const [selectedParentPairId, setSelectedParentPairId] = useState<string>('');
  const [newHealthTitle, setNewHealthTitle] = useState('');
  const [newHealthType, setNewHealthType] = useState<'Deworming' | 'Vaccination' | 'Weight Check' | 'Vet Visit'>('Weight Check');
  const [newHealthWeight, setNewHealthWeight] = useState(50);
  const [newHealthDate, setNewHealthDate] = useState(new Date().toISOString().split('T')[0]);

  // Sync state when bird opens
  React.useEffect(() => {
    if (bird) {
      setFormData({
        name: bird.name,
        ringNumber: bird.ringNumber,
        species: bird.species,
        sex: bird.sex,
        dnaStatus: bird.dnaStatus,
        status: bird.status,
        mutationDescription: bird.mutationDescription,
        hatchDate: bird.hatchDate,
        cageNumber: bird.cageNumber,
        photoUrl: bird.photoUrl,
        fatherRing: bird.fatherRing,
        motherRing: bird.motherRing,
        weightGrams: bird.weightGrams,
        breederName: bird.breederName,
        purchasePrice: bird.purchasePrice,
        soldPrice: bird.soldPrice,
        soldTo: bird.soldTo,
        notes: bird.notes,
      });

      // Find if parents match an existing pair
      const matchedPair = pairs.find(p => {
        const cock = birds.find(b => b.id === p.cockBirdId);
        const hen = birds.find(b => b.id === p.henBirdId);
        return cock?.ringNumber === bird.fatherRing && hen?.ringNumber === bird.motherRing;
      });
      if (matchedPair) setSelectedParentPairId(matchedPair.id);
    }
  }, [bird, pairs, birds]);

  if (!isOpen || !bird) return null;

  // Handle local photo upload (convert file to data URL)
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const result = evt.target?.result as string;
      setFormData(prev => ({ ...prev, photoUrl: result }));
      updateBird(bird.id, { photoUrl: result });
    };
    reader.readAsDataURL(file);
  };

  // Link directly to parent pair
  const handleSelectParentPair = (pairId: string) => {
    setSelectedParentPairId(pairId);
    if (!pairId) return;

    const pair = pairs.find(p => p.id === pairId);
    if (pair) {
      const cock = birds.find(b => b.id === pair.cockBirdId);
      const hen = birds.find(b => b.id === pair.henBirdId);

      setFormData(prev => ({
        ...prev,
        fatherRing: cock?.ringNumber || '',
        motherRing: hen?.ringNumber || '',
      }));
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateBird(bird.id, formData);
    setIsEditing(false);
  };

  // Find parents
  const fatherBird = birds.find(b => b.ringNumber && b.ringNumber === bird.fatherRing);
  const motherBird = birds.find(b => b.ringNumber && b.ringNumber === bird.motherRing);

  // Find offspring where this bird is Sire or Dam
  const offspringList = birds.filter(
    b => b.fatherRing === bird.ringNumber || b.motherRing === bird.ringNumber
  );

  // Health records for this bird
  const birdHealthRecords = healthRecords.filter(h => h.birdRingNumber === bird.ringNumber);

  const handleAddHealth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHealthTitle.trim()) return;

    addHealthRecord({
      birdRingNumber: bird.ringNumber,
      date: newHealthDate,
      recordType: newHealthType,
      title: newHealthTitle,
      description: `Logged from bird profile (${newHealthType})`,
      weightGrams: newHealthType === 'Weight Check' ? newHealthWeight : undefined,
      status: 'Completed',
    });

    if (newHealthType === 'Weight Check') {
      updateBird(bird.id, { weightGrams: newHealthWeight });
    }

    setNewHealthTitle('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto p-6 space-y-6">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm px-2.5 py-1 rounded bg-slate-950 text-emerald-400 border border-slate-800 font-bold tabular-nums">
              {bird.ringNumber}
            </span>
            <div>
              <h2 className="text-lg font-bold text-white">{bird.name || bird.ringNumber}</h2>
              <div className="text-xs text-slate-400">{bird.species}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Cancel Editing' : 'Edit Profile'}</span>
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-950 rounded-lg text-xs font-medium">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-2 rounded-md text-center transition-colors cursor-pointer ${
              activeTab === 'details' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview & Genetics
          </button>
          <button
            onClick={() => setActiveTab('pedigree')}
            className={`py-2 rounded-md text-center transition-colors cursor-pointer ${
              activeTab === 'pedigree' ? 'bg-slate-800 text-emerald-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Parentage & Lineage
          </button>
          <button
            onClick={() => setActiveTab('offspring')}
            className={`py-2 rounded-md text-center transition-colors cursor-pointer ${
              activeTab === 'offspring' ? 'bg-slate-800 text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Offspring ({offspringList.length})
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`py-2 rounded-md text-center transition-colors cursor-pointer ${
              activeTab === 'health' ? 'bg-slate-800 text-rose-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Health & Weight ({birdHealthRecords.length})
          </button>
        </div>

        {/* Tab 1: Profile Details & Editing */}
        {activeTab === 'details' && (
          <div>
            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Ring Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.ringNumber || ''}
                      onChange={e => setFormData({ ...formData, ringNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Bird Name
                    </label>
                    <input
                      type="text"
                      value={formData.name || ''}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Sex
                    </label>
                    <select
                      value={formData.sex || 'Unknown'}
                      onChange={e => setFormData({ ...formData, sex: e.target.value as BirdSex })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="Cock">Cock (Male)</option>
                      <option value="Hen">Hen (Female)</option>
                      <option value="Unknown">Unknown</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      DNA Status *
                    </label>
                    <select
                      value={formData.dnaStatus || 'Pending / Unknown'}
                      onChange={e => setFormData({ ...formData, dnaStatus: e.target.value as DnaStatus })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      {DNA_OPTIONS.map(dna => (
                        <option key={dna} value={dna}>{dna}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Aviary Status *
                    </label>
                    <select
                      value={formData.status || 'Home Bred'}
                      onChange={e => setFormData({ ...formData, status: e.target.value as BirdStatus })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      {STATUS_OPTIONS.map(st => (
                        <option key={st} value={st}>{st}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Cage / Flight Location
                    </label>
                    <input
                      type="text"
                      value={formData.cageNumber || ''}
                      onChange={e => setFormData({ ...formData, cageNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Color Mutation & Genetics Description *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.mutationDescription || ''}
                      onChange={e => setFormData({ ...formData, mutationDescription: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  {/* Direct Link to Parent Pair (Special feature for Home-Bred lineage tracking) */}
                  <div className="sm:col-span-2 p-3.5 bg-slate-950 rounded-xl border border-emerald-500/30 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                        <Heart className="w-4 h-4 text-emerald-400" />
                        <span>Link Direct to Parent Pair (Lineage Tracking)</span>
                      </label>
                      <span className="text-[11px] text-slate-400">Auto-links Sire & Dam</span>
                    </div>

                    <select
                      value={selectedParentPairId}
                      onChange={e => handleSelectParentPair(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="">Choose Parent Pair to Link...</option>
                      {pairs.map(p => {
                        const cock = birds.find(b => b.id === p.cockBirdId);
                        const hen = birds.find(b => b.id === p.henBirdId);
                        return (
                          <option key={p.id} value={p.id}>
                            {p.pairName} (Sire: {cock?.ringNumber} × Dam: {hen?.ringNumber})
                          </option>
                        );
                      })}
                    </select>

                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div>
                        <span className="text-[11px] text-slate-400 block mb-0.5">Sire (Father) Ring:</span>
                        <input
                          type="text"
                          value={formData.fatherRing || ''}
                          onChange={e => setFormData({ ...formData, fatherRing: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block mb-0.5">Dam (Mother) Ring:</span>
                        <input
                          type="text"
                          value={formData.motherRing || ''}
                          onChange={e => setFormData({ ...formData, motherRing: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-white font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Photo Upload */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Upload Custom Photograph
                    </label>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-lg text-xs cursor-pointer">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Select Image from Device</span>
                        <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                      </label>
                      <span className="text-xs text-slate-400">or choose preset photo in assets</span>
                    </div>
                  </div>

                  {/* Sold details if status is Sold */}
                  {formData.status === 'Sold' && (
                    <div className="sm:col-span-2 grid grid-cols-2 gap-3 p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Sold Price ($)</label>
                        <input
                          type="number"
                          value={formData.soldPrice || ''}
                          onChange={e => setFormData({ ...formData, soldPrice: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Purchaser / Buyer</label>
                        <input
                          type="text"
                          value={formData.soldTo || ''}
                          onChange={e => setFormData({ ...formData, soldTo: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                        />
                      </div>
                    </div>
                  )}

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Breeder Notes & History
                    </label>
                    <textarea
                      rows={2}
                      value={formData.notes || ''}
                      onChange={e => setFormData({ ...formData, notes: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            ) : (
              /* Read-Only High-Fidelity Overview */
              <div className="space-y-6">
                
                {/* Visual Hero Split */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 bg-slate-950 p-5 rounded-xl border border-slate-800">
                  <div className="relative h-44 rounded-xl overflow-hidden border border-slate-800 bg-slate-900">
                    <img
                      src={bird.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                      alt={bird.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <label className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/70 hover:bg-black/90 text-white cursor-pointer" title="Change photo">
                      <Upload className="w-3.5 h-3.5" />
                      <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                    </label>
                  </div>

                  <div className="sm:col-span-2 space-y-3">
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <span className={`px-2 py-0.5 rounded font-medium ${
                        bird.sex === 'Cock' ? 'bg-blue-950 text-blue-300 border border-blue-800' : bird.sex === 'Hen' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {bird.sex}
                      </span>
                      <span className="text-slate-400 font-medium">Status: {bird.status}</span>
                      <span className="text-slate-600">·</span>
                      <span className="text-emerald-400">{bird.dnaStatus}</span>
                      <span className="text-slate-600">·</span>
                      <span className="text-slate-400">{bird.cageNumber}</span>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400">Color Mutation & Genetics:</div>
                      <div className="text-base font-bold text-white mt-0.5">
                        {bird.mutationDescription}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-800">
                      <div>
                        <span className="text-slate-400 block">Hatch Date:</span>
                        <span className="font-mono text-slate-200">{bird.hatchDate}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Weight:</span>
                        <span className="font-mono text-slate-200">{bird.weightGrams ? `${bird.weightGrams}g` : 'Unrecorded'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Breeder / Lineage:</span>
                        <span className="text-slate-200">{bird.breederName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Total Clutches Raised:</span>
                        <span className="text-emerald-400 font-mono font-bold">{offspringList.length} chicks</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Parentage Quick Summary */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                      Parentage Heritage
                    </h4>
                    <button
                      onClick={() => {
                        onSelectBirdForPedigree(bird.id);
                        onNavigateTab('pedigree');
                        onClose();
                      }}
                      className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <span>Full 4-Generation Tree</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-blue-400 font-mono">Sire (Father)</div>
                        <div className="text-xs font-bold text-white">{fatherBird?.name || 'Registered Sire'}</div>
                        <div className="text-[11px] font-mono text-slate-400">{bird.fatherRing || 'Untracked'}</div>
                      </div>
                      {fatherBird && (
                        <button
                          onClick={() => {
                            onSelectBirdForPedigree(fatherBird.id);
                            onNavigateTab('pedigree');
                            onClose();
                          }}
                          className="text-[11px] text-emerald-400 underline"
                        >
                          View Sire
                        </button>
                      )}
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-rose-400 font-mono">Dam (Mother)</div>
                        <div className="text-xs font-bold text-white">{motherBird?.name || 'Registered Dam'}</div>
                        <div className="text-[11px] font-mono text-slate-400">{bird.motherRing || 'Untracked'}</div>
                      </div>
                      {motherBird && (
                        <button
                          onClick={() => {
                            onSelectBirdForPedigree(motherBird.id);
                            onNavigateTab('pedigree');
                            onClose();
                          }}
                          className="text-[11px] text-emerald-400 underline"
                        >
                          View Dam
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {bird.notes && (
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-xs text-slate-400 font-medium mb-1">Breeder Notes:</div>
                    <p className="text-xs text-slate-300 italic">{bird.notes}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Parentage & Lineage Details */}
        {activeTab === 'pedigree' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <GitFork className="w-4 h-4 text-emerald-400" />
                <span>Lineage & Parent Pair Linkage</span>
              </h4>
              <p className="text-xs text-slate-400">
                For home-bred lovebirds, parentage is established to avoid close inbreeding and preserve pure color mutations.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="text-xs font-bold text-blue-400">Sire (Father)</div>
                  <div className="text-sm font-mono text-white mt-1">{bird.fatherRing || 'Untracked'}</div>
                  <div className="text-xs text-slate-400 mt-1">{fatherBird?.mutationDescription || 'Lineage recorded'}</div>
                  {fatherBird && (
                    <div className="text-[11px] text-slate-500 mt-2">Status: {fatherBird.status} · Cage {fatherBird.cageNumber}</div>
                  )}
                </div>

                <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="text-xs font-bold text-rose-400">Dam (Mother)</div>
                  <div className="text-sm font-mono text-white mt-1">{bird.motherRing || 'Untracked'}</div>
                  <div className="text-xs text-slate-400 mt-1">{motherBird?.mutationDescription || 'Lineage recorded'}</div>
                  {motherBird && (
                    <div className="text-[11px] text-slate-500 mt-2">Status: {motherBird.status} · Cage {motherBird.cageNumber}</div>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => {
                    onSelectBirdForPedigree(bird.id);
                    onNavigateTab('pedigree');
                    onClose();
                  }}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                >
                  Open Full Pedigree Certificate
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Offspring Produced */}
        {activeTab === 'offspring' && (
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Direct Offspring Raised ({offspringList.length})
            </h4>

            {offspringList.length === 0 ? (
              <div className="p-8 text-center bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-400">
                No offspring recorded yet for {bird.name || bird.ringNumber}.
              </div>
            ) : (
              <div className="space-y-2">
                {offspringList.map(off => (
                  <div
                    key={off.id}
                    className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={off.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                        alt={off.name}
                        className="w-10 h-10 rounded-lg object-cover border border-slate-800"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="text-xs font-bold text-white">{off.name}</div>
                        <div className="text-[11px] font-mono text-emerald-400">{off.ringNumber}</div>
                        <div className="text-[10px] text-slate-400">{off.mutationDescription}</div>
                      </div>
                    </div>

                    <div className="text-right text-xs">
                      <div className="text-slate-300 font-medium">{off.status}</div>
                      <div className="text-[11px] font-mono text-slate-500">Hatched {off.hatchDate}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Health & Weight History */}
        {activeTab === 'health' && (
          <div className="space-y-4">
            
            {/* Quick Log Form */}
            <form onSubmit={handleAddHealth} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>Log Health Event or Weight for this Bird</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Type</label>
                  <select
                    value={newHealthType}
                    onChange={e => setNewHealthType(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                  >
                    <option value="Weight Check">Weight Check</option>
                    <option value="Deworming">Deworming</option>
                    <option value="Vaccination">Vaccination</option>
                    <option value="Vet Visit">Vet Visit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Date</label>
                  <input
                    type="date"
                    value={newHealthDate}
                    onChange={e => setNewHealthDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>

                {newHealthType === 'Weight Check' && (
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Weight (g)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={newHealthWeight}
                      onChange={e => setNewHealthWeight(parseFloat(e.target.value) || 50)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono tabular-nums"
                    />
                  </div>
                )}

                <div className={newHealthType === 'Weight Check' ? 'sm:col-span-1' : 'sm:col-span-2'}>
                  <label className="block text-[11px] text-slate-400 mb-1">Summary / Note</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Normal crop, feathers clear"
                    value={newHealthTitle}
                    onChange={e => setNewHealthTitle(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded cursor-pointer"
                >
                  Record Health Event
                </button>
              </div>
            </form>

            {/* Health Log Entries */}
            <div className="space-y-2">
              {birdHealthRecords.length === 0 ? (
                <div className="p-6 text-center bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-400">
                  No medical records logged yet for this bird.
                </div>
              ) : (
                birdHealthRecords.map(rec => (
                  <div
                    key={rec.id}
                    className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-white">{rec.title}</div>
                      <div className="text-[11px] text-slate-400">{rec.description}</div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="text-slate-300">{rec.date}</div>
                      {rec.weightGrams && (
                        <div className="text-emerald-400">{rec.weightGrams}g</div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
