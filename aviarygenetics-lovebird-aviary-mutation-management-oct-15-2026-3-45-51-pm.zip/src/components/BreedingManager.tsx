import React, { useState } from 'react';
import { 
  Heart, 
  Egg as EggIcon, 
  Calendar, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  X, 
  GitFork, 
  Trash2, 
  ChevronDown, 
  ChevronUp,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { BreedingPair, Clutch, Egg, Bird } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

interface BreedingManagerProps {
  onNavigateTab: (tab: string) => void;
  onSelectBirdForPedigree: (birdId: string) => void;
  isAddPairModalOpen: boolean;
  setIsAddPairModalOpen: (open: boolean) => void;
}

export const BreedingManager: React.FC<BreedingManagerProps> = ({
  onNavigateTab,
  onSelectBirdForPedigree,
  isAddPairModalOpen,
  setIsAddPairModalOpen,
}) => {
  const { 
    birds, 
    pairs, 
    clutches, 
    addBreedingPair, 
    updateBreedingPair, 
    deleteBreedingPair,
    addClutch,
    addEggToClutch,
    updateEgg,
    deleteEgg,
    addHomeBredBirdFromPair,
    config
  } = useAviary();

  // Selected pair for viewing or adding clutch
  const [selectedPairId, setSelectedPairId] = useState<string>(pairs[0]?.id || '');
  const [expandedClutchId, setExpandedClutchId] = useState<string | null>(null);

  // New Pair Form State
  const [newPairData, setNewPairData] = useState({
    pairName: '',
    cageNumber: 'Breeding Cage C-01',
    cockBirdId: '',
    henBirdId: '',
    dateFormed: new Date().toISOString().split('T')[0],
    notes: '',
  });

  // Home-Bred Offspring Modal State
  const [offspringModal, setOffspringModal] = useState<{
    isOpen: boolean;
    pairId: string;
    eggId?: string;
    ringNumber: string;
    name: string;
    sex: 'Cock' | 'Hen' | 'Unknown';
    mutationDescription: string;
    notes: string;
  }>({
    isOpen: false,
    pairId: '',
    eggId: undefined,
    ringNumber: '',
    name: '',
    sex: 'Unknown',
    mutationDescription: '',
    notes: '',
  });

  // Handle open quick offspring modal
  const handleOpenOffspringModal = (pairId: string, eggId?: string) => {
    const pair = pairs.find(p => p.id === pairId);
    if (!pair) return;
    const cock = birds.find(b => b.id === pair.cockBirdId);
    const hen = birds.find(b => b.id === pair.henBirdId);

    const year = new Date().getFullYear();
    const count = birds.filter(b => b.ringNumber.includes(`${year}`)).length + 1;
    const autoRing = `${config.societyRingPrefix}-${String(count).padStart(3, '0')}`;

    setOffspringModal({
      isOpen: true,
      pairId,
      eggId,
      ringNumber: autoRing,
      name: `Offspring of ${pair.pairName}`,
      sex: 'Unknown',
      mutationDescription: `${cock?.mutationDescription.split('/')[0] || ''} lineage`,
      notes: `Directly registered home-bred offspring from ${pair.pairName}.`,
    });
  };

  const handleConfirmOffspring = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offspringModal.pairId) return;

    addHomeBredBirdFromPair(offspringModal.pairId, offspringModal.eggId, {
      ringNumber: offspringModal.ringNumber,
      name: offspringModal.name,
      sex: offspringModal.sex,
      mutationDescription: offspringModal.mutationDescription,
      notes: offspringModal.notes,
    });

    setOffspringModal({ ...offspringModal, isOpen: false });
  };

  const handleCreatePair = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPairData.cockBirdId || !newPairData.henBirdId) return;

    const cock = birds.find(b => b.id === newPairData.cockBirdId);
    const hen = birds.find(b => b.id === newPairData.henBirdId);

    const pairName = newPairData.pairName.trim() || `${cock?.name || 'Cock'} × ${hen?.name || 'Hen'}`;

    const newPair = addBreedingPair({
      pairName,
      cageNumber: newPairData.cageNumber,
      cockBirdId: newPairData.cockBirdId,
      henBirdId: newPairData.henBirdId,
      dateFormed: newPairData.dateFormed,
      status: 'Active',
      notes: newPairData.notes,
    });

    setIsAddPairModalOpen(false);
    setSelectedPairId(newPair.id);
  };

  const eligibleCocks = birds.filter(b => b.sex === 'Cock' && b.status !== 'Deceased');
  const eligibleHens = birds.filter(b => b.sex === 'Hen' && b.status !== 'Deceased');

  const selectedPair = pairs.find(p => p.id === selectedPairId) || pairs[0];
  const pairClutches = clutches.filter(c => c.pairId === selectedPair?.id);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-emerald-400 mb-1">
            Breeding Cycles & Incubator
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Mating Pairs & Clutch Monitoring
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Track incubation timeline, candling (Day 6), hatching (Day 22), closed-ring banding (Day 8-10).
          </p>
        </div>

        <button
          onClick={() => setIsAddPairModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Form New Pair</span>
        </button>
      </div>

      {/* Main Layout: Pairs List Column + Selected Pair & Clutch Timeline Column */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: All Pairs Navigation */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 px-1">
            Breeding Pairs ({pairs.length})
          </h3>

          <div className="space-y-2">
            {pairs.map(pair => {
              const isSelected = pair.id === selectedPair?.id;
              const cock = birds.find(b => b.id === pair.cockBirdId);
              const hen = birds.find(b => b.id === pair.henBirdId);
              const activeClutch = clutches.find(c => c.pairId === pair.id && c.status === 'In Progress');

              return (
                <div
                  key={pair.id}
                  onClick={() => setSelectedPairId(pair.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected 
                      ? 'bg-slate-900 border-emerald-500/60 shadow-lg' 
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-white">{pair.pairName}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      pair.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {pair.status}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 mb-2">
                    {pair.cageNumber} · Formed {pair.dateFormed}
                  </div>

                  {/* Micro Parents Avatars */}
                  <div className="flex items-center justify-between text-xs text-slate-300 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center gap-1.5 truncate pr-2">
                      <span className="text-blue-400 font-mono">♂ {cock?.ringNumber}</span>
                      <span className="text-slate-600">×</span>
                      <span className="text-rose-400 font-mono">♀ {hen?.ringNumber}</span>
                    </div>
                    {activeClutch && (
                      <span className="text-[11px] font-mono text-amber-400 shrink-0">
                        {activeClutch.eggs.length} Eggs
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Columns: Active Selected Pair Workspace & Clutches */}
        {selectedPair && (
          <div className="lg:col-span-2 space-y-6">
            
            {/* Pair Hero Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>{selectedPair.pairName}</span>
                    <span className="text-xs text-slate-400 font-mono font-normal">
                      ({selectedPair.cageNumber})
                    </span>
                  </h3>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Total Clutches: <span className="font-mono text-slate-200">{selectedPair.totalClutches}</span> · 
                    Chicks Raised: <span className="font-mono text-emerald-400">{selectedPair.totalChicksRaised}</span>
                  </div>
                </div>

                {/* Direct Action: Add Home-Bred Offspring */}
                <button
                  onClick={() => handleOpenOffspringModal(selectedPair.id)}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Register Home-Bred Offspring</span>
                </button>
              </div>

              {/* Parents Lineage Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                {/* Cock Card */}
                {(() => {
                  const cock = birds.find(b => b.id === selectedPair.cockBirdId);
                  return (
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                      <img
                        src={cock?.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                        alt="Sire"
                        className="w-14 h-14 rounded-lg object-cover border border-slate-800 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] uppercase font-mono text-blue-400">Sire (Father)</div>
                        <div className="text-xs font-bold text-white truncate">{cock?.name}</div>
                        <div className="text-[11px] font-mono text-slate-400">{cock?.ringNumber}</div>
                        <div className="text-[10px] text-emerald-400 truncate">{cock?.mutationDescription}</div>
                      </div>
                    </div>
                  );
                })()}

                {/* Hen Card */}
                {(() => {
                  const hen = birds.find(b => b.id === selectedPair.henBirdId);
                  return (
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                      <img
                        src={hen?.photoUrl || '/src/assets/images/lovebird_opaline_lutino_1792053491787.jpg'}
                        alt="Dam"
                        className="w-14 h-14 rounded-lg object-cover border border-slate-800 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] uppercase font-mono text-rose-400">Dam (Mother)</div>
                        <div className="text-xs font-bold text-white truncate">{hen?.name}</div>
                        <div className="text-[11px] font-mono text-slate-400">{hen?.ringNumber}</div>
                        <div className="text-[10px] text-amber-400 truncate">{hen?.mutationDescription}</div>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Pair Actions: Add New Clutch */}
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => addClutch(selectedPair.id, `Nestbox ${selectedPair.cageNumber}`)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/30 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Start New Clutch</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm('Retire this breeding pair?')) {
                      updateBreedingPair(selectedPair.id, { status: 'Retired' });
                    }
                  }}
                  className="text-xs text-slate-500 hover:text-slate-300 cursor-pointer"
                >
                  Retire Pair
                </button>
              </div>
            </div>

            {/* Clutches Timeline & Egg Incubator */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <EggIcon className="w-4 h-4 text-amber-400" />
                <span>Clutches & Egg Incubator Timeline</span>
              </h3>

              {pairClutches.length === 0 ? (
                <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-xl">
                  <EggIcon className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-400">No clutches recorded yet for this pair.</p>
                  <button
                    onClick={() => addClutch(selectedPair.id, `Nestbox ${selectedPair.cageNumber}`)}
                    className="mt-3 px-3.5 py-1.5 text-xs font-medium text-emerald-400 bg-emerald-950 border border-emerald-800 rounded-lg hover:bg-emerald-900"
                  >
                    Log First Egg Clutch
                  </button>
                </div>
              ) : (
                pairClutches.map(clutch => (
                  <div
                    key={clutch.id}
                    className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
                  >
                    {/* Clutch Header */}
                    <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <span>Clutch #{clutch.clutchNumber}</span>
                          <span className="text-xs text-slate-400">({clutch.nestBoxNumber})</span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400">
                            {clutch.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          Started: {clutch.startDate} · {clutch.eggs.length} Total Eggs
                        </div>
                      </div>

                      <button
                        onClick={() => addEggToClutch(clutch.id)}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5 text-amber-400" />
                        <span>Log Egg</span>
                      </button>
                    </div>

                    {/* Eggs List / Incubator Tracker */}
                    <div className="p-4 space-y-3">
                      {clutch.eggs.length === 0 ? (
                        <p className="text-xs text-slate-500 italic py-2 text-center">
                          Nestbox empty. Click "Log Egg" when hen lays.
                        </p>
                      ) : (
                        clutch.eggs.map(egg => (
                          <div
                            key={egg.id}
                            className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-mono font-bold text-xs text-amber-300 shrink-0">
                                #{egg.eggNumber}
                              </div>
                              <div>
                                <div className="text-xs font-semibold text-slate-100 flex items-center gap-2">
                                  <span>Laid {egg.laidDate}</span>
                                  {egg.actualHatchDate ? (
                                    <span className="text-[11px] text-emerald-400 font-mono">
                                      Hatched on {egg.actualHatchDate}
                                    </span>
                                  ) : (
                                    <span className="text-[11px] text-amber-400 font-mono">
                                      Expected Hatch: {egg.expectedHatchDate}
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  Candling check (Day 6): {egg.candlingDate} · Banding target: {egg.bandingDate}
                                </div>
                              </div>
                            </div>

                            {/* Status Selector & Quick Action */}
                            <div className="flex items-center gap-2 self-end md:self-auto">
                              <select
                                value={egg.candlingStatus}
                                onChange={e => updateEgg(clutch.id, egg.id, { 
                                  candlingStatus: e.target.value as any 
                                })}
                                className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
                              >
                                <option value="Pending">Candling: Pending</option>
                                <option value="Fertile">Fertile (Spiderweb veins)</option>
                                <option value="Infertile">Infertile (Clear)</option>
                                <option value="Dead in Shell">Dead in Shell</option>
                                <option value="Broken">Broken</option>
                              </select>

                              {!egg.actualHatchDate ? (
                                <button
                                  onClick={() => updateEgg(clutch.id, egg.id, { 
                                    actualHatchDate: new Date().toISOString().split('T')[0] 
                                  })}
                                  className="px-2.5 py-1 text-xs font-medium text-emerald-400 hover:text-white bg-slate-900 hover:bg-emerald-950 border border-emerald-900/60 rounded cursor-pointer"
                                  title="Mark as hatched today"
                                >
                                  Hatch!
                                </button>
                              ) : !egg.addedToFlockId ? (
                                <button
                                  onClick={() => handleOpenOffspringModal(selectedPair.id, egg.id)}
                                  className="px-2.5 py-1 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded cursor-pointer"
                                  title="Add this chick as a home-bred bird in flock registry"
                                >
                                  Register Chick
                                </button>
                              ) : (
                                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded">
                                  Registered #{egg.bandingRingAssigned}
                                </span>
                              )}

                              <button
                                onClick={() => deleteEgg(clutch.id, egg.id)}
                                className="p-1 text-slate-500 hover:text-rose-400"
                                title="Remove Egg"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

      </div>

      {/* Form New Pair Modal */}
      {isAddPairModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Form New Breeding Pair</h3>
              <button onClick={() => setIsAddPairModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePair} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Select Stud Cock (Male) *
                </label>
                <select
                  required
                  value={newPairData.cockBirdId}
                  onChange={e => setNewPairData({ ...newPairData, cockBirdId: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="">Choose Stud Cock...</option>
                  {eligibleCocks.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.ringNumber}) - {c.mutationDescription}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Select Breeding Hen (Female) *
                </label>
                <select
                  required
                  value={newPairData.henBirdId}
                  onChange={e => setNewPairData({ ...newPairData, henBirdId: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="">Choose Breeding Hen...</option>
                  {eligibleHens.map(h => (
                    <option key={h.id} value={h.id}>
                      {h.name} ({h.ringNumber}) - {h.mutationDescription}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Pair Title / Reference Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Pair 3: Zephyr × Ruby"
                  value={newPairData.pairName}
                  onChange={e => setNewPairData({ ...newPairData, pairName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Cage / Flight Aviary Number
                </label>
                <input
                  type="text"
                  value={newPairData.cageNumber}
                  onChange={e => setNewPairData({ ...newPairData, cageNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddPairModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                >
                  Confirm & Form Pair
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Register Home-Bred Offspring Modal */}
      {offspringModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Register Home-Bred Offspring</span>
              </h3>
              <button 
                onClick={() => setOffspringModal({ ...offspringModal, isOpen: false })} 
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              This will automatically assign <span className="text-white font-semibold">Home Bred</span> status and link Sire and Dam lineage directly.
            </p>

            <form onSubmit={handleConfirmOffspring} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Closed Ring / Band Number *
                </label>
                <input
                  type="text"
                  required
                  value={offspringModal.ringNumber}
                  onChange={e => setOffspringModal({ ...offspringModal, ringNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Offspring Name
                </label>
                <input
                  type="text"
                  value={offspringModal.name}
                  onChange={e => setOffspringModal({ ...offspringModal, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Sex
                </label>
                <select
                  value={offspringModal.sex}
                  onChange={e => setOffspringModal({ ...offspringModal, sex: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Unknown">Unknown (Pending DNA / Moult)</option>
                  <option value="Cock">Cock (Male)</option>
                  <option value="Hen">Hen (Female)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Mutation Description
                </label>
                <input
                  type="text"
                  value={offspringModal.mutationDescription}
                  onChange={e => setOffspringModal({ ...offspringModal, mutationDescription: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="e.g. Opaline Green / Ino"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setOffspringModal({ ...offspringModal, isOpen: false })}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                >
                  Save to Flock Registry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
