import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  GitFork, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  Upload, 
  ShieldCheck, 
  Eye, 
  LayoutGrid, 
  List,
  Sparkles,
  ArrowRight,
  Heart
} from 'lucide-react';
import { Bird, BirdSex, BirdStatus, DnaStatus, LovebirdSpecies } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';
import { AddBirdLovebirdGeneticsModal } from './AddBirdLovebirdGeneticsModal';

interface FlockManagerProps {
  onSelectBirdForPedigree: (birdId: string) => void;
  onNavigateTab: (tab: string) => void;
  isAddModalOpen: boolean;
  setIsAddModalOpen: (open: boolean) => void;
  onOpenBirdProfile: (birdId: string) => void;
}

const STATUS_OPTIONS: BirdStatus[] = [
  'Home Bred',
  'Purchased',
  'Loan',
  'Sold',
  'Breeding Pair',
  'Quarantine',
  'Deceased',
];

export const FlockManager: React.FC<FlockManagerProps> = ({
  onSelectBirdForPedigree,
  onNavigateTab,
  isAddModalOpen,
  setIsAddModalOpen,
  onOpenBirdProfile,
}) => {
  const { birds, deleteBird } = useAviary();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sexFilter, setSexFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  const [editingBirdForModal, setEditingBirdForModal] = useState<Bird | null>(null);

  const handleOpenAdd = () => {
    setEditingBirdForModal(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (bird: Bird) => {
    setEditingBirdForModal(bird);
    setIsAddModalOpen(true);
  };

  const filteredBirds = birds.filter(b => {
    const matchesSearch = 
      b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.ringNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.mutationDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.cageNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'All' || b.status === statusFilter;
    const matchesSex = sexFilter === 'All' || b.sex === sexFilter;

    return matchesSearch && matchesStatus && matchesSex;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Controls Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-xl">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search ring no, bird name, mutation, cage..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status selector */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="All">All Statuses ({birds.length})</option>
            {STATUS_OPTIONS.map(st => (
              <option key={st} value={st}>
                {st} ({birds.filter(b => b.status === st).length})
              </option>
            ))}
          </select>

          {/* Sex selector */}
          <select
            value={sexFilter}
            onChange={e => setSexFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="All">All Sexes</option>
            <option value="Cock">Cock (Males)</option>
            <option value="Hen">Hen (Females)</option>
            <option value="Unknown">Unknown / Young</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded text-xs ${viewMode === 'grid' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded text-xs ${viewMode === 'table' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Add Bird Button (LovebirdGenetics standard) */}
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Add Bird (LovebirdGenetics)</span>
          </button>
        </div>
      </div>

      {/* Bird Count & Filter Chips */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <div>
          Showing <span className="font-mono text-white font-semibold">{filteredBirds.length}</span> of {birds.length} birds
        </div>
        <div className="flex items-center gap-2">
          {statusFilter !== 'All' && (
            <span className="text-emerald-400">Filtered: {statusFilter}</span>
          )}
          {sexFilter !== 'All' && (
            <span className="text-cyan-400">Sex: {sexFilter}</span>
          )}
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredBirds.map(bird => (
            <div
              key={bird.id}
              className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div 
                onClick={() => onOpenBirdProfile(bird.id)}
                className="cursor-pointer"
              >
                {/* Photo & Top Bar */}
                <div className="relative h-44 bg-slate-950 overflow-hidden">
                  <img
                    src={bird.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                    alt={bird.name}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />
                  
                  {/* Floating Top Indicators */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-950/80 backdrop-blur-md text-emerald-300 border border-slate-800 tabular-nums font-semibold">
                      {bird.ringNumber}
                    </span>
                    <span className={`text-[11px] font-medium px-2 py-0.5 rounded backdrop-blur-md ${
                      bird.sex === 'Cock' 
                        ? 'bg-blue-950/80 text-blue-300 border border-blue-800/60' 
                        : bird.sex === 'Hen'
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                        : 'bg-slate-950/80 text-slate-300 border border-slate-800'
                    }`}>
                      {bird.sex}
                    </span>
                  </div>

                  {/* Bottom Image Overlay Label */}
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-base font-bold text-white tracking-tight truncate">
                      {bird.name || bird.ringNumber}
                    </h3>
                    <p className="text-xs text-emerald-300/90 font-medium truncate">
                      {bird.mutationDescription}
                    </p>
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-4 space-y-3">
                  {/* Clean unboxed metadata with separators (Anti-Pill Rule) */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 flex-wrap">
                    <span className="text-slate-300 font-medium">{bird.status}</span>
                    <span aria-hidden="true">·</span>
                    <span>{bird.dnaStatus}</span>
                    <span aria-hidden="true">·</span>
                    <span>{bird.cageNumber}</span>
                  </div>

                  {/* Lineage parentage summary */}
                  <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 text-xs space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Sire (Father):</span>
                      <span className="font-mono text-slate-200">{bird.fatherRing || 'Untracked'}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Dam (Mother):</span>
                      <span className="font-mono text-slate-200">{bird.motherRing || 'Untracked'}</span>
                    </div>
                    <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/50">
                      <span>Hatched / Age:</span>
                      <span className="font-mono text-slate-300">{bird.hatchDate}</span>
                    </div>
                  </div>

                  {bird.notes && (
                    <p className="text-xs text-slate-400 line-clamp-2 italic">
                      "{bird.notes}"
                    </p>
                  )}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-4 py-3 bg-slate-950/80 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={() => onOpenBirdProfile(bird.id)}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Detailed Profile</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleOpenEdit(bird)}
                    className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Edit Bird in LovebirdGenetics Layout"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      onSelectBirdForPedigree(bird.id);
                      onNavigateTab('pedigree');
                    }}
                    className="p-1.5 text-slate-400 hover:text-emerald-400 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Pedigree Tree"
                  >
                    <GitFork className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Remove ${bird.name} (${bird.ringNumber}) from flock?`)) {
                        deleteBird(bird.id);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Delete Bird"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* High-Density Tabular View */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Bird / Ring</th>
                  <th className="py-3 px-4">Sex / DNA</th>
                  <th className="py-3 px-4">Mutation Description</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Sire × Dam</th>
                  <th className="py-3 px-4">Cage</th>
                  <th className="py-3 px-4">Hatch Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredBirds.map(bird => (
                  <tr 
                    key={bird.id} 
                    onClick={() => onOpenBirdProfile(bird.id)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={bird.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                          alt={bird.name}
                          className="w-8 h-8 rounded object-cover border border-slate-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-semibold text-white">{bird.name}</div>
                          <div className="font-mono text-[11px] text-emerald-400 tabular-nums">
                            {bird.ringNumber}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-200">{bird.sex}</div>
                      <div className="text-[11px] text-slate-400">{bird.dnaStatus}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                      {bird.mutationDescription}
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {bird.status}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {bird.fatherRing || '-'} × {bird.motherRing || '-'}
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {bird.cageNumber}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-400 tabular-nums">
                      {bird.hatchDate}
                    </td>
                    <td className="py-3 px-4 text-right" onClick={e => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => onOpenBirdProfile(bird.id)}
                          className="p-1 text-emerald-400 hover:text-emerald-300"
                          title="View Profile"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(bird)}
                          className="p-1 text-slate-400 hover:text-white"
                          title="Edit Bird"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            onSelectBirdForPedigree(bird.id);
                            onNavigateTab('pedigree');
                          }}
                          className="p-1 text-slate-400 hover:text-white"
                          title="View Pedigree"
                        >
                          <GitFork className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteBird(bird.id)}
                          className="p-1 text-slate-400 hover:text-rose-400"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* LovebirdGenetics Standard Layout Modal */}
      <AddBirdLovebirdGeneticsModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingBirdForModal(null);
        }}
        initialBird={editingBirdForModal}
      />

    </div>
  );
};
