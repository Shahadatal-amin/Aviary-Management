import React, { useState } from 'react';
import { 
  X, 
  Fingerprint, 
  Mail, 
  Phone, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  CheckCircle2, 
  Smartphone,
  KeyRound
} from 'lucide-react';
import { useAviary } from '../context/AviaryContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'user' | 'master';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'user',
}) => {
  const { session, loginUser, logoutUser, loginMaster, logoutMaster, config } = useAviary();

  const [activeTab, setActiveTab] = useState<'user' | 'master' | 'pin'>(initialMode);
  const [emailOrPhone, setEmailOrPhone] = useState('breeder@auroracrest.com');
  const [masterPassword, setMasterPassword] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [biometricScanning, setBiometricScanning] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Biometric login simulation (WebAuthn / TouchID / FaceID)
  const handleBiometricAuth = async () => {
    setBiometricScanning(true);
    setErrorMsg(null);

    try {
      // Check if browser has navigator.credentials
      if (window.PublicKeyCredential) {
        // Try real WebAuthn availability or simulate instant hardware biometric scan
      }
      await new Promise(r => setTimeout(r, 900));
      loginUser(emailOrPhone || 'biometric.breeder@auroracrest.com', 'biometric');
      setSuccessMsg('Biometric authentication verified (FaceID / TouchID).');
      setTimeout(() => {
        setBiometricScanning(false);
        setSuccessMsg(null);
        onClose();
      }, 700);
    } catch {
      setBiometricScanning(false);
      setErrorMsg('Biometric sensor timed out. Please enter credentials.');
    }
  };

  const handleCredentialsLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone.trim()) return;

    loginUser(emailOrPhone.trim(), 'credentials');
    setSuccessMsg('Signed in successfully.');
    setTimeout(() => {
      setSuccessMsg(null);
      onClose();
    }, 600);
  };

  const handlePinLogin = (digit: string) => {
    if (pinCode.length >= 4) return;
    const newPin = pinCode + digit;
    setPinCode(newPin);

    if (newPin.length === 4) {
      if (newPin === '2026' || newPin === '1234') {
        loginUser('Breeder PIN (2026)', 'pin');
        setSuccessMsg('PIN verified.');
        setTimeout(() => {
          setSuccessMsg(null);
          setPinCode('');
          onClose();
        }, 500);
      } else {
        setErrorMsg('Invalid PIN. Use 2026 or 1234.');
        setTimeout(() => {
          setPinCode('');
          setErrorMsg(null);
        }, 1200);
      }
    }
  };

  const handleMasterLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const ok = loginMaster(masterPassword);
    if (ok) {
      setSuccessMsg('Master Admin credentials verified. Administrative mode active.');
      setMasterPassword('');
      setTimeout(() => {
        setSuccessMsg(null);
        onClose();
      }, 700);
    } else {
      setErrorMsg('Incorrect master password. Default is master123.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 space-y-5">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Security & Authentication</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-lg text-xs font-medium">
          <button
            onClick={() => setActiveTab('user')}
            className={`py-1.5 rounded-md text-center transition-colors ${
              activeTab === 'user' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Email / Phone
          </button>
          <button
            onClick={() => setActiveTab('pin')}
            className={`py-1.5 rounded-md text-center transition-colors ${
              activeTab === 'pin' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            4-Digit PIN
          </button>
          <button
            onClick={() => setActiveTab('master')}
            className={`py-1.5 rounded-md text-center transition-colors ${
              activeTab === 'master' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Master Admin
          </button>
        </div>

        {/* Feedback Alerts */}
        {errorMsg && (
          <div className="p-3 bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs rounded-lg">
            {errorMsg}
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs rounded-lg flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab 1: Email / Mobile + Biometric */}
        {activeTab === 'user' && (
          <div className="space-y-4">
            
            {/* Biometric One-Tap Card */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
                <Fingerprint className={`w-6 h-6 text-emerald-400 ${biometricScanning ? 'animate-pulse' : ''}`} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Biometric Passkey Authentication</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Instant touch recognition with Touch ID, Face ID, or mobile sensor
                </p>
              </div>

              <button
                type="button"
                disabled={biometricScanning}
                onClick={handleBiometricAuth}
                className="w-full py-2 px-4 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
              >
                {biometricScanning ? 'Scanning Sensor...' : 'Authenticate with Biometrics'}
              </button>
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-800"></div>
              <span className="flex-shrink mx-3 text-[11px] text-slate-500 uppercase font-mono">or sign in with</span>
              <div className="flex-grow border-t border-slate-800"></div>
            </div>

            {/* Email / Mobile Form */}
            <form onSubmit={handleCredentialsLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Email Address or Mobile Phone Number
                </label>
                <input
                  type="text"
                  required
                  value={emailOrPhone}
                  onChange={e => setEmailOrPhone(e.target.value)}
                  placeholder="e.g. breeder@aviary.com or +1 555-0192"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
              >
                Sign In with Credentials
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: Quick 4-Digit PIN */}
        {activeTab === 'pin' && (
          <div className="space-y-4 text-center">
            <p className="text-xs text-slate-400">
              Enter your 4-digit aviary quick unlock PIN (Default: <span className="font-mono text-emerald-400">2026</span>)
            </p>

            {/* PIN Display */}
            <div className="flex justify-center gap-3 py-2">
              {[0, 1, 2, 3].map(idx => (
                <div
                  key={idx}
                  className={`w-10 h-12 rounded-lg border flex items-center justify-center font-mono font-bold text-lg ${
                    pinCode[idx] 
                      ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300' 
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  {pinCode[idx] ? '•' : ''}
                </div>
              ))}
            </div>

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto pt-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(digit => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handlePinLogin(digit)}
                  className="h-11 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-mono font-semibold text-sm transition-colors"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPinCode('')}
                className="h-11 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs font-medium"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => handlePinLogin('0')}
                className="h-11 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-mono font-semibold text-sm"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => setPinCode(pinCode.slice(0, -1))}
                className="h-11 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs font-medium"
              >
                ⌫
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Master Admin Mode */}
        {activeTab === 'master' && (
          <div className="space-y-4">
            <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-1">
              <div className="font-semibold text-white flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Master Admin Password Guard</span>
              </div>
              <p className="text-slate-400">
                Master password unlocks configuration of aviary title, custom logo, navigation modules, and genetic registries.
              </p>
              <p className="text-[11px] font-mono text-emerald-400">
                Default Master Passcode: master123
              </p>
            </div>

            {session.isMasterLoggedIn ? (
              <div className="space-y-3">
                <div className="p-3 bg-emerald-950 border border-emerald-500/40 rounded-lg text-emerald-300 text-xs flex items-center justify-between">
                  <span>Master Administrator mode is currently UNLOCKED.</span>
                  <button
                    onClick={logoutMaster}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded font-medium"
                  >
                    Lock Now
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleMasterLogin} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Master Password
                  </label>
                  <input
                    type="password"
                    required
                    value={masterPassword}
                    onChange={e => setMasterPassword(e.target.value)}
                    placeholder="Enter master password..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
                >
                  Unlock Master Administration
                </button>
              </form>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
