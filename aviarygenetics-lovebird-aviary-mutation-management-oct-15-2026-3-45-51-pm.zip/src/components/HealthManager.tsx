import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  Plus, 
  CheckCircle2, 
  Calendar, 
  AlertTriangle, 
  User, 
  X,
  Clock,
  Sparkles,
  Weight
} from 'lucide-react';
import { HealthRecord } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

export const HealthManager: React.FC = () => {
  const { 
    birds, 
    healthRecords, 
    addHealthRecord, 
    updateHealthRecord, 
    deleteHealthRecord 
  } = useAviary();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filterType, setFilterType] = useState<string>('All');

  const [formData, setFormData] = useState({
    birdRingNumber: birds[0]?.ringNumber || '',
    date: new Date().toISOString().split('T')[0],
    recordType: 'Deworming' as any,
    title: '',
    description: '',
    veterinarian: '',
    weightGrams: 50,
    nextDueDate: '',
    status: 'Completed' as any,
  });

  const handleOpenAdd = () => {
    setFormData({
      birdRingNumber: birds[0]?.ringNumber || '',
      date: new Date().toISOString().split('T')[0],
      recordType: 'Deworming',
      title: '',
      description: '',
      veterinarian: 'Dr. Evelyn Moss, DVM',
      weightGrams: 50,
      nextDueDate: '',
      status: 'Completed',
    });
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    addHealthRecord(formData);
    setIsAddModalOpen(false);
  };

  const filteredRecords = healthRecords.filter(r => {
    if (filterType === 'All') return true;
    return r.recordType === filterType;
  });

  const quarantineBirds = birds.filter(b => b.status === 'Quarantine');

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-rose-400 mb-1">
            Veterinary Care & Disease Prevention
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Health Records, Vaccinations & Quarantine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Log polyomavirus vaccinations, anti-parasitic deworming, routine weights, and 30-day quarantine isolation.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Log Medical Event</span>
        </button>
      </div>

      {/* Quarantine Station Watch Strip */}
      {quarantineBirds.length > 0 && (
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-amber-200">
              Active Quarantine Station ({quarantineBirds.length} birds isolated)
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Mandatory bio-security holding area. Requires separate feeding cups and hygiene protocol.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1">
            {quarantineBirds.map(qb => (
              <div 
                key={qb.id}
                className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-white">{qb.name}</div>
                  <div className="text-[11px] font-mono text-amber-400">{qb.ringNumber}</div>
                  <div className="text-[10px] text-slate-400">{qb.cageNumber}</div>
                </div>
                <span className="text-[10px] font-mono uppercase px-2 py-1 bg-amber-500/10 text-amber-300 rounded border border-amber-500/30">
                  Day 14 / 30
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Records Section with Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-sm font-semibold text-white">Medical Event History ({filteredRecords.length})</h3>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Filter:</span>
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200"
            >
              <option value="All">All Categories</option>
              <option value="Vaccination">Vaccination</option>
              <option value="Deworming">Deworming</option>
              <option value="Weight Check">Weight Check</option>
              <option value="Quarantine Check">Quarantine Check</option>
              <option value="Vet Visit">Vet Visit</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-slate-800/70">
          {filteredRecords.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No medical records logged for this filter.
            </div>
          ) : (
            filteredRecords.map(record => {
              const bird = birds.find(b => b.ringNumber === record.birdRingNumber);

              return (
                <div key={record.id} className="p-4 hover:bg-slate-800/30 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                      <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded ${
                        record.recordType === 'Vaccination'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                          : record.recordType === 'Deworming'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        {record.recordType}
                      </span>
                      <h4 className="text-xs font-bold text-white">
                        {record.title}
                      </h4>
                      <span className="text-[11px] font-mono text-slate-500">
                        {record.date}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400">
                      {record.description}
                    </p>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                      <span>Bird: <span className="font-mono text-emerald-400 font-semibold">{record.birdRingNumber}</span> {bird ? `(${bird.name})` : ''}</span>
                      {record.veterinarian && (
                        <span>· Examiner: {record.veterinarian}</span>
                      )}
                      {record.weightGrams && (
                        <span>· Weight: <span className="font-mono text-slate-200">{record.weightGrams}g</span></span>
                      )}
                    </div>
                  </div>

                  {record.nextDueDate && (
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 shrink-0 text-right">
                      <div className="text-[10px] text-slate-500 font-mono">Next Prophylaxis Due:</div>
                      <div className="text-xs font-bold text-cyan-400 font-mono">{record.nextDueDate}</div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Add Health Record Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Log Health & Medical Record</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Select Bird (Ring Number) *
                </label>
                <select
                  required
                  value={formData.birdRingNumber}
                  onChange={e => setFormData({ ...formData, birdRingNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {birds.map(b => (
                    <option key={b.id} value={b.ringNumber}>
                      {b.ringNumber} - {b.name} ({b.status})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Record Type
                </label>
                <select
                  value={formData.recordType}
                  onChange={e => setFormData({ ...formData, recordType: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Deworming">Deworming & Parasite Prevention</option>
                  <option value="Vaccination">Vaccination (Polyoma / Pox)</option>
                  <option value="Weight Check">Weight & Body Condition</option>
                  <option value="Quarantine Check">Quarantine Observation</option>
                  <option value="Vet Visit">Veterinary Clinical Visit</option>
                  <option value="Medication">Medication Course</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Event Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bi-Annual Ivermectin Spot-on"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Date Administered
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Next Due Date (Reminder)
                  </label>
                  <input
                    type="date"
                    value={formData.nextDueDate}
                    onChange={e => setFormData({ ...formData, nextDueDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Weight (Grams)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.weightGrams}
                    onChange={e => setFormData({ ...formData, weightGrams: parseFloat(e.target.value) || 50 })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Attending Vet / Handler
                  </label>
                  <input
                    type="text"
                    value={formData.veterinarian}
                    onChange={e => setFormData({ ...formData, veterinarian: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Clinical Notes & Observation
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="Dosage, clinical reaction, feather quality..."
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
