import React, { useState } from 'react';
import { 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Plus, 
  Edit3, 
  Check, 
  X, 
  Sparkles,
  Utensils
} from 'lucide-react';
import { FeedingSchedule } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

export const FeedingManager: React.FC = () => {
  const { 
    feedingSchedules, 
    feedingLogs, 
    addFeedingSchedule, 
    updateFeedingSchedule, 
    toggleFeedingSchedule, 
    logFeedingCompletion,
    session 
  } = useAviary();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSched, setEditingSched] = useState<FeedingSchedule | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    dietCategory: 'Base Seeds' as any,
    frequency: 'Daily' as any,
    timeOfDay: 'Morning (07:30)' as any,
    targetGroup: 'Entire Aviary' as any,
    instructions: '',
    active: true,
  });

  const todayStr = new Date().toISOString().split('T')[0];
  const todayLogs = feedingLogs.filter(l => l.date === todayStr);

  const handleOpenAdd = () => {
    setFormData({
      title: '',
      dietCategory: 'Base Seeds',
      frequency: 'Daily',
      timeOfDay: 'Morning (07:30)',
      targetGroup: 'Entire Aviary',
      instructions: '',
      active: true,
    });
    setEditingSched(null);
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    if (editingSched) {
      updateFeedingSchedule(editingSched.id, formData);
    } else {
      addFeedingSchedule(formData);
    }
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-emerald-400 mb-1">
            Nutritional Protocols & Aviary Diets
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Feeding Schedules & Daily Regimen
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage seed blends, germinated sprout bowls, breeding softfood, greens and vitamin rotations.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Add Diet Protocol</span>
        </button>
      </div>

      {/* Today's Feeding Checklist Strip */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">
              Today's Feeding Checklist ({todayStr})
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {todayLogs.length} of {feedingSchedules.filter(s => s.active).length} diets completed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {feedingSchedules.filter(s => s.active).map(schedule => {
            const isCompleted = todayLogs.some(l => l.scheduleId === schedule.id);

            return (
              <div
                key={schedule.id}
                className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                  isCompleted 
                    ? 'bg-emerald-950/20 border-emerald-500/40' 
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {schedule.dietCategory}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {schedule.timeOfDay}
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-white mb-1">
                    {schedule.title}
                  </h4>
                  <div className="text-[11px] text-slate-400 mb-2">
                    Target: <span className="text-slate-200">{schedule.targetGroup}</span> ({schedule.frequency})
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2">
                    {schedule.instructions}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between">
                  {isCompleted ? (
                    <span className="text-xs text-emerald-400 font-medium flex items-center gap-1.5 font-mono">
                      <CheckCircle2 className="w-4 h-4" />
                      Completed
                    </span>
                  ) : (
                    <button
                      onClick={() => logFeedingCompletion(schedule.id, 'Standard portion fed')}
                      className="w-full py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors cursor-pointer"
                    >
                      Mark Completed Today
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Diet Master Schedule Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-white">All Aviary Nutritional Protocols</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Protocol Title</th>
                <th className="py-3 px-4">Diet Category</th>
                <th className="py-3 px-4">Frequency / Time</th>
                <th className="py-3 px-4">Target Group</th>
                <th className="py-3 px-4">Instructions</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {feedingSchedules.map(sched => (
                <tr key={sched.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-4 font-semibold text-white">
                    {sched.title}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {sched.dietCategory}
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono">
                    {sched.frequency} · {sched.timeOfDay}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {sched.targetGroup}
                  </td>
                  <td className="py-3 px-4 text-slate-400 max-w-sm truncate">
                    {sched.instructions}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => toggleFeedingSchedule(sched.id)}
                      className={`px-2.5 py-1 text-[11px] font-mono rounded cursor-pointer ${
                        sched.active 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {sched.active ? 'Active' : 'Disabled'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Feeding Protocol Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingSched ? 'Edit Feeding Protocol' : 'New Dietary Protocol'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Protocol Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="e.g. Sprouted Seed & Eggfood Mash"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Diet Category
                </label>
                <select
                  value={formData.dietCategory}
                  onChange={e => setFormData({ ...formData, dietCategory: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Base Seeds">Base Seeds</option>
                  <option value="Eggfood & Softfood">Eggfood & Softfood</option>
                  <option value="Germinated & Sprouts">Germinated & Sprouts</option>
                  <option value="Fresh Greens & Veggies">Fresh Greens & Veggies</option>
                  <option value="Calcium & Minerals">Calcium & Minerals</option>
                  <option value="Supplements & Vitamins">Supplements & Vitamins</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Frequency
                  </label>
                  <select
                    value={formData.frequency}
                    onChange={e => setFormData({ ...formData, frequency: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="Daily">Daily</option>
                    <option value="Twice Daily">Twice Daily</option>
                    <option value="3 Times / Week">3 Times / Week</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Breeding Season Only">Breeding Season Only</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Time of Day
                  </label>
                  <select
                    value={formData.timeOfDay}
                    onChange={e => setFormData({ ...formData, timeOfDay: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="Morning (07:30)">Morning (07:30)</option>
                    <option value="Noon (12:00)">Noon (12:00)</option>
                    <option value="Evening (17:00)">Evening (17:00)</option>
                    <option value="All Day">All Day</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Group
                </label>
                <select
                  value={formData.targetGroup}
                  onChange={e => setFormData({ ...formData, targetGroup: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Entire Aviary">Entire Aviary</option>
                  <option value="Breeding Flights">Breeding Flights</option>
                  <option value="Weaning Nursery">Weaning Nursery</option>
                  <option value="Quarantine">Quarantine</option>
                  <option value="Resting Birds">Resting Birds</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Preparation Instructions
                </label>
                <textarea
                  rows={2}
                  value={formData.instructions}
                  onChange={e => setFormData({ ...formData, instructions: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="Ingredients, dosages, soak time..."
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg"
                >
                  Save Protocol
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
