import React, { useState } from 'react';
import { 
  GitFork, 
  Printer, 
  ShieldCheck, 
  Share2, 
  ChevronRight, 
  User, 
  ExternalLink,
  Award,
  Sparkles,
  QrCode
} from 'lucide-react';
import { Bird } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

interface PedigreeTreeProps {
  initialBirdId?: string;
  onNavigateTab: (tab: string) => void;
}

export const PedigreeTree: React.FC<PedigreeTreeProps> = ({
  initialBirdId,
  onNavigateTab,
}) => {
  const { birds, config } = useAviary();

  const [focusBirdId, setFocusBirdId] = useState<string>(
    initialBirdId || birds[0]?.id || ''
  );
  const [showCertificateView, setShowCertificateView] = useState(false);

  const focusBird = birds.find(b => b.id === focusBirdId) || birds[0];

  // Lookup ancestors by ring number
  const findBirdByRing = (ring?: string): Bird | undefined => {
    if (!ring) return undefined;
    return birds.find(b => b.ringNumber.trim().toLowerCase() === ring.trim().toLowerCase());
  };

  // Generation 1: Parents
  const sire = findBirdByRing(focusBird?.fatherRing);
  const dam = findBirdByRing(focusBird?.motherRing);

  // Generation 2: Grandparents
  const paternalGrandSire = findBirdByRing(sire?.fatherRing);
  const paternalGrandDam = findBirdByRing(sire?.motherRing);

  const maternalGrandSire = findBirdByRing(dam?.fatherRing);
  const maternalGrandDam = findBirdByRing(dam?.motherRing);

  // Lineage certificate hash simulation
  const lineageHash = focusBird ? `GEN-${focusBird.ringNumber.replace(/[^A-Za-z0-9]/g, '')}-${focusBird.hatchDate.replace(/-/g, '')}-VERIFIED` : 'N/A';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Controls & Bird Selector Bar */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider text-emerald-400 mb-1">
            Breeder Lineage Register
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Pedigree Ancestry & Certificate Generator
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Interactive multi-generation pedigree. Click any ancestor node to pivot the lineage tree.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Bird Selector Dropdown */}
          <select
            value={focusBirdId}
            onChange={e => setFocusBirdId(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
          >
            {birds.map(b => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.ringNumber}) - {b.status}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowCertificateView(!showCertificateView)}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            {showCertificateView ? 'Interactive Tree View' : 'Official Certificate'}
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Print Certificate</span>
          </button>
        </div>
      </div>

      {/* Official Certificate View (Print Optimized & Clean) */}
      {showCertificateView ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 max-w-4xl mx-auto space-y-6">
          {/* Certificate Header */}
          <div className="text-center pb-6 border-b border-slate-800 space-y-2">
            <div className="w-16 h-16 mx-auto rounded-xl overflow-hidden border border-emerald-500/40 p-1 bg-slate-950">
              <img 
                src={config.logoUrl} 
                alt="Aviary Logo" 
                className="w-full h-full object-cover rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white uppercase font-sans">
              Official Aviary Certificate of Pedigree
            </h1>
            <div className="text-xs text-emerald-400 font-mono">
              {config.aviaryName} · Registered Prefix: {config.societyRingPrefix}
            </div>
            <div className="text-xs text-slate-400">
              Breeder: {config.breederName} · {config.location}
            </div>
          </div>

          {/* Certified Bird Primary Card */}
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="w-32 h-32 mx-auto rounded-xl overflow-hidden border border-slate-800">
              <img
                src={focusBird?.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                alt={focusBird?.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="md:col-span-2 space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-800">
                <div>
                  <span className="text-slate-400 block">Registered Ring No:</span>
                  <span className="text-base font-bold font-mono text-emerald-400">{focusBird?.ringNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Bird Name:</span>
                  <span className="text-sm font-bold text-white">{focusBird?.name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Species:</span>
                  <span className="text-slate-200">{focusBird?.species}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Sex & DNA Status:</span>
                  <span className="text-slate-200 font-semibold">{focusBird?.sex} · {focusBird?.dnaStatus}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block">Color Mutation & Genotype:</span>
                <span className="text-emerald-300 font-semibold text-sm">{focusBird?.mutationDescription}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Hatch Date:</span>
                <span className="font-mono text-slate-300">{focusBird?.hatchDate} (Status: {focusBird?.status})</span>
              </div>
            </div>
          </div>

          {/* 3-Generation Pedigree Table in Certificate */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Verified Ancestral Heritage
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Sire Line */}
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="text-xs font-mono font-bold text-blue-400">SIRE (FATHER)</div>
                <div className="text-sm font-bold text-white">{sire?.name || 'External Outcross Sire'}</div>
                <div className="text-xs font-mono text-slate-400">Ring: {focusBird?.fatherRing || 'N/A'}</div>
                <div className="text-xs text-slate-300">{sire?.mutationDescription || 'Lineage on record'}</div>
                
                {/* Grandparents */}
                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                  <div>Paternal Grand-Sire: <span className="text-slate-200 font-mono">{sire?.fatherRing || 'N/A'}</span></div>
                  <div>Paternal Grand-Dam: <span className="text-slate-200 font-mono">{sire?.motherRing || 'N/A'}</span></div>
                </div>
              </div>

              {/* Dam Line */}
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="text-xs font-mono font-bold text-rose-400">DAM (MOTHER)</div>
                <div className="text-sm font-bold text-white">{dam?.name || 'External Outcross Dam'}</div>
                <div className="text-xs font-mono text-slate-400">Ring: {focusBird?.motherRing || 'N/A'}</div>
                <div className="text-xs text-slate-300">{dam?.mutationDescription || 'Lineage on record'}</div>

                {/* Grandparents */}
                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                  <div>Maternal Grand-Sire: <span className="text-slate-200 font-mono">{dam?.fatherRing || 'N/A'}</span></div>
                  <div>Maternal Grand-Dam: <span className="text-slate-200 font-mono">{dam?.motherRing || 'N/A'}</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* Certificate Footer Signature Block */}
          <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-6 text-xs text-slate-400">
            <div>
              <div className="font-mono text-[11px] text-slate-500">Certificate Verification Code:</div>
              <div className="font-mono text-emerald-400 font-bold">{lineageHash}</div>
            </div>

            <div className="text-right space-y-1">
              <div className="border-b border-slate-700 w-48 ml-auto pb-1 font-serif italic text-slate-200">
                {config.breederName}
              </div>
              <div className="text-[11px]">Authorized Master Aviary Signature</div>
            </div>
          </div>
        </div>
      ) : (
        /* Interactive Tree Flow Diagram */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 overflow-x-auto">
          <div className="min-w-[800px] flex items-center justify-center gap-6 py-6">
            
            {/* Column 1: Focus Bird (Generation 0) */}
            <div className="w-64 shrink-0">
              <div className="p-4 rounded-xl bg-slate-950 border-2 border-emerald-500/80 shadow-xl space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={focusBird?.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'}
                    alt={focusBird?.name}
                    className="w-14 h-14 rounded-lg object-cover border border-slate-800"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400">
                      Subject
                    </span>
                    <h4 className="text-sm font-bold text-white truncate mt-1">{focusBird?.name}</h4>
                    <div className="text-xs font-mono text-emerald-400">{focusBird?.ringNumber}</div>
                  </div>
                </div>

                <div className="text-xs text-slate-300">
                  <div className="font-medium text-white">{focusBird?.mutationDescription}</div>
                  <div className="text-slate-400 text-[11px] mt-1">{focusBird?.sex} · {focusBird?.dnaStatus}</div>
                  <div className="text-slate-400 text-[11px]">Hatched: {focusBird?.hatchDate}</div>
                </div>
              </div>
            </div>

            <ChevronRight className="w-6 h-6 text-slate-600 shrink-0" />

            {/* Column 2: Parents (Generation 1) */}
            <div className="w-64 shrink-0 space-y-6">
              
              {/* Sire Node */}
              <div 
                onClick={() => sire && setFocusBirdId(sire.id)}
                className={`p-3.5 rounded-xl border transition-all ${
                  sire 
                    ? 'bg-slate-950 border-blue-500/50 hover:border-blue-400 cursor-pointer' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">
                    Sire ♂
                  </span>
                  <span className="font-mono text-xs text-slate-300 truncate">
                    {focusBird?.fatherRing || 'Untracked'}
                  </span>
                </div>
                <div className="text-xs font-bold text-white truncate">{sire?.name || 'Registered Sire'}</div>
                <div className="text-[11px] text-slate-400 truncate mt-0.5">
                  {sire?.mutationDescription || 'Lineage on record'}
                </div>
              </div>

              {/* Dam Node */}
              <div 
                onClick={() => dam && setFocusBirdId(dam.id)}
                className={`p-3.5 rounded-xl border transition-all ${
                  dam 
                    ? 'bg-slate-950 border-rose-500/50 hover:border-rose-400 cursor-pointer' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-400">
                    Dam ♀
                  </span>
                  <span className="font-mono text-xs text-slate-300 truncate">
                    {focusBird?.motherRing || 'Untracked'}
                  </span>
                </div>
                <div className="text-xs font-bold text-white truncate">{dam?.name || 'Registered Dam'}</div>
                <div className="text-[11px] text-slate-400 truncate mt-0.5">
                  {dam?.mutationDescription || 'Lineage on record'}
                </div>
              </div>

            </div>

            <ChevronRight className="w-6 h-6 text-slate-600 shrink-0" />

            {/* Column 3: Grandparents (Generation 2) */}
            <div className="w-64 shrink-0 space-y-3">
              
              {/* Paternal Grand-Sire */}
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                <div className="text-[10px] text-blue-400 font-mono">Paternal Grand-Sire ♂</div>
                <div className="font-mono text-white truncate">{sire?.fatherRing || 'N/A'}</div>
              </div>

              {/* Paternal Grand-Dam */}
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                <div className="text-[10px] text-rose-400 font-mono">Paternal Grand-Dam ♀</div>
                <div className="font-mono text-white truncate">{sire?.motherRing || 'N/A'}</div>
              </div>

              {/* Maternal Grand-Sire */}
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                <div className="text-[10px] text-blue-400 font-mono">Maternal Grand-Sire ♂</div>
                <div className="font-mono text-white truncate">{dam?.fatherRing || 'N/A'}</div>
              </div>

              {/* Maternal Grand-Dam */}
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                <div className="text-[10px] text-rose-400 font-mono">Maternal Grand-Dam ♀</div>
                <div className="font-mono text-white truncate">{dam?.motherRing || 'N/A'}</div>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
