import React from 'react';
import { 
  Egg as EggIcon, 
  Dna, 
  Heart, 
  Calendar, 
  Clock, 
  Bell, 
  CheckCircle2, 
  AlertTriangle, 
  ChevronRight, 
  Sparkles, 
  FileText, 
  ShieldAlert,
  ArrowUpRight,
  TrendingUp,
  Plus,
  Eye
} from 'lucide-react';
import { useAviary } from '../context/AviaryContext';

interface DashboardProps {
  onNavigateTab: (tab: string) => void;
  onOpenAddBird: () => void;
  onOpenAddPair: () => void;
  onOpenExport: () => void;
  onSelectBirdForPedigree: (birdId: string) => void;
  onOpenBirdProfile?: (birdId: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  onNavigateTab,
  onOpenAddBird,
  onOpenAddPair,
  onOpenExport,
  onSelectBirdForPedigree,
  onOpenBirdProfile,
}) => {
  const { 
    birds, 
    pairs, 
    clutches, 
    reminders, 
    feedingSchedules, 
    feedingLogs, 
    healthRecords, 
    dismissReminder,
    addHomeBredBirdFromPair,
    config
  } = useAviary();

  const activeClutches = clutches.filter(c => c.status === 'In Progress');
  const allIncubatingEggs = activeClutches.flatMap(c => c.eggs.filter(e => e.candlingStatus !== 'Infertile' && e.candlingStatus !== 'Broken' && !e.actualHatchDate));
  const activePairs = pairs.filter(p => p.status === 'Active');

  // Today string
  const todayStr = new Date().toISOString().split('T')[0];
  const todayFeedsLogged = feedingLogs.filter(l => l.date === todayStr);

  // Mutation statistics
  const mutationStats = {
    opaline: birds.filter(b => b.mutationDescription.toLowerCase().includes('opaline')).length,
    lutino: birds.filter(b => b.mutationDescription.toLowerCase().includes('lutino') || b.mutationDescription.toLowerCase().includes('ino')).length,
    turquoise: birds.filter(b => b.mutationDescription.toLowerCase().includes('turquoise') || b.mutationDescription.toLowerCase().includes('blue')).length,
    violet: birds.filter(b => b.mutationDescription.toLowerCase().includes('violet')).length,
    darkFactor: birds.filter(b => b.mutationDescription.toLowerCase().includes('dark') || b.mutationDescription.toLowerCase().includes('cobalt') || b.mutationDescription.toLowerCase().includes('olive')).length,
    homeBred: birds.filter(b => b.status === 'Home Bred').length,
  };

  const [quickAddSuccess, setQuickAddSuccess] = React.useState<string | null>(null);

  const handleQuickAddOffspring = (pairId: string) => {
    const pair = pairs.find(p => p.id === pairId);
    if (!pair) return;
    const newOffspring = addHomeBredBirdFromPair(pairId);
    if (newOffspring) {
      setQuickAddSuccess(`Directly registered ${newOffspring.ringNumber} as Home Bred under ${pair.pairName}!`);
      setTimeout(() => setQuickAddSuccess(null), 4500);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Success Notification Bar */}
      {quickAddSuccess && (
        <div className="p-3.5 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{quickAddSuccess}</span>
          </div>
          <button 
            onClick={() => onNavigateTab('flock')}
            className="text-emerald-400 underline font-medium hover:text-emerald-300 ml-4 shrink-0"
          >
            View in Flock
          </button>
        </div>
      )}

      {/* Hero Aviary Overview Banner */}
      <div className="relative overflow-hidden rounded-xl bg-slate-900 border border-slate-800 p-6">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              {config.aviaryName}
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Genetic lineage tracking, breeding cycle incubator, and health records for lovebird mutations.
            </p>
          </div>

          {/* Quick Action Strip */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenAddBird}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-all cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add Bird</span>
            </button>
            <button
              onClick={() => onNavigateTab('genetics')}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              <Dna className="w-3.5 h-3.5 text-emerald-400" />
              <span>Genetics Calculator</span>
            </button>
            <button
              onClick={onOpenAddPair}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              <Heart className="w-3.5 h-3.5 text-rose-400" />
              <span>Form Mating Pair</span>
            </button>
            <button
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Export PDF / CSV</span>
            </button>
          </div>
        </div>

        {/* 4-Zone Primary KPI Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-950/60 rounded-lg p-3.5 border border-slate-800/80">
            <div className="text-xs text-slate-400">Total Flock Size</div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums mt-1">
              {birds.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {mutationStats.homeBred} Home Bred · {birds.filter(b => b.status === 'Purchased').length} Purchased
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-lg p-3.5 border border-slate-800/80">
            <div className="text-xs text-slate-400">Active Mating Pairs</div>
            <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums mt-1">
              {activePairs.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {activeClutches.length} Clutches currently in progress
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-lg p-3.5 border border-slate-800/80">
            <div className="text-xs text-slate-400">Incubating Eggs</div>
            <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums mt-1">
              {allIncubatingEggs.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Day 21-23 expected hatch cycle
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-lg p-3.5 border border-slate-800/80">
            <div className="text-xs text-slate-400">Upcoming Reminders</div>
            <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums mt-1">
              {reminders.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Candling, banding & health checks
            </div>
          </div>
        </div>
      </div>

      {/* Automated Notifications & Reminders Center */}
      {reminders.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-white">
                Automated Aviary Alerts & Reminders ({reminders.length})
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-mono">Real-time schedule monitor</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {reminders.map(rem => (
              <div 
                key={rem.id}
                className="bg-slate-950/70 border border-slate-800/90 rounded-lg p-3.5 flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      rem.severity === 'urgent' 
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' 
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    }`}>
                      {rem.type}
                    </span>
                    <span className="text-xs font-semibold text-slate-100">
                      {rem.title}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {rem.details}
                  </p>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Target Date: {rem.date}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => onNavigateTab(rem.type === 'health' ? 'health' : 'breeding')}
                    className="px-2.5 py-1 text-xs font-medium text-emerald-400 hover:text-white bg-slate-900 hover:bg-emerald-950/80 rounded border border-slate-800 transition-colors"
                  >
                    Action
                  </button>
                  <button
                    onClick={() => dismissReminder(rem.id)}
                    className="text-[11px] text-slate-500 hover:text-slate-300"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main 2-Column Dashboard Grid: Active Breeding Pairs & Clutches vs Genetics & Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Active Breeding Pairs & Incubator Status */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Active Breeding Pairs Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-semibold text-white">Active Breeding Pairs</h2>
              </div>
              <button
                onClick={() => onNavigateTab('breeding')}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
              >
                <span>Manage All Pairs</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-4">
              {activePairs.map(pair => {
                const cock = birds.find(b => b.id === pair.cockBirdId);
                const hen = birds.find(b => b.id === pair.henBirdId);
                const pairClutch = clutches.find(c => c.pairId === pair.id && c.status === 'In Progress');

                return (
                  <div
                    key={pair.id}
                    className="bg-slate-950/70 border border-slate-800 rounded-lg p-4 transition-all hover:border-slate-700"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <span>{pair.pairName}</span>
                          <span className="text-xs text-slate-400 font-mono">({pair.cageNumber})</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          Formed {pair.dateFormed} · {pair.totalChicksRaised} Total Chicks Raised
                        </div>
                      </div>

                      {/* Direct Add Home-Bred Offspring Button */}
                      <button
                        onClick={() => handleQuickAddOffspring(pair.id)}
                        className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/30 rounded-lg transition-colors cursor-pointer"
                        title="Add home-bred bird directly under this pair with automatic lineage linking"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Home-Bred Offspring</span>
                      </button>
                    </div>

                    {/* Parents Details Split */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                      {/* Cock */}
                      <div 
                        onClick={() => cock && onOpenBirdProfile && onOpenBirdProfile(cock.id)}
                        className="flex items-center gap-3 p-2 rounded-md bg-slate-900/70 border border-slate-800/70 cursor-pointer hover:border-slate-700 transition-colors"
                      >
                        <img 
                          src={cock?.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg'} 
                          alt={cock?.name || 'Sire'} 
                          className="w-10 h-10 rounded-md object-cover border border-slate-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-slate-200 truncate flex items-center gap-1">
                            <span>Sire: {cock?.name || 'Unknown'}</span>
                            <Eye className="w-3 h-3 text-slate-500" />
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {cock?.ringNumber}
                          </div>
                          <div className="text-[10px] text-emerald-400/90 truncate">
                            {cock?.mutationDescription}
                          </div>
                        </div>
                      </div>

                      {/* Hen */}
                      <div 
                        onClick={() => hen && onOpenBirdProfile && onOpenBirdProfile(hen.id)}
                        className="flex items-center gap-3 p-2 rounded-md bg-slate-900/70 border border-slate-800/70 cursor-pointer hover:border-slate-700 transition-colors"
                      >
                        <img 
                          src={hen?.photoUrl || '/src/assets/images/lovebird_opaline_lutino_1792053491787.jpg'} 
                          alt={hen?.name || 'Dam'} 
                          className="w-10 h-10 rounded-md object-cover border border-slate-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-slate-200 truncate flex items-center gap-1">
                            <span>Dam: {hen?.name || 'Unknown'}</span>
                            <Eye className="w-3 h-3 text-slate-500" />
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {hen?.ringNumber}
                          </div>
                          <div className="text-[10px] text-amber-400/90 truncate">
                            {hen?.mutationDescription}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Clutch Incubator Status */}
                    {pairClutch && (
                      <div className="mt-3 pt-3 border-t border-slate-800/60 flex flex-wrap items-center justify-between text-xs text-slate-400">
                        <div className="flex items-center gap-2">
                          <EggIcon className="w-3.5 h-3.5 text-amber-400" />
                          <span>Clutch #{pairClutch.clutchNumber}: {pairClutch.eggs.length} Eggs</span>
                          <span className="text-slate-600">·</span>
                          <span className="text-emerald-400">
                            {pairClutch.eggs.filter(e => e.actualHatchDate).length} Hatched
                          </span>
                        </div>
                        <button
                          onClick={() => onNavigateTab('breeding')}
                          className="text-xs text-slate-300 hover:text-white underline font-medium"
                        >
                          View Egg Candling Timeline
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Genetic Mutation Distribution in Flock */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Dna className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-semibold text-white">
                  Genetics & Mutation Portfolio (Flock Census)
                </h2>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={onOpenAddBird}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Bird</span>
                </button>
                <span className="text-slate-700">·</span>
                <button
                  onClick={() => onNavigateTab('genetics')}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                >
                  Run Pairing Engine
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                <div className="w-3 h-3 rounded-full bg-emerald-500 mx-auto mb-1.5" />
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {mutationStats.opaline}
                </div>
                <div className="text-[11px] text-slate-400">Opaline Line</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                <div className="w-3 h-3 rounded-full bg-yellow-400 mx-auto mb-1.5" />
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {mutationStats.lutino}
                </div>
                <div className="text-[11px] text-slate-400">Ino / Lutino</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                <div className="w-3 h-3 rounded-full bg-cyan-400 mx-auto mb-1.5" />
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {mutationStats.turquoise}
                </div>
                <div className="text-[11px] text-slate-400">Blue 1, 2 / B1B2</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                <div className="w-3 h-3 rounded-full bg-violet-500 mx-auto mb-1.5" />
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {mutationStats.violet}
                </div>
                <div className="text-[11px] text-slate-400">Violet Factor</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center col-span-2 sm:col-span-1">
                <div className="w-3 h-3 rounded-full bg-slate-400 mx-auto mb-1.5" />
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {mutationStats.darkFactor}
                </div>
                <div className="text-[11px] text-slate-400">Dark Factors (D/DD)</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Daily Feeding & Health Status + Quick Pedigree Access */}
        <div className="space-y-6">
          
          {/* Daily Feeding Routine Status */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-semibold text-white">Daily Feeding Checklist</h2>
              </div>
              <button
                onClick={() => onNavigateTab('feeding')}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
              >
                Full Schedule
              </button>
            </div>

            <div className="text-xs text-slate-400 mb-3">
              Today: {todayFeedsLogged.length} of {feedingSchedules.filter(s => s.active).length} diets completed
            </div>

            <div className="space-y-2">
              {feedingSchedules.slice(0, 3).map(schedule => {
                const isLogged = todayFeedsLogged.some(l => l.scheduleId === schedule.id);
                return (
                  <div
                    key={schedule.id}
                    className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="text-xs font-medium text-slate-200 truncate">
                        {schedule.title}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {schedule.timeOfDay} · {schedule.targetGroup}
                      </div>
                    </div>
                    {isLogged ? (
                      <span className="text-[11px] text-emerald-400 flex items-center gap-1 shrink-0 font-mono">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Done
                      </span>
                    ) : (
                      <span className="text-[11px] text-amber-400 shrink-0 font-mono">
                        Pending
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Health & Quarantine Status */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <h2 className="text-sm font-semibold text-white">Health & Medical Log</h2>
              </div>
              <button
                onClick={() => onNavigateTab('health')}
                className="text-xs text-rose-400 hover:text-rose-300 font-medium"
              >
                View Records
              </button>
            </div>

            <div className="space-y-2.5">
              {healthRecords.slice(0, 3).map(rec => (
                <div
                  key={rec.id}
                  className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 space-y-1"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200">{rec.title}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{rec.date}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    Ring #{rec.birdRingNumber} · {rec.description}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Featured Stud Bird Pedigree Showcase */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-white">Lineage Pedigree Explorer</h2>
              <span className="text-xs text-slate-500">Stud Spotlight</span>
            </div>

            {birds[0] && (
              <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-3">
                <div 
                  onClick={() => onOpenBirdProfile && onOpenBirdProfile(birds[0].id)}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <img 
                    src={birds[0].photoUrl} 
                    alt={birds[0].name}
                    className="w-12 h-12 rounded-lg object-cover border border-slate-800 group-hover:border-emerald-500 transition-colors"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">{birds[0].name}</div>
                    <div className="text-[11px] font-mono text-emerald-400">{birds[0].ringNumber}</div>
                    <div className="text-[10px] text-slate-400">{birds[0].mutationDescription}</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Parents: {birds[0].fatherRing || 'N/A'} × {birds[0].motherRing || 'N/A'}
                  </span>
                  <button
                    onClick={() => {
                      onSelectBirdForPedigree(birds[0].id);
                      onNavigateTab('pedigree');
                    }}
                    className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                  >
                    <span>View Pedigree Tree</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
