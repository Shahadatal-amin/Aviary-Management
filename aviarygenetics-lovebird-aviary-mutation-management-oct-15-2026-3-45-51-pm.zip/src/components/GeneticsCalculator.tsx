import React, { useState, useMemo } from 'react';
import { 
  Dna, 
  Sparkles, 
  RefreshCw, 
  Heart, 
  FileText, 
  Check, 
  HelpCircle,
  ArrowRight,
  Info
} from 'lucide-react';
import { 
  ParentGeneticsInput, 
  calculatePairingPredictions, 
  PairingResult 
} from '../genetics/lovebirdGeneticsEngine';
import { useAviary } from '../context/AviaryContext';

interface GeneticsCalculatorProps {
  onFormPairWithGenetics?: () => void;
  onNavigateTab: (tab: string) => void;
}

export const GeneticsCalculator: React.FC<GeneticsCalculatorProps> = ({
  onFormPairWithGenetics,
  onNavigateTab,
}) => {
  const { birds } = useAviary();

  // Sire Genetics Input
  const [sire, setSire] = useState<ParentGeneticsInput>({
    baseColor: 'Green',
    darkFactor: 1, // 1D (Dark Green)
    violetFactor: 0,
    visualFischer: false,
    splitFischer: false,
    visualPersonatus: false,
    splitPersonatus: false,
    visualIno: false,
    visualCinnamon: false,
    visualOpaline: true, // Visual Opaline
    visualPallid: false,
    splitIno: true, // Split Lutino
    splitCinnamon: false,
    splitOpaline: false,
    splitPallid: false,
    splitBlue1: true, // Split /Blue 1
    splitBlue2: false,
    splitB1B2: false,
    splitBlue: true,
    visualOrangeFaced: false,
    splitOrangeFaced: false,
    visualMarbled: false,
    splitMarbled: false,
    visualDilute: false,
    splitDilute: false,
    visualBronzeFallow: false,
    splitBronzeFallow: false,
    visualPaleFallow: false,
    splitPaleFallow: false,
    visualRecessivePied: false,
    splitRecessivePied: false,
    visualSlaty: false,
    splitSlaty: false,
    dominantPied: false,
    euwing: false,
    mist: false,
    edgedDilute: false,
  });

  // Dam Genetics Input
  const [dam, setDam] = useState<ParentGeneticsInput>({
    baseColor: 'Parblue B1B2',
    darkFactor: 1, // 1D
    violetFactor: 1, // 1SF Violet
    visualFischer: false,
    splitFischer: false,
    visualPersonatus: false,
    splitPersonatus: false,
    visualIno: true, // Visual Lutino / Albino
    visualCinnamon: false,
    visualOpaline: false,
    visualPallid: false,
    splitBlue1: false,
    splitBlue2: false,
    splitB1B2: false,
    splitBlue: false,
    visualOrangeFaced: false,
    splitOrangeFaced: false,
    visualMarbled: false,
    splitMarbled: false,
    visualDilute: false,
    splitDilute: false,
    visualBronzeFallow: false,
    splitBronzeFallow: false,
    visualPaleFallow: false,
    splitPaleFallow: false,
    visualRecessivePied: false,
    splitRecessivePied: false,
    visualSlaty: false,
    splitSlaty: false,
    dominantPied: false,
    euwing: false,
    mist: false,
    edgedDilute: false,
  });

  // Quick preset loader
  const handleLoadPreset = (presetName: string) => {
    if (presetName === 'opaline_lutino') {
      setSire({
        baseColor: 'Green',
        darkFactor: 1,
        violetFactor: 0,
        visualIno: false,
        visualCinnamon: false,
        visualOpaline: true,
        visualPallid: false,
        splitIno: true,
        splitBlue1: false,
        splitBlue2: false,
        splitB1B2: false,
        splitBlue: false,
      });
      setDam({
        baseColor: 'Green',
        darkFactor: 0,
        violetFactor: 0,
        visualIno: true,
        visualCinnamon: false,
        visualOpaline: false,
        visualPallid: false,
        splitBlue1: false,
        splitBlue2: false,
        splitB1B2: false,
        splitBlue: false,
      });
    } else if (presetName === 'violet_b1b2') {
      setSire({
        baseColor: 'Blue 2',
        darkFactor: 1,
        violetFactor: 1,
        visualIno: false,
        visualCinnamon: false,
        visualOpaline: false,
        visualPallid: false,
        splitBlue1: true,
        splitBlue2: false,
        splitB1B2: false,
        splitBlue: true,
      });
      setDam({
        baseColor: 'Parblue B1B2',
        darkFactor: 1,
        violetFactor: 1,
        visualIno: false,
        visualCinnamon: false,
        visualOpaline: false,
        visualPallid: false,
        splitBlue1: false,
        splitBlue2: false,
        splitB1B2: false,
        splitBlue: false,
      });
    } else if (presetName === 'fischer_orange') {
      setSire({
        baseColor: 'Green',
        darkFactor: 0,
        violetFactor: 0,
        visualFischer: true,
        splitFischer: false,
        visualIno: false,
        visualCinnamon: false,
        visualOpaline: false,
        visualPallid: false,
        visualOrangeFaced: true,
        splitOrangeFaced: false,
        splitBlue1: true,
        splitBlue: true,
      });
      setDam({
        baseColor: 'Green',
        darkFactor: 1,
        violetFactor: 0,
        visualFischer: false,
        splitFischer: true,
        visualIno: false,
        visualCinnamon: false,
        visualOpaline: true,
        visualPallid: false,
        splitOrangeFaced: true,
        splitBlue1: false,
        splitBlue: false,
      });
    }
  };

  // Run pairing prediction
  const result: PairingResult = useMemo(() => {
    return calculatePairingPredictions(sire, dam);
  }, [sire, dam]);

  // Load from real bird in flock
  const handleLoadSireFromFlock = (birdId: string) => {
    const b = birds.find(item => item.id === birdId);
    if (!b) return;
    const desc = b.mutationDescription.toLowerCase();
    const baseColor = desc.includes('parblue') || desc.includes('b1b2')
      ? 'Parblue B1B2'
      : desc.includes('blue 2')
      ? 'Blue 2'
      : desc.includes('blue 1')
      ? 'Blue 1'
      : desc.includes('blue')
      ? 'Blue 1'
      : 'Green';

    const sB1 = desc.includes('/blue 1') || desc.includes('//blue 1');
    const sB2 = desc.includes('/blue 2') || desc.includes('//blue 2');
    const sB1B2 = desc.includes('/b1b2') || desc.includes('//b1b2');

    setSire({
      baseColor,
      darkFactor: desc.includes('olive') || desc.includes('mauve') || desc.includes('2d') ? 2 : (desc.includes('dark') || desc.includes('cobalt') || desc.includes('1d')) ? 1 : 0,
      violetFactor: desc.includes('df violet') ? 2 : desc.includes('violet') ? 1 : 0,
      visualFischer: desc.includes('fischer') && !desc.includes('/fischer'),
      splitFischer: desc.includes('/fischer'),
      visualPersonatus: desc.includes('personatus') && !desc.includes('/personatus'),
      splitPersonatus: desc.includes('/personatus'),
      visualIno: desc.includes('lutino') || desc.includes('albino') || (desc.includes('ino') && !desc.includes('/ino')),
      visualCinnamon: desc.includes('cinnamon') && !desc.includes('/cinnamon'),
      visualOpaline: desc.includes('opaline') && !desc.includes('/opaline'),
      visualPallid: desc.includes('pallid') && !desc.includes('/pallid'),
      splitIno: desc.includes('/ino') || desc.includes('//ino'),
      splitOpaline: desc.includes('/opaline') || desc.includes('//opaline'),
      splitCinnamon: desc.includes('/cinnamon') || desc.includes('//cinnamon'),
      splitPallid: desc.includes('/pallid') || desc.includes('//pallid'),
      splitBlue1: sB1,
      splitBlue2: sB2,
      splitB1B2: sB1B2,
      splitBlue: sB1 || sB2 || sB1B2 || desc.includes('/blue'),
      visualOrangeFaced: desc.includes('orange-faced'),
      splitOrangeFaced: desc.includes('/orange-faced'),
      visualMarbled: desc.includes('marbled'),
      splitMarbled: desc.includes('/marbled'),
      visualDilute: desc.includes('dilute') && !desc.includes('edged'),
      splitDilute: desc.includes('/dilute'),
      visualBronzeFallow: desc.includes('bronze fallow'),
      splitBronzeFallow: desc.includes('/bronze fallow'),
      visualPaleFallow: desc.includes('pale fallow'),
      splitPaleFallow: desc.includes('/pale fallow'),
      visualRecessivePied: desc.includes('recessive pied'),
      splitRecessivePied: desc.includes('/recessive pied'),
      visualSlaty: desc.includes('slaty'),
      splitSlaty: desc.includes('/slaty'),
      dominantPied: desc.includes('dominant pied') || desc.includes('dom pied'),
      euwing: desc.includes('euwing'),
      mist: desc.includes('mist'),
      edgedDilute: desc.includes('edged'),
    });
  };

  const handleLoadDamFromFlock = (birdId: string) => {
    const b = birds.find(item => item.id === birdId);
    if (!b) return;
    const desc = b.mutationDescription.toLowerCase();
    const baseColor = desc.includes('parblue') || desc.includes('b1b2')
      ? 'Parblue B1B2'
      : desc.includes('blue 2')
      ? 'Blue 2'
      : desc.includes('blue 1')
      ? 'Blue 1'
      : desc.includes('blue')
      ? 'Blue 1'
      : 'Green';

    const sB1 = desc.includes('/blue 1') || desc.includes('//blue 1');
    const sB2 = desc.includes('/blue 2') || desc.includes('//blue 2');
    const sB1B2 = desc.includes('/b1b2') || desc.includes('//b1b2');

    setDam({
      baseColor,
      darkFactor: desc.includes('olive') || desc.includes('mauve') || desc.includes('2d') ? 2 : (desc.includes('dark') || desc.includes('cobalt') || desc.includes('1d')) ? 1 : 0,
      violetFactor: desc.includes('df violet') ? 2 : desc.includes('violet') ? 1 : 0,
      visualFischer: desc.includes('fischer') && !desc.includes('/fischer'),
      splitFischer: desc.includes('/fischer'),
      visualPersonatus: desc.includes('personatus') && !desc.includes('/personatus'),
      splitPersonatus: desc.includes('/personatus'),
      visualIno: desc.includes('lutino') || desc.includes('albino') || (desc.includes('ino') && !desc.includes('/ino')),
      visualCinnamon: desc.includes('cinnamon'),
      visualOpaline: desc.includes('opaline'),
      visualPallid: desc.includes('pallid'),
      splitBlue1: sB1,
      splitBlue2: sB2,
      splitB1B2: sB1B2,
      splitBlue: sB1 || sB2 || sB1B2 || desc.includes('/blue'),
      visualOrangeFaced: desc.includes('orange-faced'),
      splitOrangeFaced: desc.includes('/orange-faced'),
      visualMarbled: desc.includes('marbled'),
      splitMarbled: desc.includes('/marbled'),
      visualDilute: desc.includes('dilute') && !desc.includes('edged'),
      splitDilute: desc.includes('/dilute'),
      visualBronzeFallow: desc.includes('bronze fallow'),
      splitBronzeFallow: desc.includes('/bronze fallow'),
      visualPaleFallow: desc.includes('pale fallow'),
      splitPaleFallow: desc.includes('/pale fallow'),
      visualRecessivePied: desc.includes('recessive pied'),
      splitRecessivePied: desc.includes('/recessive pied'),
      visualSlaty: desc.includes('slaty'),
      splitSlaty: desc.includes('/slaty'),
      dominantPied: desc.includes('dominant pied') || desc.includes('dom pied'),
      euwing: desc.includes('euwing'),
      mist: desc.includes('mist'),
      edgedDilute: desc.includes('edged'),
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner - LovebirdGenetics.com inspired */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs uppercase font-mono tracking-wider text-emerald-400 mb-1">
              Automated Lovebird Genetics Engine
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Pairing Predictions & Mutation Calculator
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Modeled after authentic psittacine genetics (lovebirdgenetics.com). Calculates sex-linked inheritance (ZZ/ZW), dark factor co-dominance, and autosomal recessive carrier probabilities.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400">Presets:</span>
            <button
              onClick={() => handleLoadPreset('opaline_lutino')}
              className="px-2.5 py-1 text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded cursor-pointer"
            >
              Opaline × Lutino
            </button>
            <button
              onClick={() => handleLoadPreset('violet_b1b2')}
              className="px-2.5 py-1 text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded cursor-pointer"
            >
              Violet B1B2 × Blue 2
            </button>
            <button
              onClick={() => handleLoadPreset('fischer_orange')}
              className="px-2.5 py-1 text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded cursor-pointer"
            >
              Fischer Orange × /Blue 1
            </button>
          </div>
        </div>
      </div>

      {/* 2-Column Parent Genotype Selector: Cock (Sire) vs Hen (Dam) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Cock (Sire) Genetics Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-blue-400">♂ Sire (Cock)</span>
              <span className="text-xs text-slate-500 font-mono">Chromosomes: ZZ</span>
            </div>
            {/* Quick Flock Loader */}
            <select
              onChange={e => handleLoadSireFromFlock(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300"
            >
              <option value="">Load from Flock Cock...</option>
              {birds.filter(b => b.sex === 'Cock').map(b => (
                <option key={b.id} value={b.id}>{b.name} ({b.ringNumber})</option>
              ))}
            </select>
          </div>

          <div className="space-y-4">
            {/* Base Color Series: Green, Blue 1, Blue 2, Parblue B1B2 */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Base Series & Allele
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Green', 'Blue 1', 'Blue 2', 'Parblue B1B2'] as const).map(color => (
                  <button
                    key={color}
                    onClick={() => setSire({ ...sire, baseColor: color })}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      sire.baseColor === color
                        ? 'bg-blue-950 border-blue-500 text-blue-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>

            {/* Blue Locus Splits: /Blue 1, /Blue 2, /B1B2 */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Blue Locus Splits (Autosomal Carriers)
              </label>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(sire.splitBlue1)}
                    onChange={e => setSire({ 
                      ...sire, 
                      splitBlue1: e.target.checked,
                      splitBlue: e.target.checked || Boolean(sire.splitBlue2) || Boolean(sire.splitB1B2)
                    })}
                    className="rounded border-slate-700 text-blue-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/Blue 1</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(sire.splitBlue2)}
                    onChange={e => setSire({ 
                      ...sire, 
                      splitBlue2: e.target.checked,
                      splitBlue: Boolean(sire.splitBlue1) || e.target.checked || Boolean(sire.splitB1B2)
                    })}
                    className="rounded border-slate-700 text-blue-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/Blue 2</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(sire.splitB1B2)}
                    onChange={e => setSire({ 
                      ...sire, 
                      splitB1B2: e.target.checked,
                      splitBlue: Boolean(sire.splitBlue1) || Boolean(sire.splitBlue2) || e.target.checked
                    })}
                    className="rounded border-slate-700 text-blue-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/B1B2</span>
                </label>
              </div>
            </div>

            {/* Dark & Violet Factors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Dark Factor (Incomplete Dominant)
                </label>
                <select
                  value={sire.darkFactor}
                  onChange={e => setSire({ ...sire, darkFactor: Number(e.target.value) as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0D - Normal</option>
                  <option value={1}>1D - Single Dark (Dark Green / Cobalt)</option>
                  <option value={2}>2D - Double Dark (Olive / Mauve)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Violet Factor
                </label>
                <select
                  value={sire.violetFactor}
                  onChange={e => setSire({ ...sire, violetFactor: Number(e.target.value) as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0V - Normal (No Violet)</option>
                  <option value={1}>1V - SF Single Factor Violet</option>
                  <option value={2}>2V - DF Double Factor Violet</option>
                </select>
              </div>
            </div>

            {/* Interspecies (fischer, personatus) */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-200 mb-2">
                Interspecies & Modifiers (lovebirdgenetics.com)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">fischer</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualFischer)}
                        onChange={e => setSire({ ...sire, visualFischer: e.target.checked, splitFischer: e.target.checked ? false : sire.splitFischer })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualFischer}
                        checked={Boolean(sire.splitFischer)}
                        onChange={e => setSire({ ...sire, splitFischer: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualFischer ? 'text-slate-600' : 'text-slate-400 font-mono'}>/fischer</span>
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">personatus</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualPersonatus)}
                        onChange={e => setSire({ ...sire, visualPersonatus: e.target.checked, splitPersonatus: e.target.checked ? false : sire.splitPersonatus })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualPersonatus}
                        checked={Boolean(sire.splitPersonatus)}
                        onChange={e => setSire({ ...sire, splitPersonatus: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualPersonatus ? 'text-slate-600' : 'text-slate-400 font-mono'}>/personatus</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Sex-Linked Recessive (Cock can be Visual OR Split Carrier) */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-200 mb-2">
                Sex-Linked Recessive Traits (Z-Chromosome)
              </label>
              
              <div className="space-y-2">
                {/* Ino / Lutino */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">Ino (Lutino / Albino)</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sire.visualIno}
                        onChange={e => setSire({ 
                          ...sire, 
                          visualIno: e.target.checked,
                          splitIno: e.target.checked ? false : sire.splitIno 
                        })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualIno}
                        checked={sire.splitIno}
                        onChange={e => setSire({ ...sire, splitIno: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualIno ? 'text-slate-600' : 'text-slate-400 font-mono'}>/ino</span>
                    </label>
                  </div>
                </div>

                {/* Opaline */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">Opaline</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sire.visualOpaline}
                        onChange={e => setSire({ 
                          ...sire, 
                          visualOpaline: e.target.checked,
                          splitOpaline: e.target.checked ? false : sire.splitOpaline 
                        })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualOpaline}
                        checked={sire.splitOpaline}
                        onChange={e => setSire({ ...sire, splitOpaline: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualOpaline ? 'text-slate-600' : 'text-slate-400 font-mono'}>/opaline</span>
                    </label>
                  </div>
                </div>

                {/* Cinnamon */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">Cinnamon</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sire.visualCinnamon}
                        onChange={e => setSire({ 
                          ...sire, 
                          visualCinnamon: e.target.checked,
                          splitCinnamon: e.target.checked ? false : sire.splitCinnamon 
                        })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualCinnamon}
                        checked={sire.splitCinnamon}
                        onChange={e => setSire({ ...sire, splitCinnamon: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualCinnamon ? 'text-slate-600' : 'text-slate-400 font-mono'}>/cinnamon</span>
                    </label>
                  </div>
                </div>

                {/* Pallid */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">Pallid (Australian Cinnamon)</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sire.visualPallid}
                        onChange={e => setSire({ 
                          ...sire, 
                          visualPallid: e.target.checked,
                          splitPallid: e.target.checked ? false : sire.splitPallid 
                        })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualPallid}
                        checked={sire.splitPallid}
                        onChange={e => setSire({ ...sire, splitPallid: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                      />
                      <span className={sire.visualPallid ? 'text-slate-600' : 'text-slate-400 font-mono'}>/pallid</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Autosomal Recessive & Other Mutations */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-200 mb-2">
                Autosomal Mutations (lovebirdgenetics.com)
              </label>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {/* Orange-Faced */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">orange-faced</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualOrangeFaced)}
                        onChange={e => setSire({ ...sire, visualOrangeFaced: e.target.checked, splitOrangeFaced: e.target.checked ? false : sire.splitOrangeFaced })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualOrangeFaced}
                        checked={Boolean(sire.splitOrangeFaced)}
                        onChange={e => setSire({ ...sire, splitOrangeFaced: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Dilute */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">dilute</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualDilute)}
                        onChange={e => setSire({ ...sire, visualDilute: e.target.checked, splitDilute: e.target.checked ? false : sire.splitDilute })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualDilute}
                        checked={Boolean(sire.splitDilute)}
                        onChange={e => setSire({ ...sire, splitDilute: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Marbled */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">marbled</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualMarbled)}
                        onChange={e => setSire({ ...sire, visualMarbled: e.target.checked, splitMarbled: e.target.checked ? false : sire.splitMarbled })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualMarbled}
                        checked={Boolean(sire.splitMarbled)}
                        onChange={e => setSire({ ...sire, splitMarbled: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Bronze Fallow */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">bronze fallow</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(sire.visualBronzeFallow)}
                        onChange={e => setSire({ ...sire, visualBronzeFallow: e.target.checked, splitBronzeFallow: e.target.checked ? false : sire.splitBronzeFallow })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={sire.visualBronzeFallow}
                        checked={Boolean(sire.splitBronzeFallow)}
                        onChange={e => setSire({ ...sire, splitBronzeFallow: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Dominant Traits */}
            <div className="flex flex-wrap items-center gap-3 text-xs pt-1">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(sire.euwing)}
                  onChange={e => setSire({ ...sire, euwing: e.target.checked })}
                  className="rounded border-slate-700 text-emerald-500"
                />
                <span className="text-slate-300">Euwing</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(sire.dominantPied)}
                  onChange={e => setSire({ ...sire, dominantPied: e.target.checked })}
                  className="rounded border-slate-700 text-emerald-500"
                />
                <span className="text-slate-300">Dominant Pied</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(sire.mist)}
                  onChange={e => setSire({ ...sire, mist: e.target.checked })}
                  className="rounded border-slate-700 text-emerald-500"
                />
                <span className="text-slate-300">Mist</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(sire.edgedDilute)}
                  onChange={e => setSire({ ...sire, edgedDilute: e.target.checked })}
                  className="rounded border-slate-700 text-emerald-500"
                />
                <span className="text-slate-300">Edged Dilute</span>
              </label>
            </div>
          </div>
        </div>

        {/* Hen (Dam) Genetics Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-rose-400">♀ Dam (Hen)</span>
              <span className="text-xs text-slate-500 font-mono">Chromosomes: ZW</span>
            </div>
            {/* Quick Flock Loader */}
            <select
              onChange={e => handleLoadDamFromFlock(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-300"
            >
              <option value="">Load from Flock Hen...</option>
              {birds.filter(b => b.sex === 'Hen').map(b => (
                <option key={b.id} value={b.id}>{b.name} ({b.ringNumber})</option>
              ))}
            </select>
          </div>

          <div className="space-y-4">
            {/* Base Color Series: Green, Blue 1, Blue 2, Parblue B1B2 */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Base Series & Allele
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Green', 'Blue 1', 'Blue 2', 'Parblue B1B2'] as const).map(color => (
                  <button
                    key={color}
                    onClick={() => setDam({ ...dam, baseColor: color })}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                      dam.baseColor === color
                        ? 'bg-rose-950 border-rose-500 text-rose-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>

            {/* Blue Locus Splits: /Blue 1, /Blue 2, /B1B2 */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Blue Locus Splits (Autosomal Carriers)
              </label>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(dam.splitBlue1)}
                    onChange={e => setDam({ 
                      ...dam, 
                      splitBlue1: e.target.checked,
                      splitBlue: e.target.checked || Boolean(dam.splitBlue2) || Boolean(dam.splitB1B2)
                    })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/Blue 1</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(dam.splitBlue2)}
                    onChange={e => setDam({ 
                      ...dam, 
                      splitBlue2: e.target.checked,
                      splitBlue: Boolean(dam.splitBlue1) || e.target.checked || Boolean(dam.splitB1B2)
                    })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/Blue 2</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer bg-slate-900 px-2.5 py-1 rounded border border-slate-800 hover:border-slate-700">
                  <input
                    type="checkbox"
                    checked={Boolean(dam.splitB1B2)}
                    onChange={e => setDam({ 
                      ...dam, 
                      splitB1B2: e.target.checked,
                      splitBlue: Boolean(dam.splitBlue1) || Boolean(dam.splitBlue2) || e.target.checked
                    })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="font-mono text-slate-200">/B1B2</span>
                </label>
              </div>
            </div>

            {/* Dark & Violet Factors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Dark Factor (Incomplete Dominant)
                </label>
                <select
                  value={dam.darkFactor}
                  onChange={e => setDam({ ...dam, darkFactor: Number(e.target.value) as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0D - Normal</option>
                  <option value={1}>1D - Single Dark (Dark Green / Cobalt)</option>
                  <option value={2}>2D - Double Dark (Olive / Mauve)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Violet Factor
                </label>
                <select
                  value={dam.violetFactor}
                  onChange={e => setDam({ ...dam, violetFactor: Number(e.target.value) as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0V - Normal (No Violet)</option>
                  <option value={1}>1V - SF Single Factor Violet</option>
                  <option value={2}>2V - DF Double Factor Violet</option>
                </select>
              </div>
            </div>

            {/* Interspecies (fischer, personatus) */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-200 mb-2">
                Interspecies & Modifiers (lovebirdgenetics.com)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">fischer</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualFischer)}
                        onChange={e => setDam({ ...dam, visualFischer: e.target.checked, splitFischer: e.target.checked ? false : dam.splitFischer })}
                        className="rounded border-slate-700 text-rose-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualFischer}
                        checked={Boolean(dam.splitFischer)}
                        onChange={e => setDam({ ...dam, splitFischer: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500 focus:ring-0"
                      />
                      <span className={dam.visualFischer ? 'text-slate-600' : 'text-slate-400 font-mono'}>/fischer</span>
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="text-slate-300">personatus</span>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualPersonatus)}
                        onChange={e => setDam({ ...dam, visualPersonatus: e.target.checked, splitPersonatus: e.target.checked ? false : dam.splitPersonatus })}
                        className="rounded border-slate-700 text-rose-500 focus:ring-0"
                      />
                      <span className="text-slate-300">Visual</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualPersonatus}
                        checked={Boolean(dam.splitPersonatus)}
                        onChange={e => setDam({ ...dam, splitPersonatus: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500 focus:ring-0"
                      />
                      <span className={dam.visualPersonatus ? 'text-slate-600' : 'text-slate-400 font-mono'}>/personatus</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Sex-Linked Recessive for Hen: Visual ONLY (No split carrier possible on ZW) */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-semibold text-slate-200">
                  Sex-Linked Traits (Visual Only for Hens)
                </label>
                <span className="text-[10px] text-slate-500 font-mono">ZW females cannot be split</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dam.visualIno}
                    onChange={e => setDam({ ...dam, visualIno: e.target.checked })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="text-slate-300">Ino (Lutino)</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dam.visualOpaline}
                    onChange={e => setDam({ ...dam, visualOpaline: e.target.checked })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="text-slate-300">Opaline</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dam.visualCinnamon}
                    onChange={e => setDam({ ...dam, visualCinnamon: e.target.checked })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="text-slate-300">Cinnamon</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dam.visualPallid}
                    onChange={e => setDam({ ...dam, visualPallid: e.target.checked })}
                    className="rounded border-slate-700 text-rose-500 focus:ring-0"
                  />
                  <span className="text-slate-300">Pallid</span>
                </label>
              </div>
            </div>

            {/* Autosomal Recessive & Other Mutations for Dam */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-200 mb-2">
                Autosomal Mutations (lovebirdgenetics.com)
              </label>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {/* Orange-Faced */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">orange-faced</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualOrangeFaced)}
                        onChange={e => setDam({ ...dam, visualOrangeFaced: e.target.checked, splitOrangeFaced: e.target.checked ? false : dam.splitOrangeFaced })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualOrangeFaced}
                        checked={Boolean(dam.splitOrangeFaced)}
                        onChange={e => setDam({ ...dam, splitOrangeFaced: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Dilute */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">dilute</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualDilute)}
                        onChange={e => setDam({ ...dam, visualDilute: e.target.checked, splitDilute: e.target.checked ? false : dam.splitDilute })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualDilute}
                        checked={Boolean(dam.splitDilute)}
                        onChange={e => setDam({ ...dam, splitDilute: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Marbled */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">marbled</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualMarbled)}
                        onChange={e => setDam({ ...dam, visualMarbled: e.target.checked, splitMarbled: e.target.checked ? false : dam.splitMarbled })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualMarbled}
                        checked={Boolean(dam.splitMarbled)}
                        onChange={e => setDam({ ...dam, splitMarbled: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>

                {/* Bronze Fallow */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-300">bronze fallow</span>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(dam.visualBronzeFallow)}
                        onChange={e => setDam({ ...dam, visualBronzeFallow: e.target.checked, splitBronzeFallow: e.target.checked ? false : dam.splitBronzeFallow })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">Vis</span>
                    </label>
                    <label className="cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={dam.visualBronzeFallow}
                        checked={Boolean(dam.splitBronzeFallow)}
                        onChange={e => setDam({ ...dam, splitBronzeFallow: e.target.checked })}
                        className="rounded border-slate-700 text-rose-500"
                      />
                      <span className="ml-1 text-[11px] text-slate-400">/split</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Dominant Traits */}
            <div className="flex flex-wrap items-center gap-3 text-xs pt-1">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(dam.euwing)}
                  onChange={e => setDam({ ...dam, euwing: e.target.checked })}
                  className="rounded border-slate-700 text-rose-500"
                />
                <span className="text-slate-300">Euwing</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(dam.dominantPied)}
                  onChange={e => setDam({ ...dam, dominantPied: e.target.checked })}
                  className="rounded border-slate-700 text-rose-500"
                />
                <span className="text-slate-300">Dominant Pied</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(dam.mist)}
                  onChange={e => setDam({ ...dam, mist: e.target.checked })}
                  className="rounded border-slate-700 text-rose-500"
                />
                <span className="text-slate-300">Mist</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(dam.edgedDilute)}
                  onChange={e => setDam({ ...dam, edgedDilute: e.target.checked })}
                  className="rounded border-slate-700 text-rose-500"
                />
                <span className="text-slate-300">Edged Dilute</span>
              </label>
            </div>
          </div>
        </div>

      </div>

      {/* Genetics Pairing Calculation Results Stage */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
        
        {/* Pairing Summary Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="text-xs uppercase font-mono tracking-wider text-emerald-400 mb-1">
              Theoretical Offspring Expectations
            </div>
            <h3 className="text-base font-bold text-white flex items-center gap-2 flex-wrap">
              <span>{result.sireSummary}</span>
              <span className="text-slate-500">×</span>
              <span>{result.damSummary}</span>
            </h3>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigateTab('breeding')}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
            >
              <Heart className="w-3.5 h-3.5" />
              <span>Form This Pair in Aviary</span>
            </button>
          </div>
        </div>

        {/* Genetic Insights & Biological Rules Alert */}
        {result.overallSummary.length > 0 && (
          <div className="p-3.5 bg-slate-950 border border-emerald-500/30 rounded-lg space-y-1">
            <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
              <Info className="w-4 h-4" />
              <span>Genetic Inheritance Insights</span>
            </div>
            {result.overallSummary.map((note, idx) => (
              <p key={idx} className="text-xs text-slate-300 pl-5">
                • {note}
              </p>
            ))}
          </div>
        )}

        {/* 2-Column Sex Breakdown: Male (Cock) vs Female (Hen) Offspring */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Cock Offspring Outcomes */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="text-sm font-bold text-blue-400 flex items-center gap-1.5">
                <span>♂ Cock (Male) Offspring (50% of brood)</span>
              </h4>
              <span className="text-xs text-slate-500 font-mono">ZZ Genotype</span>
            </div>

            <div className="space-y-2.5">
              {result.cockOutcomes.map((outcome, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      {/* Visual Color Swatch */}
                      <div 
                        className="w-5 h-5 rounded-full border border-slate-700 shadow-sm shrink-0"
                        style={{ backgroundColor: outcome.colorHexPreview }}
                        title={`Plumage Preview: ${outcome.phenotypeName}`}
                      />
                      <span className="text-xs font-bold text-white">
                        {outcome.phenotypeName}
                      </span>
                    </div>

                    <span className="font-mono text-sm font-bold text-emerald-400 tabular-nums">
                      {outcome.percentage}%
                    </span>
                  </div>

                  {/* Splits & Genotype notation */}
                  <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                    <div className="font-mono text-slate-500">
                      {outcome.genotypeNotation}
                    </div>
                    {outcome.splitGenes.length > 0 ? (
                      <div className="text-amber-300/90 font-medium">
                        Carrier: {outcome.splitGenes.join(', ')}
                      </div>
                    ) : (
                      <div className="text-slate-500">Pure visual</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hen Offspring Outcomes */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                <span>♀ Hen (Female) Offspring (50% of brood)</span>
              </h4>
              <span className="text-xs text-slate-500 font-mono">ZW Genotype</span>
            </div>

            <div className="space-y-2.5">
              {result.henOutcomes.map((outcome, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      {/* Visual Color Swatch */}
                      <div 
                        className="w-5 h-5 rounded-full border border-slate-700 shadow-sm shrink-0"
                        style={{ backgroundColor: outcome.colorHexPreview }}
                        title={`Plumage Preview: ${outcome.phenotypeName}`}
                      />
                      <span className="text-xs font-bold text-white">
                        {outcome.phenotypeName}
                      </span>
                    </div>

                    <span className="font-mono text-sm font-bold text-emerald-400 tabular-nums">
                      {outcome.percentage}%
                    </span>
                  </div>

                  {/* Splits & Genotype notation */}
                  <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                    <div className="font-mono text-slate-500">
                      {outcome.genotypeNotation}
                    </div>
                    {outcome.splitGenes.length > 0 ? (
                      <div className="text-amber-300/90 font-medium">
                        Carrier: {outcome.splitGenes.join(', ')}
                      </div>
                    ) : (
                      <div className="text-slate-500">No sex-linked splits</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
