import React, { useState } from 'react';
import { 
  X, 
  FileText, 
  Download, 
  Printer, 
  Table, 
  ShieldCheck, 
  Calendar,
  Check,
  CheckSquare,
  Square,
  Layers
} from 'lucide-react';
import { useAviary } from '../context/AviaryContext';

interface ReportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportExportModal: React.FC<ReportExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { birds, pairs, clutches, healthRecords, config } = useAviary();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // PDF Report Options
  const [includeFlock, setIncludeFlock] = useState(true);
  const [includeBreeding, setIncludeBreeding] = useState(true);
  const [includeHealth, setIncludeHealth] = useState(true);

  if (!isOpen) return null;

  // CSV Generator Helper
  const downloadCsv = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = [
      headers.join(','),
      ...rows.map(row => 
        row.map(cell => {
          const str = String(cell ?? '');
          return str.includes(',') || str.includes('"') || str.includes('\n')
            ? `"${str.replace(/"/g, '""')}"`
            : str;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(`Downloaded ${filename}`);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  // 1. Export Flock CSV
  const handleExportFlockCsv = () => {
    const headers = [
      'Ring Number',
      'Name',
      'Species',
      'Sex',
      'DNA Status',
      'Aviary Status',
      'Mutation Description',
      'Hatch Date',
      'Cage Number',
      'Father (Sire) Ring',
      'Mother (Dam) Ring',
      'Weight (g)',
      'Breeder',
      'Notes'
    ];

    const rows = birds.map(b => [
      b.ringNumber,
      b.name,
      b.species,
      b.sex,
      b.dnaStatus,
      b.status,
      b.mutationDescription,
      b.hatchDate,
      b.cageNumber,
      b.fatherRing || '',
      b.motherRing || '',
      b.weightGrams || '',
      b.breederName,
      b.notes || ''
    ]);

    downloadCsv(`flock_census_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
  };

  // 2. Export Breeding Clutches CSV
  const handleExportBreedingCsv = () => {
    const headers = [
      'Pair Name',
      'Cage Number',
      'Sire Ring',
      'Dam Ring',
      'Clutch Number',
      'Nestbox',
      'Clutch Status',
      'Egg Number',
      'Laid Date',
      'Expected Hatch Date',
      'Actual Hatch Date',
      'Candling Status',
      'Band Ring Assigned'
    ];

    const rows: (string | number)[][] = [];
    clutches.forEach(c => {
      const pair = pairs.find(p => p.id === c.pairId);
      const cock = birds.find(b => b.id === pair?.cockBirdId);
      const hen = birds.find(b => b.id === pair?.henBirdId);

      c.eggs.forEach(egg => {
        rows.push([
          pair?.pairName || c.pairId,
          pair?.cageNumber || '',
          cock?.ringNumber || '',
          hen?.ringNumber || '',
          c.clutchNumber,
          c.nestBoxNumber,
          c.status,
          egg.eggNumber,
          egg.laidDate,
          egg.expectedHatchDate,
          egg.actualHatchDate || '',
          egg.candlingStatus,
          egg.bandingRingAssigned || ''
        ]);
      });
    });

    downloadCsv(`breeding_clutches_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
  };

  // 3. Export Health Logs CSV
  const handleExportHealthCsv = () => {
    const headers = [
      'Date',
      'Bird Ring Number',
      'Event Category',
      'Title',
      'Description',
      'Veterinarian / Handler',
      'Weight (g)',
      'Next Due Date'
    ];

    const rows = healthRecords.map(h => [
      h.date,
      h.birdRingNumber,
      h.recordType,
      h.title,
      h.description,
      h.veterinarian || '',
      h.weightGrams || '',
      h.nextDueDate || ''
    ]);

    downloadCsv(`health_medical_logs_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
  };

  // 4. Export Complete Combined Master CSV
  const handleExportAllInOneCsv = () => {
    const headers = [
      'Record Type',
      'Identifier / Ring',
      'Secondary ID / Pair',
      'Category / Species',
      'Status / Outcome',
      'Date',
      'Details / Mutation',
      'Notes'
    ];

    const rows: (string | number)[][] = [];

    // Add birds
    birds.forEach(b => {
      rows.push([
        'BIRD',
        b.ringNumber,
        b.name,
        b.species,
        b.status,
        b.hatchDate,
        `${b.sex} · ${b.dnaStatus} · ${b.mutationDescription}`,
        `Sire: ${b.fatherRing || 'N/A'} × Dam: ${b.motherRing || 'N/A'}`
      ]);
    });

    // Add clutches
    clutches.forEach(c => {
      const pair = pairs.find(p => p.id === c.pairId);
      c.eggs.forEach(egg => {
        rows.push([
          'CLUTCH_EGG',
          egg.id,
          pair?.pairName || c.pairId,
          `Egg #${egg.eggNumber}`,
          egg.candlingStatus,
          egg.laidDate,
          `Hatch: ${egg.actualHatchDate || egg.expectedHatchDate}`,
          `Banded: ${egg.bandingRingAssigned || 'Pending'}`
        ]);
      });
    });

    // Add health
    healthRecords.forEach(h => {
      rows.push([
        'HEALTH_LOG',
        h.birdRingNumber,
        h.title,
        h.recordType,
        h.status,
        h.date,
        h.description,
        h.veterinarian || ''
      ]);
    });

    downloadCsv(`complete_aviary_master_backup_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
  };

  const handlePrintFullReport = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-base font-bold text-white">Export Aviary Data & Reports (PDF & CSV)</h3>
              <p className="text-xs text-slate-400">Download spreadsheet records or generate printable official aviary documents</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {downloadSuccess && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs rounded-lg flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{downloadSuccess}</span>
          </div>
        )}

        {/* Section 1: Official PDF Printable Report */}
        <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Official Aviary Certificate & Census (PDF Format)</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Formatted printable document with your custom logo ({config.aviaryName}), breeder signature, ring prefix ({config.societyRingPrefix}), and full flock census.
              </p>
            </div>
            <button
              onClick={handlePrintFullReport}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer shrink-0"
            >
              <Printer className="w-4 h-4 stroke-[2.5]" />
              <span>Print / Save as PDF</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex items-center gap-4">
            <span className="text-slate-300 font-medium">Included in PDF:</span>
            <span>• Master Logo & Header</span>
            <span>• {birds.length} Birds Census</span>
            <span>• Verified Breeder Signature</span>
          </div>
        </div>

        {/* Section 2: CSV Data Exports for Spreadsheets & Accounting */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              CSV Spreadsheet Exports (Excel / Sheets)
            </h4>
            <button
              onClick={handleExportAllInOneCsv}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Master All-in-One CSV</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {/* Flock Census CSV */}
            <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Full Flock Master Registry (.csv)</div>
                <div className="text-[11px] text-slate-400">
                  {birds.length} birds with ring numbers, DNA status, status, pedigree parents, mutation descriptions.
                </div>
              </div>
              <button
                onClick={handleExportFlockCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded text-xs font-medium cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>
            </div>

            {/* Breeding Clutches CSV */}
            <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Breeding Clutches & Egg Incubator (.csv)</div>
                <div className="text-[11px] text-slate-400">
                  {clutches.length} clutches, egg candling logs, expected/actual hatch dates, assigned band numbers.
                </div>
              </div>
              <button
                onClick={handleExportBreedingCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded text-xs font-medium cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>
            </div>

            {/* Health & Vet CSV */}
            <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Health & Medical History (.csv)</div>
                <div className="text-[11px] text-slate-400">
                  {healthRecords.length} medical events, vaccinations, deworming cycles, weight checks.
                </div>
              </div>
              <button
                onClick={handleExportHealthCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded text-xs font-medium cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
