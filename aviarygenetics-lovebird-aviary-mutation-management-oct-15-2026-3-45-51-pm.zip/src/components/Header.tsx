import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Cloud, 
  CloudOff, 
  RefreshCw, 
  Settings, 
  User, 
  Plus, 
  Menu, 
  X,
  FileText
} from 'lucide-react';
import { useAviary } from '../context/AviaryContext';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenSettings: () => void;
  onOpenAuth: () => void;
  onOpenAddBird: () => void;
  onOpenExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  onOpenSettings,
  onOpenAuth,
  onOpenAddBird,
  onOpenExport,
}) => {
  const { 
    config, 
    session, 
    isOnline, 
    isSyncing, 
    syncCloudData, 
    logoutMaster, 
    reminders 
  } = useAviary();

  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', enabled: config.enabledModules.dashboard },
    { id: 'flock', label: 'Flock', enabled: config.enabledModules.flock },
    { id: 'breeding', label: 'Breeding & Clutches', enabled: config.enabledModules.breeding },
    { id: 'genetics', label: 'Genetics Engine', enabled: config.enabledModules.genetics },
    { id: 'pedigree', label: 'Pedigree Lineage', enabled: config.enabledModules.pedigree },
    { id: 'feeding', label: 'Feeding', enabled: config.enabledModules.feeding },
    { id: 'health', label: 'Health & Vet', enabled: config.enabledModules.health },
  ].filter(item => item.enabled);

  const handleSync = async () => {
    await syncCloudData();
  };

  return (
    <header className="no-print sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
      {/* Strict 3-Zone Top Bar Contract: Brand - 4-5 Nav Links - 1 Primary Action Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single Brand Lockup Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg overflow-hidden bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center shrink-0">
            {config.logoUrl ? (
              <img 
                src={config.logoUrl} 
                alt={`${config.aviaryName} logo`} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            )}
          </div>
          <button 
            onClick={() => setCurrentTab('dashboard')}
            className="text-left group cursor-pointer focus-visible:outline-none"
          >
            <span className="text-base font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors whitespace-nowrap">
              {config.aviaryName}
            </span>
            <div className="text-[11px] text-slate-400 font-medium tracking-wide">
              {config.societyRingPrefix} · {config.breederName}
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single Line, Desktop) */}
        <nav className="hidden lg:flex items-center gap-6">
          {navItems.map(item => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`text-sm font-medium transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                  isActive 
                    ? 'text-emerald-400 font-semibold border-b-2 border-emerald-500' 
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Controls Area */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Cloud Sync Status Indicator */}
          <button
            onClick={handleSync}
            disabled={isSyncing}
            title={isOnline ? 'Online - Click to sync with cloud backup' : 'Offline - Storing locally in aviary'}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium border border-slate-800 bg-slate-900/80 text-slate-300 hover:border-slate-700 transition-colors cursor-pointer"
          >
            {isSyncing ? (
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            ) : isOnline ? (
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <CloudOff className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="font-mono text-[11px]">
              {isSyncing ? 'Syncing...' : isOnline ? 'Cloud Synced' : 'Offline Mode'}
            </span>
          </button>

          {/* Master Admin Lock Badge */}
          {session.isMasterLoggedIn ? (
            <button
              onClick={logoutMaster}
              title="Master Mode Unlocked. Click to lock."
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 transition-colors cursor-pointer"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Master Active</span>
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              title="Click to unlock Master Admin mode"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200 transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Master Lock</span>
            </button>
          )}

          {/* Export Report PDF / CSV */}
          <button
            onClick={onOpenExport}
            title="Export Aviary Reports & Pedigree PDF"
            className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
          >
            <FileText className="w-4 h-4" />
          </button>

          {/* Aviary Settings Modal */}
          <button
            onClick={onOpenSettings}
            title="Aviary & Module Settings"
            className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* User Auth Profile */}
          <button
            onClick={onOpenAuth}
            title={session.userIdentifier || 'Breeder Account'}
            className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
          >
            <User className="w-4 h-4" />
          </button>

          {/* Primary Quick CTA: Add Bird */}
          <button
            onClick={onOpenAddBird}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-sm"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Add Bird</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-md text-slate-400 hover:text-white cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-950 px-4 py-3 space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => {
                setCurrentTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentTab === item.id
                  ? 'bg-emerald-500/10 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 px-3">
            <span>{isOnline ? 'Online Synced' : 'Offline Mode'}</span>
            <button onClick={handleSync} className="text-emerald-400 font-medium">Sync Now</button>
          </div>
        </div>
      )}
    </header>
  );
};
