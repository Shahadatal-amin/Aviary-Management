import React, { useState, useEffect } from 'react';
import { 
  X, 
  Dna, 
  Upload, 
  Heart, 
  Sparkles, 
  Check, 
  HelpCircle, 
  Info,
  Calendar,
  Tag
} from 'lucide-react';
import { Bird, BirdSex, BirdStatus, DnaStatus, LovebirdSpecies } from '../types/aviary';
import { useAviary } from '../context/AviaryContext';

interface AddBirdLovebirdGeneticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialBird?: Bird | null;
  defaultPairId?: string;
}

// 9 Recognized Agapornis Lovebird Species
export const LOVEBIRD_SPECIES_LIST: { id: LovebirdSpecies; commonName: string; scientificName: string }[] = [
  { id: 'Agapornis roseicollis (Peach-faced)', commonName: 'Peach-faced Lovebird', scientificName: 'Agapornis roseicollis' },
  { id: 'Agapornis fischeri (Fischer\'s)', commonName: 'Fischer\'s Lovebird', scientificName: 'Agapornis fischeri' },
  { id: 'Agapornis personatus (Masked)', commonName: 'Yellow-collared / Black-masked Lovebird', scientificName: 'Agapornis personatus' },
  { id: 'Agapornis lilianae (Nyasa)', commonName: 'Lilian\'s / Nyasa Lovebird', scientificName: 'Agapornis lilianae' },
  { id: 'Agapornis nigrigenis (Black-cheeked)', commonName: 'Black-cheeked Lovebird', scientificName: 'Agapornis nigrigenis' },
  { id: 'Agapornis canus (Madagascar)', commonName: 'Grey-headed / Madagascar Lovebird', scientificName: 'Agapornis canus' },
  { id: 'Agapornis taranta (Abyssinian)', commonName: 'Black-winged / Abyssinian Lovebird', scientificName: 'Agapornis taranta' },
  { id: 'Agapornis pullarius (Red-headed)', commonName: 'Red-headed / Red-faced Lovebird', scientificName: 'Agapornis pullarius' },
  { id: 'Agapornis swindernianus (Black-collared)', commonName: 'Black-collared Lovebird', scientificName: 'Agapornis swindernianus' },
];

export type MutationGeneState = 'none' | 'visual' | 'split' | 'possible_split';

interface MutationGeneDef {
  key: string;
  label: string;
  category: 'species_modifier' | 'sex_linked' | 'autosomal_recessive' | 'dominant';
  visualText: string;
  splitText: string;
  possibleSplitText: string;
  sexLinkedOnlyMaleSplit?: boolean;
}

const MUTATION_GENES: MutationGeneDef[] = [
  // 1. Blue Locus Alleles & Splits (exact requirement)
  {
    key: 'blue1',
    label: 'Blue 1 (Aqua Allele)',
    category: 'autosomal_recessive',
    visualText: 'Blue 1',
    splitText: '/Blue 1',
    possibleSplitText: '//Blue 1',
  },
  {
    key: 'blue2',
    label: 'Blue 2 (Turquoise Allele)',
    category: 'autosomal_recessive',
    visualText: 'Blue 2',
    splitText: '/Blue 2',
    possibleSplitText: '//Blue 2',
  },
  {
    key: 'parblue_b1b2',
    label: 'Parblue B1B2 (AquaTurquoise)',
    category: 'autosomal_recessive',
    visualText: 'Parblue B1B2',
    splitText: '/B1B2',
    possibleSplitText: '//B1B2',
  },
  // 2. Species Modifiers / Interspecies
  {
    key: 'fischer',
    label: 'Fischer (Eye-Ring Introgressed)',
    category: 'species_modifier',
    visualText: 'fischer',
    splitText: '/fischer',
    possibleSplitText: '//fischer',
  },
  {
    key: 'personatus',
    label: 'Personatus (Masked Introgressed)',
    category: 'species_modifier',
    visualText: 'personatus',
    splitText: '/personatus',
    possibleSplitText: '//personatus',
  },
  // 3. Sex-Linked Recessive Mutations
  {
    key: 'opaline',
    label: 'Opaline',
    category: 'sex_linked',
    visualText: 'opaline',
    splitText: '/opaline',
    possibleSplitText: '//opaline',
    sexLinkedOnlyMaleSplit: true,
  },
  {
    key: 'ino',
    label: 'Ino (Lutino / Albino)',
    category: 'sex_linked',
    visualText: 'ino',
    splitText: '/ino',
    possibleSplitText: '//ino',
    sexLinkedOnlyMaleSplit: true,
  },
  {
    key: 'cinnamon',
    label: 'Cinnamon',
    category: 'sex_linked',
    visualText: 'cinnamon',
    splitText: '/cinnamon',
    possibleSplitText: '//cinnamon',
    sexLinkedOnlyMaleSplit: true,
  },
  {
    key: 'pallid',
    label: 'Pallid (Australian Cinnamon / Pastel)',
    category: 'sex_linked',
    visualText: 'pallid',
    splitText: '/pallid',
    possibleSplitText: '//pallid',
    sexLinkedOnlyMaleSplit: true,
  },
  // 4. Autosomal Recessive Mutations
  {
    key: 'orangeFaced',
    label: 'Orange-Faced',
    category: 'autosomal_recessive',
    visualText: 'orange-faced',
    splitText: '/orange-faced',
    possibleSplitText: '//orange-faced',
  },
  {
    key: 'marbled',
    label: 'Marbled (Australian Cinnamon)',
    category: 'autosomal_recessive',
    visualText: 'marbled',
    splitText: '/marbled',
    possibleSplitText: '//marbled',
  },
  {
    key: 'dilute',
    label: 'Dilute',
    category: 'autosomal_recessive',
    visualText: 'dilute',
    splitText: '/dilute',
    possibleSplitText: '//dilute',
  },
  {
    key: 'bronzeFallow',
    label: 'Bronze Fallow',
    category: 'autosomal_recessive',
    visualText: 'bronze fallow',
    splitText: '/bronze fallow',
    possibleSplitText: '//bronze fallow',
  },
  {
    key: 'paleFallow',
    label: 'Pale Fallow',
    category: 'autosomal_recessive',
    visualText: 'pale fallow',
    splitText: '/pale fallow',
    possibleSplitText: '//pale fallow',
  },
  {
    key: 'recessivePied',
    label: 'Recessive Pied',
    category: 'autosomal_recessive',
    visualText: 'recessive pied',
    splitText: '/recessive pied',
    possibleSplitText: '//recessive pied',
  },
  {
    key: 'slaty',
    label: 'Slaty',
    category: 'autosomal_recessive',
    visualText: 'slaty',
    splitText: '/slaty',
    possibleSplitText: '//slaty',
  },
  {
    key: 'pale',
    label: 'Pale',
    category: 'autosomal_recessive',
    visualText: 'pale',
    splitText: '/pale',
    possibleSplitText: '//pale',
  },
  {
    key: 'misty',
    label: 'Misty',
    category: 'autosomal_recessive',
    visualText: 'misty',
    splitText: '/misty',
    possibleSplitText: '//misty',
  },
  // 5. Dominant & Incomplete Dominant Mutations
  {
    key: 'euwing',
    label: 'Euwing (Wing Melanin Pattern)',
    category: 'dominant',
    visualText: 'euwing',
    splitText: 'SF euwing',
    possibleSplitText: 'DF euwing',
  },
  {
    key: 'mist',
    label: 'Mist',
    category: 'dominant',
    visualText: 'mist',
    splitText: 'SF mist',
    possibleSplitText: 'DF mist',
  },
  {
    key: 'dominantPied',
    label: 'Dominant Pied',
    category: 'dominant',
    visualText: 'dominant pied',
    splitText: 'SF dom pied',
    possibleSplitText: 'DF dom pied',
  },
  {
    key: 'edgedDilute',
    label: 'Edged Dilute (Spangle)',
    category: 'dominant',
    visualText: 'edged dilute',
    splitText: 'SF edged',
    possibleSplitText: 'DF edged',
  },
  {
    key: 'japanesePied',
    label: 'Japanese Pied (Clearflight)',
    category: 'dominant',
    visualText: 'japanese pied',
    splitText: 'SF jp pied',
    possibleSplitText: 'DF jp pied',
  },
  {
    key: 'mottled',
    label: 'Mottled',
    category: 'dominant',
    visualText: 'mottled',
    splitText: 'SF mottled',
    possibleSplitText: 'DF mottled',
  },
  {
    key: 'star',
    label: 'Star',
    category: 'dominant',
    visualText: 'star',
    splitText: 'SF star',
    possibleSplitText: 'DF star',
  },
];

export const AddBirdLovebirdGeneticsModal: React.FC<AddBirdLovebirdGeneticsModalProps> = ({
  isOpen,
  onClose,
  initialBird,
  defaultPairId,
}) => {
  const { birds, pairs, addBird, updateBird, config } = useAviary();

  // Step 1: Species Selection (lovebirdgenetics style)
  const [species, setSpecies] = useState<LovebirdSpecies>(
    initialBird?.species || 'Agapornis roseicollis (Peach-faced)'
  );

  // Sex selector (lovebirdgenetics breeder notation: 1.0 Cock, 0.1 Hen, 0.0.1 Unknown)
  const [sex, setSex] = useState<BirdSex>(initialBird?.sex || 'Cock');

  // Base Series
  const [baseColor, setBaseColor] = useState<'Green' | 'Blue 1' | 'Blue 2' | 'Parblue B1B2'>('Green');
  const [darkFactor, setDarkFactor] = useState<0 | 1 | 2>(0);
  const [violetFactor, setVioletFactor] = useState<0 | 1 | 2>(0);

  // Mutations dictionary: key -> 'none' | 'visual' | 'split' | 'possible_split'
  const [mutationStates, setMutationStates] = useState<Record<string, MutationGeneState>>({});

  // Aviary fields
  const [ringNumber, setRingNumber] = useState('');
  const [name, setName] = useState('');
  const [dnaStatus, setDnaStatus] = useState<DnaStatus>('Pending / Unknown');
  const [status, setStatus] = useState<BirdStatus>('Home Bred');
  const [cageNumber, setCageNumber] = useState('Flight Aviary 1');
  const [hatchDate, setHatchDate] = useState(new Date().toISOString().split('T')[0]);
  const [fatherRing, setFatherRing] = useState('');
  const [motherRing, setMotherRing] = useState('');
  const [weightGrams, setWeightGrams] = useState(50);
  const [photoUrl, setPhotoUrl] = useState('/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg');
  const [notes, setNotes] = useState('');
  const [selectedParentPairId, setSelectedParentPairId] = useState(defaultPairId || '');
  const [customMutationOverride, setCustomMutationOverride] = useState('');

  // Source & Finance fields
  const [breederName, setBreederName] = useState(initialBird?.breederName || config.aviaryName);
  const [sourceAviary, setSourceAviary] = useState(initialBird?.sourceAviary || '');
  const [loanTerms, setLoanTerms] = useState(initialBird?.loanTerms || '');
  const [purchasePrice, setPurchasePrice] = useState<number>(initialBird?.purchasePrice || 0);
  const [purchaseDate, setPurchaseDate] = useState<string>(initialBird?.purchaseDate || new Date().toISOString().split('T')[0]);
  const [soldPrice, setSoldPrice] = useState<number>(initialBird?.soldPrice || 0);
  const [soldDate, setSoldDate] = useState<string>(initialBird?.soldDate || new Date().toISOString().split('T')[0]);
  const [soldTo, setSoldTo] = useState<string>(initialBird?.soldTo || '');

  // Initialize or reset form
  useEffect(() => {
    if (initialBird) {
      setSpecies(initialBird.species);
      setSex(initialBird.sex);
      setRingNumber(initialBird.ringNumber);
      setName(initialBird.name);
      setDnaStatus(initialBird.dnaStatus);
      setStatus(initialBird.status);
      setCageNumber(initialBird.cageNumber);
      setHatchDate(initialBird.hatchDate);
      setFatherRing(initialBird.fatherRing || '');
      setMotherRing(initialBird.motherRing || '');
      setSelectedParentPairId(initialBird.parentPairId || '');
      setWeightGrams(initialBird.weightGrams || 50);
      setPhotoUrl(initialBird.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg');
      setNotes(initialBird.notes || '');
      setCustomMutationOverride(initialBird.mutationDescription);
      setBreederName(initialBird.breederName || config.aviaryName);
      setSourceAviary(initialBird.sourceAviary || '');
      setLoanTerms(initialBird.loanTerms || '');
      setPurchasePrice(initialBird.purchasePrice || 0);
      setPurchaseDate(initialBird.purchaseDate || initialBird.createdAt.split('T')[0]);
      setSoldPrice(initialBird.soldPrice || 0);
      setSoldDate(initialBird.soldDate || new Date().toISOString().split('T')[0]);
      setSoldTo(initialBird.soldTo || '');

      // Parse mutations if possible
      const desc = initialBird.mutationDescription.toLowerCase();
      const initialStates: Record<string, MutationGeneState> = {};
      MUTATION_GENES.forEach(g => {
        if (desc.includes(`//${g.key}`) || desc.includes(`// ${g.key}`)) {
          initialStates[g.key] = 'possible_split';
        } else if (desc.includes(`/${g.key}`) || desc.includes(`/ ${g.key}`)) {
          initialStates[g.key] = 'split';
        } else if (desc.includes(g.key) || desc.includes(g.label.toLowerCase())) {
          initialStates[g.key] = 'visual';
        }
      });
      setMutationStates(initialStates);
    } else {
      // New bird defaults
      const year = new Date().getFullYear();
      const count = birds.length + 1;
      setRingNumber(`${config.societyRingPrefix}-${String(count).padStart(3, '0')}`);
      setName('');
      setSpecies('Agapornis roseicollis (Peach-faced)');
      setSex('Cock');
      setDnaStatus('Pending / Unknown');
      setStatus('Home Bred');
      setCageNumber('Flight Aviary 1');
      setHatchDate(new Date().toISOString().split('T')[0]);
      setFatherRing('');
      setMotherRing('');
      setSelectedParentPairId(defaultPairId || '');
      setWeightGrams(50);
      setPhotoUrl('/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg');
      setNotes('');
      setMutationStates({ opaline: 'none', fischer: 'none' });
      setCustomMutationOverride('');
      setBreederName(config.aviaryName);
      setSourceAviary('');
      setLoanTerms('');
      setPurchasePrice(0);
      setPurchaseDate(new Date().toISOString().split('T')[0]);
      setSoldPrice(0);
      setSoldDate(new Date().toISOString().split('T')[0]);
      setSoldTo('');

      if (defaultPairId) {
        handleLinkParentPair(defaultPairId);
      }
    }
  }, [initialBird, defaultPairId, isOpen]);

  // Compute lovebirdgenetics.com formatted genetic formula string
  const computedGeneticFormula = React.useMemo(() => {
    if (customMutationOverride.trim()) {
      return customMutationOverride.trim();
    }

    const sexPrefix = sex === 'Cock' ? '1.0' : sex === 'Hen' ? '0.1' : '0.0.1';
    
    // Dark factor label
    const darkPrefix = darkFactor === 1 ? 'D ' : darkFactor === 2 ? 'DD ' : '';
    const violetPrefix = violetFactor === 1 ? 'SF Violet ' : violetFactor === 2 ? 'DF Violet ' : '';

    // Visuals list
    const visuals: string[] = [];
    const splits: string[] = [];
    const possibleSplits: string[] = [];

    MUTATION_GENES.forEach(gene => {
      const state = mutationStates[gene.key];
      if (state === 'visual') {
        visuals.push(gene.visualText);
      } else if (state === 'split') {
        splits.push(gene.splitText);
      } else if (state === 'possible_split') {
        possibleSplits.push(gene.possibleSplitText);
      }
    });

    const visualStr = visuals.join(' ');
    const splitStr = splits.join(' ');
    const possibleSplitStr = possibleSplits.join(' ');

    const parts = [
      sexPrefix,
      violetPrefix.trim(),
      darkPrefix.trim(),
      baseColor,
      visualStr,
      splitStr,
      possibleSplitStr
    ].filter(Boolean);

    return parts.join(' ').replace(/\s+/g, ' ').trim();
  }, [sex, baseColor, darkFactor, violetFactor, mutationStates, customMutationOverride]);

  // Set mutation state for a gene
  const handleSetMutationState = (key: string, state: MutationGeneState) => {
    setMutationStates(prev => {
      const curr = prev[key];
      // If clicking same state, toggle off to 'none'
      const nextState = curr === state ? 'none' : state;
      return { ...prev, [key]: nextState };
    });
    setCustomMutationOverride(''); // Reset override so live formula reflects choices
  };

  // Link to parent pair
  const handleLinkParentPair = (pairId: string) => {
    setSelectedParentPairId(pairId);
    if (!pairId) return;

    const pair = pairs.find(p => p.id === pairId);
    if (pair) {
      const cock = birds.find(b => b.id === pair.cockBirdId);
      const hen = birds.find(b => b.id === pair.henBirdId);

      setFatherRing(cock?.ringNumber || '');
      setMotherRing(hen?.ringNumber || '');
      setCageNumber(pair.cageNumber);
      setStatus('Home Bred');
    }
  };

  // Photo upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const result = evt.target?.result as string;
      setPhotoUrl(result);
    };
    reader.readAsDataURL(file);
  };

  // Save handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ringNumber.trim()) return;

    const birdData = {
      ringNumber: ringNumber.trim(),
      name: name.trim() || ringNumber.trim(),
      species,
      sex,
      dnaStatus,
      status,
      mutationDescription: computedGeneticFormula,
      hatchDate,
      cageNumber,
      photoUrl,
      fatherRing,
      motherRing,
      parentPairId: (status === 'Home Bred' || status === 'Breeding Pair') ? selectedParentPairId : undefined,
      weightGrams,
      breederName: status === 'Home Bred' ? config.aviaryName : (breederName.trim() || config.aviaryName),
      sourceAviary: (status === 'Purchased' || status === 'Loan') ? sourceAviary.trim() : undefined,
      loanTerms: status === 'Loan' ? loanTerms.trim() : undefined,
      purchasePrice: status === 'Purchased' ? Number(purchasePrice) || 0 : undefined,
      purchaseDate: status === 'Purchased' ? purchaseDate : undefined,
      soldPrice: status === 'Sold' ? Number(soldPrice) || 0 : undefined,
      soldDate: status === 'Sold' ? soldDate : undefined,
      soldTo: status === 'Sold' ? soldTo.trim() : undefined,
      notes,
    };

    if (initialBird) {
      updateBird(initialBird.id, birdData);
    } else {
      addBird(birdData);
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto p-5 sm:p-7 space-y-6 shadow-2xl my-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Dna className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>{initialBird ? 'Edit Bird Record' : 'Add Bird — LovebirdGenetics Standard Layout'}</span>
              </h2>
              <p className="text-xs text-slate-400">
                Species selection, mutation selector (visual, split /, possible split //), and official aviary registry
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* STEP 1: CHOOSE BIRD SPECIES (Exact as used on lovebirdgenetics.com) */}
          <div className="space-y-3 p-4 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-2">
                <span>01. Select Bird Species (Agapornis)</span>
              </label>
              <span className="text-[11px] text-slate-400 font-mono">lovebirdgenetics.com standard</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-1">
              {LOVEBIRD_SPECIES_LIST.map(sp => {
                const isSelected = species === sp.id;
                return (
                  <button
                    type="button"
                    key={sp.id}
                    onClick={() => setSpecies(sp.id)}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-950/70 border-emerald-500 text-white shadow-md'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold">{sp.commonName}</div>
                    <div className="text-[11px] text-slate-400 italic font-serif">{sp.scientificName}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 2: SEX & GENETICS ENGINE (fischer, opaline, /opaline, //opaline, ino, etc.) */}
          <div className="space-y-4 p-4 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <label className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-2">
                <span>02. Choose Genetics & Mutations (Visual, /Split, //Possible Split)</span>
              </label>
              <span className="text-[11px] text-slate-400">fischer · opaline · /opaline · //opaline</span>
            </div>

            {/* Sex Selector (Breeder notation: 1.0 Cock, 0.1 Hen, 0.0.1 Unknown) */}
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-300">Sex Specification (Breeder Notation):</span>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setSex('Cock')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold text-center transition-all cursor-pointer ${
                    sex === 'Cock'
                      ? 'bg-blue-950 border-blue-500 text-blue-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  1.0 Cock (Male ZZ)
                </button>
                <button
                  type="button"
                  onClick={() => setSex('Hen')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold text-center transition-all cursor-pointer ${
                    sex === 'Hen'
                      ? 'bg-rose-950 border-rose-500 text-rose-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  0.1 Hen (Female ZW)
                </button>
                <button
                  type="button"
                  onClick={() => setSex('Unknown')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold text-center transition-all cursor-pointer ${
                    sex === 'Unknown'
                      ? 'bg-slate-800 border-slate-600 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  0.0.1 Unknown / Unsexed
                </button>
              </div>
            </div>

            {/* Base Series & Dark / Violet Factors */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Base Color Series</label>
                <select
                  value={baseColor}
                  onChange={e => setBaseColor(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Green">Green (Wildtype)</option>
                  <option value="Blue 1">Blue 1 (Aqua)</option>
                  <option value="Blue 2">Blue 2 (Turquoise / Whitefaced)</option>
                  <option value="Parblue B1B2">Parblue B1B2 (AquaTurquoise)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Dark Factor (D)</label>
                <select
                  value={darkFactor}
                  onChange={e => setDarkFactor(Number(e.target.value) as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0D - Normal</option>
                  <option value={1}>1D - Dark Green / Cobalt</option>
                  <option value={2}>2D - Olive / Mauve</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Violet Factor (V)</label>
                <select
                  value={violetFactor}
                  onChange={e => setVioletFactor(Number(e.target.value) as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value={0}>0V - None</option>
                  <option value={1}>1V - SF Single Violet</option>
                  <option value={2}>2V - DF Double Violet</option>
                </select>
              </div>
            </div>

            {/* Mutations Grid with Visual, Split (/), Possible Split (//) states */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
                <span>Select Mutations & Carrier Status:</span>
                <span className="text-[11px] text-slate-500 font-normal">Click any state to toggle</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto pr-1">
                {MUTATION_GENES.map(gene => {
                  const state = mutationStates[gene.key] || 'none';
                  const isHenSexLinked = sex === 'Hen' && gene.category === 'sex_linked';

                  return (
                    <div
                      key={gene.key}
                      className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium text-slate-200 truncate">{gene.label}</div>
                      </div>

                      {/* 3 Buttons per mutation: Visual, Split (/), Possible Split (//) */}
                      <div className="flex items-center gap-1 shrink-0 font-mono text-[11px]">
                        {/* Visual */}
                        <button
                          type="button"
                          onClick={() => handleSetMutationState(gene.key, 'visual')}
                          className={`px-2 py-1 rounded border transition-colors cursor-pointer ${
                            state === 'visual'
                              ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                              : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                          }`}
                          title={`Visual expression of ${gene.visualText}`}
                        >
                          {gene.visualText}
                        </button>

                        {/* Split (/) */}
                        <button
                          type="button"
                          disabled={isHenSexLinked}
                          onClick={() => handleSetMutationState(gene.key, 'split')}
                          className={`px-2 py-1 rounded border transition-colors cursor-pointer ${
                            state === 'split'
                              ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                              : isHenSexLinked 
                              ? 'bg-slate-950/40 text-slate-600 border-transparent cursor-not-allowed'
                              : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                          }`}
                          title={isHenSexLinked ? 'Females cannot be split for sex-linked traits' : `Confirmed split carrier ${gene.splitText}`}
                        >
                          {gene.splitText}
                        </button>

                        {/* Possible Split (//) */}
                        <button
                          type="button"
                          disabled={isHenSexLinked}
                          onClick={() => handleSetMutationState(gene.key, 'possible_split')}
                          className={`px-2 py-1 rounded border transition-colors cursor-pointer ${
                            state === 'possible_split'
                              ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                              : isHenSexLinked
                              ? 'bg-slate-950/40 text-slate-600 border-transparent cursor-not-allowed'
                              : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                          }`}
                          title={isHenSexLinked ? 'Females cannot be split for sex-linked traits' : `Possible carrier ${gene.possibleSplitText}`}
                        >
                          {gene.possibleSplitText}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Live Genetic Formula Output Bar (lovebirdgenetics.com format) */}
            <div className="p-3 bg-slate-900 rounded-lg border border-emerald-500/40 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-emerald-400 font-mono font-bold uppercase">Generated Genetic Formula:</span>
                <span className="text-slate-500">lovebirdgenetics notation</span>
              </div>
              <div className="font-mono text-sm font-bold text-white tracking-wide bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
                {computedGeneticFormula}
              </div>
            </div>
          </div>

          {/* STEP 3: USUAL AVIARY REGISTRY (Ring No, Parentage, DNA, etc.) */}
          <div className="space-y-4 p-4 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <label className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-2">
                <span>03. Usual Aviary Record Details</span>
              </label>
              <span className="text-[11px] text-slate-400">Ring number · Parentage · Lineage</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Ring / Band Number *
                </label>
                <input
                  type="text"
                  required
                  value={ringNumber}
                  onChange={e => setRingNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  placeholder="e.g. ACL-2026-001"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Bird Name / Identifier
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="e.g. Zephyr, Jade Crown"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  DNA Certification Status
                </label>
                <select
                  value={dnaStatus}
                  onChange={e => setDnaStatus(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="DNA Certified Male">DNA Certified Male</option>
                  <option value="DNA Certified Female">DNA Certified Female</option>
                  <option value="Sex-Linked Confirmed">Sex-Linked Confirmed</option>
                  <option value="Breeding Proven">Breeding Proven</option>
                  <option value="Pending / Unknown">Pending / Unknown</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Status *
                </label>
                <select
                  value={status}
                  onChange={e => {
                    const newSt = e.target.value as BirdStatus;
                    setStatus(newSt);
                    if (newSt === 'Home Bred') {
                      setBreederName(config.aviaryName);
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="Home Bred">Home Bred</option>
                  <option value="Purchased">Purchased</option>
                  <option value="Loan">Loan</option>
                  <option value="Sold">Sold</option>
                  <option value="Breeding Pair">Breeding Pair</option>
                  <option value="Quarantine">Quarantine</option>
                  <option value="Deceased">Deceased</option>
                </select>
              </div>

              {/* Conditional 1: If Home Bred (or Breeding Pair) is selected, show parent linkage option */}
              {(status === 'Home Bred' || status === 'Breeding Pair') && (
                <div className="sm:col-span-2 p-3.5 bg-slate-900 rounded-xl border border-emerald-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                      <Heart className="w-4 h-4 text-emerald-400" />
                      <span>Parent Linkage (Home-Bred Lineage Tracking)</span>
                    </label>
                    <span className="text-[11px] text-slate-400">Auto-fills Sire and Dam rings from pair</span>
                  </div>

                  <select
                    value={selectedParentPairId}
                    onChange={e => handleLinkParentPair(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="">Select Parent Pair (Optional)...</option>
                    {pairs.map(p => {
                      const cock = birds.find(b => b.id === p.cockBirdId);
                      const hen = birds.find(b => b.id === p.henBirdId);
                      return (
                        <option key={p.id} value={p.id}>
                          {p.pairName} (Sire: {cock?.ringNumber} × Dam: {hen?.ringNumber})
                        </option>
                      );
                    })}
                  </select>

                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Sire (Father) Ring:</span>
                      <input
                        type="text"
                        value={fatherRing}
                        onChange={e => setFatherRing(e.target.value)}
                        placeholder="e.g. ACL-2024-001"
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Dam (Mother) Ring:</span>
                      <input
                        type="text"
                        value={motherRing}
                        onChange={e => setMotherRing(e.target.value)}
                        placeholder="e.g. ACL-2024-002"
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Conditional 2: If Purchased or Loan is selected, show breeder name and aviary option */}
              {(status === 'Purchased' || status === 'Loan') && (
                <div className="sm:col-span-2 p-3.5 bg-slate-900 rounded-xl border border-blue-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-blue-300 flex items-center gap-1.5">
                      <Tag className="w-4 h-4 text-blue-400" />
                      <span>{status === 'Loan' ? 'Breeding Loan & Aviary Source' : 'Acquisition Source & Aviary Details'}</span>
                    </label>
                    <span className="text-[11px] text-slate-400">Breeder & source facility origin</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Breeder Name *
                      </label>
                      <input
                        type="text"
                        value={breederName}
                        onChange={e => setBreederName(e.target.value)}
                        placeholder="e.g. Dr. Luc Van Eyck"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Source Aviary *
                      </label>
                      <input
                        type="text"
                        value={sourceAviary}
                        onChange={e => setSourceAviary(e.target.value)}
                        placeholder="e.g. Van Eyck Belgian Stud, Belgium"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  {status === 'Loan' && (
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Loan Terms & Duration
                      </label>
                      <input
                        type="text"
                        value={loanTerms}
                        onChange={e => setLoanTerms(e.target.value)}
                        placeholder="e.g. On breeding loan for Season 2026; 50% chick split; return by Dec 2026"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Conditional 3: For Purchase, add amount tab to adjust finance */}
              {status === 'Purchased' && (
                <div className="sm:col-span-2 p-3.5 bg-slate-900 rounded-xl border border-amber-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Finance Adjustment: Acquisition Cost</span>
                    </label>
                    <span className="text-[11px] text-emerald-400 font-mono">Syncs to Finance Ledger</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Purchase Amount ({config.currencySymbol}) *
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={purchasePrice || ''}
                        onChange={e => setPurchasePrice(parseFloat(e.target.value) || 0)}
                        placeholder="e.g. 450.00"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Purchase / Acquisition Date
                      </label>
                      <input
                        type="date"
                        value={purchaseDate}
                        onChange={e => setPurchaseDate(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Conditional 4: For Sale, add amount tab to adjust finance */}
              {status === 'Sold' && (
                <div className="sm:col-span-2 p-3.5 bg-slate-900 rounded-xl border border-emerald-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>Finance Adjustment: Sale Revenue</span>
                    </label>
                    <span className="text-[11px] text-emerald-400 font-mono">Syncs to Finance Ledger</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Sale Amount ({config.currencySymbol}) *
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={soldPrice || ''}
                        onChange={e => setSoldPrice(parseFloat(e.target.value) || 0)}
                        placeholder="e.g. 320.00"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Sold To (Buyer Name / Aviary)
                      </label>
                      <input
                        type="text"
                        value={soldTo}
                        onChange={e => setSoldTo(e.target.value)}
                        placeholder="e.g. Clara Beaumont"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Date Sold
                      </label>
                      <input
                        type="date"
                        value={soldDate}
                        onChange={e => setSoldDate(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Hatch Date
                </label>
                <input
                  type="date"
                  value={hatchDate}
                  onChange={e => setHatchDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Cage / Flight Location
                </label>
                <input
                  type="text"
                  value={cageNumber}
                  onChange={e => setCageNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="e.g. Flight 1, Cage B-04"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Weight (Grams)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={weightGrams}
                  onChange={e => setWeightGrams(parseFloat(e.target.value) || 50)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Photograph (Custom Upload or Asset)
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-lg text-xs cursor-pointer">
                    <Upload className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Upload Image</span>
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                  <span className="text-[11px] text-slate-500 truncate">Stored locally</span>
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Breeder Notes
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  placeholder="Lineage pedigree notes, show awards, exhibition traits..."
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer shadow-lg"
            >
              {initialBird ? 'Update Bird Record' : 'Register Bird to Aviary'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
