import React, { useState } from 'react';
import { 
  X, 
  Settings, 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Cloud, 
  Download, 
  Upload, 
  RefreshCw, 
  Check, 
  AlertCircle,
  Image as ImageIcon,
  Palette,
  Sliders
} from 'lucide-react';
import { useAviary } from '../context/AviaryContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenMasterAuth: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenMasterAuth,
}) => {
  const { 
    config, 
    updateConfig, 
    session, 
    syncCloudData, 
    isSyncing, 
    lastSyncTime, 
    exportAviaryDataJson, 
    importAviaryDataJson, 
    resetToDemoData 
  } = useAviary();

  const [formData, setFormData] = useState({
    aviaryName: config.aviaryName,
    breederName: config.breederName,
    societyRingPrefix: config.societyRingPrefix,
    logoUrl: config.logoUrl,
    contactEmail: config.contactEmail,
    contactPhone: config.contactPhone,
    location: config.location,
    currencySymbol: config.currencySymbol,
  });

  const [modules, setModules] = useState(config.enabledModules);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>(config.logoUrl);

  if (!isOpen) return null;

  // Handle local logo file upload (Data URL)
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const result = evt.target?.result as string;
      setLogoPreview(result);
      setFormData(prev => ({ ...prev, logoUrl: result }));
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!session.isMasterLoggedIn) {
      alert('Master Admin credentials required to modify aviary identity and module configuration.');
      onOpenMasterAuth();
      return;
    }

    updateConfig({
      ...formData,
      logoUrl: logoPreview,
      enabledModules: modules,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleExportJson = () => {
    const dataStr = exportAviaryDataJson();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aviary_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const content = evt.target?.result as string;
      const success = importAviaryDataJson(content);
      if (success) {
        setImportStatus('Aviary backup restored successfully!');
      } else {
        setImportStatus('Invalid JSON backup file.');
      }
      setTimeout(() => setImportStatus(null), 4000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Settings className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold text-white">Aviary Customization & Settings</h2>
              <p className="text-xs text-slate-400">Custom aviary name, logo upload, UI preferences, and cloud sync</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Login Lock Status Banner */}
        <div className={`p-3.5 rounded-lg border flex items-center justify-between text-xs ${
          session.isMasterLoggedIn 
            ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' 
            : 'bg-amber-950/40 border-amber-500/40 text-amber-300'
        }`}>
          <div className="flex items-center gap-2">
            {session.isMasterLoggedIn ? (
              <Unlock className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span>
              {session.isMasterLoggedIn
                ? 'Master Mode Unlocked. You have full administrative permission to modify aviary branding & modules.'
                : 'Master Mode Locked. Title and menu customization is guarded.'}
            </span>
          </div>

          {!session.isMasterLoggedIn && (
            <button
              onClick={onOpenMasterAuth}
              className="px-3 py-1 bg-amber-500 text-slate-950 font-bold rounded hover:bg-amber-400 shrink-0 cursor-pointer"
            >
              Unlock Master
            </button>
          )}
        </div>

        {saveSuccess && (
          <div className="p-3 bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs rounded-lg flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>Aviary configuration updated successfully!</span>
          </div>
        )}

        {importStatus && (
          <div className="p-3 bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg">
            {importStatus}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-5">
          
          {/* Section 1: Aviary Branding & Custom Logo Upload */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Aviary Identity & Custom Logo
            </h3>

            {/* Custom Logo Upload Box */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
              <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-900 border border-emerald-500/30 flex items-center justify-center shrink-0">
                {logoPreview ? (
                  <img src={logoPreview} alt="Aviary Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <ImageIcon className="w-8 h-8 text-slate-600" />
                )}
              </div>

              <div className="space-y-2 flex-1 text-center sm:text-left">
                <div className="text-xs font-bold text-white">Upload Custom Aviary Emblem / Logo</div>
                <p className="text-[11px] text-slate-400">
                  Select any PNG or JPG from your device. This logo appears in your top navigation and official PDF pedigree certificates.
                </p>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                  <label className={`flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-lg text-xs cursor-pointer ${
                    !session.isMasterLoggedIn ? 'opacity-50 pointer-events-none' : ''
                  }`}>
                    <Upload className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Upload Logo File</span>
                    <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                  </label>

                  <button
                    type="button"
                    disabled={!session.isMasterLoggedIn}
                    onClick={() => {
                      setLogoPreview('/src/assets/images/aviary_logo_crest_1792053492040.jpg');
                      setFormData(prev => ({ ...prev, logoUrl: '/src/assets/images/aviary_logo_crest_1792053492040.jpg' }));
                    }}
                    className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white rounded-lg text-xs"
                  >
                    Reset to Emblem
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Aviary Name *
                </label>
                <input
                  type="text"
                  required
                  disabled={!session.isMasterLoggedIn}
                  value={formData.aviaryName}
                  onChange={e => setFormData({ ...formData, aviaryName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white disabled:opacity-60"
                  placeholder="e.g. Aurora Crest Lovebird Aviary"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Master Breeder Name *
                </label>
                <input
                  type="text"
                  required
                  disabled={!session.isMasterLoggedIn}
                  value={formData.breederName}
                  onChange={e => setFormData({ ...formData, breederName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Society Ring Prefix (e.g. ACL-2026)
                </label>
                <input
                  type="text"
                  disabled={!session.isMasterLoggedIn}
                  value={formData.societyRingPrefix}
                  onChange={e => setFormData({ ...formData, societyRingPrefix: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Facility Location
                </label>
                <input
                  type="text"
                  disabled={!session.isMasterLoggedIn}
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Contact Email
                </label>
                <input
                  type="email"
                  disabled={!session.isMasterLoggedIn}
                  value={formData.contactEmail}
                  onChange={e => setFormData({ ...formData, contactEmail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Currency Symbol
                </label>
                <input
                  type="text"
                  disabled={!session.isMasterLoggedIn}
                  value={formData.currencySymbol}
                  onChange={e => setFormData({ ...formData, currencySymbol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono disabled:opacity-60"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Navigation Menu Module Customization */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Navigation Menu & Feature Customization
            </h3>
            <p className="text-xs text-slate-400">
              Toggle specific modules on or off to tailor the interface for your aviary workflow.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
              {Object.entries(modules).map(([modKey, isEnabled]) => (
                <label
                  key={modKey}
                  className={`p-2.5 rounded-lg border text-xs flex items-center justify-between cursor-pointer ${
                    isEnabled 
                      ? 'bg-slate-950 border-emerald-500/40 text-emerald-300' 
                      : 'bg-slate-950/40 border-slate-800 text-slate-500'
                  }`}
                >
                  <span className="capitalize">{modKey}</span>
                  <input
                    type="checkbox"
                    disabled={!session.isMasterLoggedIn}
                    checked={isEnabled}
                    onChange={e => setModules({ ...modules, [modKey]: e.target.checked })}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-0 disabled:opacity-50"
                  />
                </label>
              ))}
            </div>
          </div>

          {/* Section 3: Cloud Synchronization & Local Backups */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Cloud Synchronization & Mobile Backup
            </h3>

            <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-300 font-semibold">Cloud Sync Status:</span>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    Last snapshot: {lastSyncTime}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isSyncing}
                  onClick={() => syncCloudData()}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
                </button>
              </div>

              {/* JSON Backup & Restore */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportJson}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Download JSON Backup</span>
                  </button>

                  <label className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Restore JSON Backup</span>
                    <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
                  </label>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Reset aviary database back to default demonstration records?')) {
                      resetToDemoData();
                      onClose();
                    }
                  }}
                  className="text-xs text-rose-400 hover:text-rose-300"
                >
                  Reset Demo Data
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={!session.isMasterLoggedIn}
              className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg disabled:opacity-50 cursor-pointer"
            >
              Save Configuration
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
