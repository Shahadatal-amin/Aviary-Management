/**
 * Lovebird Genetics Calculation Engine
 * Based on authentic psittacine / Agapornis mutation genetics (as referenced on lovebirdgenetics.com)
 */

import { BirdGenotype, GeneticOutcome } from '../types/aviary';

export interface ParentGeneticsInput {
  baseColor: 'Green' | 'Blue 1' | 'Blue 2' | 'Parblue B1B2';
  darkFactor: 0 | 1 | 2; // 0=None, 1=Single Dark (D), 2=Double Dark (DD)
  violetFactor: 0 | 1 | 2; // 0=None, 1=SF, 2=DF
  // Interspecies modifiers (lovebirdgenetics.com)
  visualFischer?: boolean;
  splitFischer?: boolean;
  visualPersonatus?: boolean;
  splitPersonatus?: boolean;
  // Sex-linked (Visual)
  visualIno: boolean;
  visualCinnamon: boolean;
  visualOpaline: boolean;
  visualPallid: boolean;
  // Sex-linked (Splits - ONLY cocks can be split)
  splitIno?: boolean;
  splitCinnamon?: boolean;
  splitOpaline?: boolean;
  splitPallid?: boolean;
  // Autosomal Recessive (Visual)
  visualOrangeFaced?: boolean;
  visualMarbled?: boolean;
  visualDilute?: boolean;
  visualBronzeFallow?: boolean;
  visualPaleFallow?: boolean;
  visualRecessivePied?: boolean;
  visualSlaty?: boolean;
  // Autosomal Recessive (Splits)
  splitBlue1?: boolean;
  splitBlue2?: boolean;
  splitB1B2?: boolean;
  splitBlue?: boolean;
  splitOrangeFaced?: boolean;
  splitMarbled?: boolean;
  splitDilute?: boolean;
  splitBronzeFallow?: boolean;
  splitPaleFallow?: boolean;
  splitRecessivePied?: boolean;
  splitSlaty?: boolean;
  // Dominant traits
  dominantPied?: boolean;
  euwing?: boolean;
  mist?: boolean;
  edgedDilute?: boolean;
}

export interface PairingResult {
  sireSummary: string;
  damSummary: string;
  cockOutcomes: GeneticOutcome[];
  henOutcomes: GeneticOutcome[];
  overallSummary: string[];
}

/**
 * Determines visual color preview hex for lovebird mutation combinations
 */
export function getPlumageColorHex(
  base: string,
  dark: number,
  violet: number,
  isLutino: boolean,
  isOpaline: boolean,
  isCinnamon: boolean
): { primary: string; secondary?: string } {
  if (isLutino) {
    if (base === 'Green') return { primary: '#FACC15', secondary: '#EF4444' }; // Golden yellow + scarlet head
    return { primary: '#F8FAFC', secondary: '#FCA5A5' }; // Albino white
  }

  if (base === 'Green') {
    if (dark === 0 && violet === 0) return { primary: '#16A34A', secondary: '#F87171' }; // Wildtype emerald green + peach
    if (dark === 1 && violet === 0) return { primary: '#15803D', secondary: '#F87171' }; // Dark Green + peach
    if (dark === 2) return { primary: '#4D7C0F', secondary: '#EF4444' }; // Olive green
    if (violet > 0) return { primary: '#0D9488', secondary: '#F87171' }; // Green violet shimmer
  }

  if (base === 'Blue 1' || base === 'Aqua') {
    if (dark === 0) return { primary: '#06B6D4', secondary: '#FEF08A' }; // Pastel sea green / aqua
    if (dark === 1) return { primary: '#0284C7', secondary: '#F1F5F9' }; // Dark Aqua / Cobalt
    if (dark === 2) return { primary: '#64748B', secondary: '#F1F5F9' }; // Mauve
  }

  if (base === 'Blue 2' || base === 'Blue (Whitefaced)') {
    if (violet > 0) return { primary: '#7C3AED', secondary: '#FFFFFF' }; // Deep violet
    if (dark === 0) return { primary: '#38BDF8', secondary: '#FFFFFF' }; // Sky Blue 2
    if (dark === 1) return { primary: '#2563EB', secondary: '#FFFFFF' }; // Cobalt Blue 2
    if (dark === 2) return { primary: '#475569', secondary: '#FFFFFF' }; // Mauve
  }

  if (base === 'Parblue B1B2') {
    if (violet > 0 && dark >= 1) return { primary: '#6366F1', secondary: '#F1F5F9' }; // Violet Cobalt B1B2
    if (dark === 0) return { primary: '#0EA5E9', secondary: '#FEF9C3' }; // Parblue B1B2
    if (dark === 1) return { primary: '#1D4ED8', secondary: '#F1F5F9' }; // D Parblue B1B2
    if (dark === 2) return { primary: '#475569', secondary: '#F1F5F9' }; // DD Parblue B1B2
  }

  return { primary: '#16A34A', secondary: '#F87171' };
}

/**
 * Calculates Dark Factor inheritance distribution (Incomplete Dominance)
 */
function calculateDarkInheritance(sireD: number, damD: number): Array<{ factor: number; prob: number }> {
  // sire alleles: D=0 => (0,0), D=1 => (0,1), D=2 => (1,1)
  const sireAlleles = sireD === 0 ? [0, 0] : sireD === 1 ? [0, 1] : [1, 1];
  const damAlleles = damD === 0 ? [0, 0] : damD === 1 ? [0, 1] : [1, 1];

  const counts: Record<number, number> = { 0: 0, 1: 0, 2: 0 };
  for (const s of sireAlleles) {
    for (const d of damAlleles) {
      counts[s + d]++;
    }
  }

  const result: Array<{ factor: number; prob: number }> = [];
  for (const factorStr of Object.keys(counts)) {
    const f = Number(factorStr);
    if (counts[f] > 0) {
      result.push({ factor: f, prob: counts[f] / 4 });
    }
  }
  return result;
}

/**
 * Calculates Violet Factor inheritance (Autosomal Dominant / Incomplete Dominant)
 */
function calculateVioletInheritance(sireV: number, damV: number): Array<{ factor: number; prob: number }> {
  const sireAlleles = sireV === 0 ? [0, 0] : sireV === 1 ? [0, 1] : [1, 1];
  const damAlleles = damV === 0 ? [0, 0] : damV === 1 ? [0, 1] : [1, 1];

  const counts: Record<number, number> = { 0: 0, 1: 0, 2: 0 };
  for (const s of sireAlleles) {
    for (const d of damAlleles) {
      counts[s + d]++;
    }
  }

  return Object.keys(counts)
    .filter(k => counts[Number(k)] > 0)
    .map(k => ({ factor: Number(k), prob: counts[Number(k)] / 4 }));
}

/**
 * Calculates Sex-Linked inheritance for a specific gene (Ino, Cinnamon, Opaline, etc.)
 * Sire is Cock (ZZ), Dam is Hen (ZW)
 */
function calculateSexLinkedGene(
  sireVisual: boolean,
  sireSplit: boolean,
  damVisual: boolean,
  geneName: string
): {
  cockOutcomes: Array<{ visual: boolean; split: boolean; prob: number }>;
  henOutcomes: Array<{ visual: boolean; split: boolean; prob: number }>;
} {
  // Sire alleles: Visual (m, m), Split (m, +), Normal (+, +)
  const sireZ: string[] = sireVisual ? ['m', 'm'] : sireSplit ? ['m', '+'] : ['+', '+'];
  // Dam alleles: Visual (m, W), Normal (+, W) - Note: Hen has NO split
  const damZ = damVisual ? 'm' : '+';

  // Cock offspring receive one Z from sire, one Z from dam
  const cockCombinations: Array<{ visual: boolean; split: boolean }> = [];
  for (const s of sireZ) {
    const isVisual = s === 'm' && damZ === 'm';
    const isSplit = !isVisual && (s === 'm' || damZ === 'm');
    cockCombinations.push({ visual: isVisual, split: isSplit });
  }

  // Hen offspring receive one Z from sire, W from dam
  const henCombinations: Array<{ visual: boolean; split: boolean }> = [];
  for (const s of sireZ) {
    const isVisual = s === 'm';
    henCombinations.push({ visual: isVisual, split: false });
  }

  // Aggregate probabilities
  const aggCock: Record<string, number> = {};
  for (const c of cockCombinations) {
    const key = `${c.visual ? 'VISUAL' : 'NORMAL'}_${c.split ? 'SPLIT' : 'PURE'}`;
    aggCock[key] = (aggCock[key] || 0) + 1 / cockCombinations.length;
  }

  const aggHen: Record<string, number> = {};
  for (const h of henCombinations) {
    const key = `${h.visual ? 'VISUAL' : 'NORMAL'}`;
    aggHen[key] = (aggHen[key] || 0) + 1 / henCombinations.length;
  }

  return {
    cockOutcomes: Object.entries(aggCock).map(([key, prob]) => ({
      visual: key.startsWith('VISUAL'),
      split: key.endsWith('SPLIT'),
      prob,
    })),
    henOutcomes: Object.entries(aggHen).map(([key, prob]) => ({
      visual: key.startsWith('VISUAL'),
      split: false,
      prob,
    })),
  };
}

/**
 * Calculates Autosomal Recessive inheritance (e.g. Blue, Orange-faced, Dilute)
 */
function calculateAutosomalRecessive(
  sireVisual: boolean,
  sireSplit: boolean,
  damVisual: boolean,
  damSplit: boolean
): Array<{ visual: boolean; split: boolean; prob: number }> {
  const sireAlleles = sireVisual ? ['a', 'a'] : sireSplit ? ['a', 'A'] : ['A', 'A'];
  const damAlleles = damVisual ? ['a', 'a'] : damSplit ? ['a', 'A'] : ['A', 'A'];

  const combos: Array<{ visual: boolean; split: boolean }> = [];
  for (const s of sireAlleles) {
    for (const d of damAlleles) {
      if (s === 'a' && d === 'a') {
        combos.push({ visual: true, split: false });
      } else if (s === 'a' || d === 'a') {
        combos.push({ visual: false, split: true });
      } else {
        combos.push({ visual: false, split: false });
      }
    }
  }

  const agg: Record<string, number> = {};
  for (const c of combos) {
    const k = `${c.visual ? 'V' : 'N'}_${c.split ? 'S' : 'P'}`;
    agg[k] = (agg[k] || 0) + 0.25;
  }

  return Object.entries(agg).map(([k, prob]) => ({
    visual: k.startsWith('V'),
    split: k.endsWith('S'),
    prob,
  }));
}

/**
 * Master pairing prediction function for Lovebirds
 */
export function calculatePairingPredictions(
  sire: ParentGeneticsInput,
  dam: ParentGeneticsInput
): PairingResult {
  const darkOutcomes = calculateDarkInheritance(sire.darkFactor, dam.darkFactor);
  const violetOutcomes = calculateVioletInheritance(sire.violetFactor, dam.violetFactor);

  // Base color blue series (Autosomal Recessive: Blue 1, Blue 2, Parblue B1B2)
  const sireIsBlueSeries = sire.baseColor !== 'Green';
  const damIsBlueSeries = dam.baseColor !== 'Green';
  const sireSplitBlue = Boolean(sire.splitBlue1 || sire.splitBlue2 || sire.splitB1B2);
  const damSplitBlue = Boolean(dam.splitBlue1 || dam.splitBlue2 || dam.splitB1B2);

  const baseOutcomes = calculateAutosomalRecessive(
    sireIsBlueSeries,
    sireSplitBlue,
    damIsBlueSeries,
    damSplitBlue
  );

  // Sex-linked Ino & Opaline & Cinnamon
  const inoOutcomes = calculateSexLinkedGene(
    sire.visualIno,
    Boolean(sire.splitIno),
    dam.visualIno,
    'Ino'
  );

  const opalineOutcomes = calculateSexLinkedGene(
    sire.visualOpaline,
    Boolean(sire.splitOpaline),
    dam.visualOpaline,
    'Opaline'
  );

  const cinnamonOutcomes = calculateSexLinkedGene(
    sire.visualCinnamon,
    Boolean(sire.splitCinnamon),
    dam.visualCinnamon,
    'Cinnamon'
  );

  // Orange-faced autosomal recessive
  const ofOutcomes = calculateAutosomalRecessive(
    Boolean(sire.visualOrangeFaced),
    Boolean(sire.splitOrangeFaced),
    Boolean(dam.visualOrangeFaced),
    Boolean(dam.splitOrangeFaced)
  );

  // Determine split label for Blue locus
  const blueSplitLabel = sire.splitBlue1 || dam.splitBlue1 
    ? '/Blue 1' 
    : sire.splitBlue2 || dam.splitBlue2 
    ? '/Blue 2' 
    : sire.splitB1B2 || dam.splitB1B2 
    ? '/B1B2' 
    : '/Blue 1';

  // Build Cock Outcomes
  const rawCockOutcomes: GeneticOutcome[] = [];
  for (const b of baseOutcomes) {
    for (const d of darkOutcomes) {
      for (const v of violetOutcomes) {
        for (const ino of inoOutcomes.cockOutcomes) {
          for (const op of opalineOutcomes.cockOutcomes) {
            for (const cin of cinnamonOutcomes.cockOutcomes) {
              const combinedProb = b.prob * d.prob * v.prob * ino.prob * op.prob * cin.prob;
              if (combinedProb < 0.01) continue;

              const base = b.visual 
                ? (sire.baseColor !== 'Green' ? sire.baseColor : dam.baseColor !== 'Green' ? dam.baseColor : 'Blue 1') 
                : 'Green';
              const darkLabel = d.factor === 0 ? '' : d.factor === 1 ? (base === 'Green' ? 'Dark ' : 'Cobalt ') : (base === 'Green' ? 'Olive ' : 'Mauve ');
              const violetLabel = v.factor === 1 ? 'SF Violet ' : v.factor === 2 ? 'DF Violet ' : '';
              const inoLabel = ino.visual ? (base === 'Green' ? 'Lutino ' : 'Albino ') : '';
              const opalineLabel = op.visual ? 'Opaline ' : '';
              const cinLabel = cin.visual ? 'Cinnamon ' : '';

              let phenotypeName = `${violetLabel}${darkLabel}${inoLabel || ''}${opalineLabel}${cinLabel}${ino.visual ? '' : base}`;
              if (!phenotypeName.trim()) phenotypeName = 'Normal Green Wildtype';

              const splits: string[] = [];
              if (b.split) splits.push(blueSplitLabel);
              if (ino.split) splits.push('/opaline');
              if (op.split) splits.push('/ino');
              if (cin.split) splits.push('/cinnamon');

              const colors = getPlumageColorHex(base, d.factor, v.factor, ino.visual, op.visual, cin.visual);

              const notation = `ZZ · ${d.factor > 0 ? `D${d.factor}` : 'D+'} ${v.factor > 0 ? `V${v.factor}` : ''} ${b.visual ? 'bl/bl' : b.split ? 'bl+/bl' : 'bl+/bl+'}`;

              rawCockOutcomes.push({
                sex: 'Cock (Male)',
                percentage: combinedProb * 100,
                phenotypeName: phenotypeName.trim(),
                genotypeNotation: notation.trim(),
                colorHexPreview: colors.primary,
                secondaryColorHex: colors.secondary,
                splitGenes: splits,
              });
            }
          }
        }
      }
    }
  }

  // Build Hen Outcomes
  const rawHenOutcomes: GeneticOutcome[] = [];
  for (const b of baseOutcomes) {
    for (const d of darkOutcomes) {
      for (const v of violetOutcomes) {
        for (const ino of inoOutcomes.henOutcomes) {
          for (const op of opalineOutcomes.henOutcomes) {
            for (const cin of cinnamonOutcomes.henOutcomes) {
              const combinedProb = b.prob * d.prob * v.prob * ino.prob * op.prob * cin.prob;
              if (combinedProb < 0.01) continue;

              const base = b.visual 
                ? (sire.baseColor !== 'Green' ? sire.baseColor : dam.baseColor !== 'Green' ? dam.baseColor : 'Blue 1') 
                : 'Green';
              const darkLabel = d.factor === 0 ? '' : d.factor === 1 ? (base === 'Green' ? 'Dark ' : 'Cobalt ') : (base === 'Green' ? 'Olive ' : 'Mauve ');
              const violetLabel = v.factor === 1 ? 'SF Violet ' : v.factor === 2 ? 'DF Violet ' : '';
              const inoLabel = ino.visual ? (base === 'Green' ? 'Lutino ' : 'Albino ') : '';
              const opalineLabel = op.visual ? 'Opaline ' : '';
              const cinLabel = cin.visual ? 'Cinnamon ' : '';

              let phenotypeName = `${violetLabel}${darkLabel}${inoLabel || ''}${opalineLabel}${cinLabel}${ino.visual ? '' : base}`;
              if (!phenotypeName.trim()) phenotypeName = 'Normal Green Wildtype';

              const splits: string[] = [];
              if (b.split) splits.push(blueSplitLabel);
              // Hen CANNOT be split for sex-linked traits!

              const colors = getPlumageColorHex(base, d.factor, v.factor, ino.visual, op.visual, cin.visual);
              const notation = `ZW · ${d.factor > 0 ? `D${d.factor}` : 'D+'} ${v.factor > 0 ? `V${v.factor}` : ''} ${b.visual ? 'bl/bl' : b.split ? 'bl+/bl' : 'bl+/bl+'}`;

              rawHenOutcomes.push({
                sex: 'Hen (Female)',
                percentage: combinedProb * 100,
                phenotypeName: phenotypeName.trim(),
                genotypeNotation: notation.trim(),
                colorHexPreview: colors.primary,
                secondaryColorHex: colors.secondary,
                splitGenes: splits,
              });
            }
          }
        }
      }
    }
  }

  // Consolidate identical outcomes
  const consolidate = (outcomes: GeneticOutcome[]) => {
    const map = new Map<string, GeneticOutcome>();
    for (const item of outcomes) {
      const key = `${item.phenotypeName}__${item.splitGenes.sort().join(',')}`;
      if (map.has(key)) {
        map.get(key)!.percentage += item.percentage;
      } else {
        map.set(key, { ...item });
      }
    }
    return Array.from(map.values())
      .map(o => ({ ...o, percentage: Math.round(o.percentage * 10) / 10 }))
      .sort((a, b) => b.percentage - a.percentage);
  };

  const consolidatedCock = consolidate(rawCockOutcomes);
  const consolidatedHen = consolidate(rawHenOutcomes);

  // Format summaries
  const getBlueSplitText = (parent: ParentGeneticsInput) => {
    if (parent.splitBlue1) return ' / Blue 1';
    if (parent.splitBlue2) return ' / Blue 2';
    if (parent.splitB1B2) return ' / B1B2';
    if (parent.splitBlue) return ' / Blue';
    return '';
  };

  const sireFischerText = sire.visualFischer ? 'fischer ' : sire.splitFischer ? '/fischer ' : '';
  const sireSummary = `${sire.darkFactor === 1 ? '1D ' : sire.darkFactor === 2 ? '2D ' : ''}${sire.violetFactor > 0 ? 'Violet ' : ''}${sireFischerText}${sire.visualOpaline ? 'Opaline ' : ''}${sire.visualIno ? 'Lutino/Ino ' : ''}${sire.visualCinnamon ? 'Cinnamon ' : ''}${sire.baseColor}${sire.splitIno ? ' / Ino' : ''}${sire.splitOpaline ? ' / Opaline' : ''}${getBlueSplitText(sire)}`;

  const damFischerText = dam.visualFischer ? 'fischer ' : dam.splitFischer ? '/fischer ' : '';
  const damSummary = `${dam.darkFactor === 1 ? '1D ' : dam.darkFactor === 2 ? '2D ' : ''}${dam.violetFactor > 0 ? 'Violet ' : ''}${damFischerText}${dam.visualOpaline ? 'Opaline ' : ''}${dam.visualIno ? 'Lutino/Ino ' : ''}${dam.visualCinnamon ? 'Cinnamon ' : ''}${dam.baseColor}${getBlueSplitText(dam)}`;

  const summaryNotes: string[] = [];
  if (sire.visualIno || sire.splitIno) {
    if (!dam.visualIno) {
      summaryNotes.push('Sex-linked alert: Any visual Lutino/Ino chicks born from this pairing will strictly be Females (Hens).');
    }
  }
  if (sire.visualOpaline || sire.splitOpaline) {
    if (!dam.visualOpaline) {
      summaryNotes.push('Opaline alert: Visual Opaline offspring without an Opaline dam will guarantee female sex.');
    }
  }
  if (sire.darkFactor > 0 && dam.darkFactor > 0) {
    summaryNotes.push('Double dark factor potential: 25% of offspring will inherit 2 Dark genes (Olive / Mauve).');
  }

  return {
    sireSummary,
    damSummary,
    cockOutcomes: consolidatedCock,
    henOutcomes: consolidatedHen,
    overallSummary: summaryNotes,
  };
}
