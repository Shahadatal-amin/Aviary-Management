import React, { useState } from 'react';
import { AviaryProvider, useAviary } from './context/AviaryContext';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { FlockManager } from './components/FlockManager';
import { BreedingManager } from './components/BreedingManager';
import { GeneticsCalculator } from './components/GeneticsCalculator';
import { PedigreeTree } from './components/PedigreeTree';
import { FeedingManager } from './components/FeedingManager';
import { HealthManager } from './components/HealthManager';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';
import { ReportExportModal } from './components/ReportExportModal';
import { BirdProfileModal } from './components/BirdProfileModal';
import { AddBirdLovebirdGeneticsModal } from './components/AddBirdLovebirdGeneticsModal';

function MainAppContent() {
  const { birds, clutches, config } = useAviary();

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedPedigreeBirdId, setSelectedPedigreeBirdId] = useState<string>(birds[0]?.id || '');
  
  // Bird Profile Modal
  const [selectedBirdProfileId, setSelectedBirdProfileId] = useState<string | null>(null);
  const [isBirdProfileOpen, setIsBirdProfileOpen] = useState(false);

  // LovebirdGenetics Add Bird Modal
  const [isLovebirdGeneticsAddOpen, setIsLovebirdGeneticsAddOpen] = useState(false);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'user' | 'master'>('user');
  const [isAddPairOpen, setIsAddPairOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  const handleSelectBirdForPedigree = (birdId: string) => {
    setSelectedPedigreeBirdId(birdId);
  };

  const handleOpenBirdProfile = (birdId: string) => {
    setSelectedBirdProfileId(birdId);
    setIsBirdProfileOpen(true);
  };

  const handleOpenMasterAuth = () => {
    setAuthInitialMode('master');
    setIsAuthOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Printable Report View (Visible only during window.print()) */}
      <div className="hidden print:block p-8 bg-white text-black font-sans print-only">
        <div className="flex items-center justify-between pb-6 border-b-2 border-black">
          <div>
            <h1 className="text-2xl font-bold uppercase tracking-tight">{config.aviaryName}</h1>
            <div className="text-xs font-mono">Society Ring Prefix: {config.societyRingPrefix} · Master Breeder: {config.breederName}</div>
            <div className="text-xs text-gray-600">{config.location} · {config.contactEmail}</div>
          </div>
          <div className="text-right text-xs">
            <div>Report Date: {new Date().toLocaleDateString()}</div>
            <div className="font-mono text-[10px]">Auth Hash: ACL-CERT-MASTER-PRINT</div>
          </div>
        </div>

        <div className="my-6">
          <h2 className="text-sm font-bold uppercase tracking-wider mb-2">Flock Census Registry ({birds.length} Birds)</h2>
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-black font-mono">
                <th className="py-1">Ring No</th>
                <th className="py-1">Name</th>
                <th className="py-1">Sex</th>
                <th className="py-1">DNA Status</th>
                <th className="py-1">Status</th>
                <th className="py-1">Mutation</th>
                <th className="py-1">Sire × Dam</th>
                <th className="py-1">Hatch Date</th>
              </tr>
            </thead>
            <tbody>
              {birds.map(b => (
                <tr key={b.id} className="border-b border-gray-200">
                  <td className="py-1 font-mono">{b.ringNumber}</td>
                  <td className="py-1 font-semibold">{b.name}</td>
                  <td className="py-1">{b.sex}</td>
                  <td className="py-1">{b.dnaStatus}</td>
                  <td className="py-1">{b.status}</td>
                  <td className="py-1">{b.mutationDescription}</td>
                  <td className="py-1 font-mono text-[11px]">{b.fatherRing || '-'} × {b.motherRing || '-'}</td>
                  <td className="py-1 font-mono">{b.hatchDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="pt-8 border-t border-black flex justify-between items-center text-xs">
          <div>Official Aviary Record Certification</div>
          <div className="w-48 border-b border-black text-center pb-1 font-serif italic">
            {config.breederName}
          </div>
        </div>
      </div>

      {/* Screen Interface (hidden during print) */}
      <div className="no-print flex-1 flex flex-col">
        {/* Top Bar Header */}
        <Header
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenAuth={() => {
            setAuthInitialMode('user');
            setIsAuthOpen(true);
          }}
          onOpenAddBird={() => setIsLovebirdGeneticsAddOpen(true)}
          onOpenExport={() => setIsExportOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {currentTab === 'dashboard' && (
            <Dashboard
              onNavigateTab={setCurrentTab}
              onOpenAddBird={() => setIsLovebirdGeneticsAddOpen(true)}
              onOpenAddPair={() => {
                setCurrentTab('breeding');
                setIsAddPairOpen(true);
              }}
              onOpenExport={() => setIsExportOpen(true)}
              onSelectBirdForPedigree={handleSelectBirdForPedigree}
              onOpenBirdProfile={handleOpenBirdProfile}
            />
          )}

          {currentTab === 'flock' && (
            <FlockManager
              onSelectBirdForPedigree={handleSelectBirdForPedigree}
              onNavigateTab={setCurrentTab}
              isAddModalOpen={isLovebirdGeneticsAddOpen}
              setIsAddModalOpen={setIsLovebirdGeneticsAddOpen}
              onOpenBirdProfile={handleOpenBirdProfile}
            />
          )}

          {currentTab === 'breeding' && (
            <BreedingManager
              onNavigateTab={setCurrentTab}
              onSelectBirdForPedigree={handleSelectBirdForPedigree}
              isAddPairModalOpen={isAddPairOpen}
              setIsAddPairModalOpen={setIsAddPairOpen}
            />
          )}

          {currentTab === 'genetics' && (
            <GeneticsCalculator
              onNavigateTab={setCurrentTab}
              onFormPairWithGenetics={() => {
                setCurrentTab('breeding');
                setIsAddPairOpen(true);
              }}
            />
          )}

          {currentTab === 'pedigree' && (
            <PedigreeTree
              initialBirdId={selectedPedigreeBirdId}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'feeding' && <FeedingManager />}

          {currentTab === 'health' && <HealthManager />}
        </main>

        {/* Quiet Clean Footer */}
        <footer className="border-t border-slate-900 bg-slate-950 py-6 px-4 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="text-slate-400 font-medium">{config.aviaryName}</span>
              <span className="mx-2">·</span>
              <span>Prefix: {config.societyRingPrefix}</span>
              <span className="mx-2">·</span>
              <span>Offline-First Cloud Synced</span>
            </div>
            <div className="flex items-center gap-4 text-slate-500">
              <button onClick={() => setIsExportOpen(true)} className="hover:text-slate-300 cursor-pointer">
                PDF & CSV Export
              </button>
              <button onClick={handleOpenMasterAuth} className="hover:text-slate-300 cursor-pointer">
                Master Admin Mode
              </button>
              <button onClick={() => setIsSettingsOpen(true)} className="hover:text-slate-300 cursor-pointer">
                Settings & Custom Logo
              </button>
            </div>
          </div>
        </footer>
      </div>

      {/* Bird Profile Modal */}
      <BirdProfileModal
        birdId={selectedBirdProfileId}
        isOpen={isBirdProfileOpen}
        onClose={() => {
          setIsBirdProfileOpen(false);
          setSelectedBirdProfileId(null);
        }}
        onNavigateTab={setCurrentTab}
        onSelectBirdForPedigree={handleSelectBirdForPedigree}
      />

      {/* LovebirdGenetics Add Bird Modal */}
      <AddBirdLovebirdGeneticsModal
        isOpen={isLovebirdGeneticsAddOpen}
        onClose={() => setIsLovebirdGeneticsAddOpen(false)}
      />

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onOpenMasterAuth={handleOpenMasterAuth}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialMode={authInitialMode}
      />

      <ReportExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AviaryProvider>
      <MainAppContent />
    </AviaryProvider>
  );
}
