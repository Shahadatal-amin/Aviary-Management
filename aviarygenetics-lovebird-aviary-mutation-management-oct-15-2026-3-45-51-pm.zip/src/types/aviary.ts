/**
 * Aviary & Lovebird Genetics Management Types
 */

export type BirdSex = 'Cock' | 'Hen' | 'Unknown';

export type BirdStatus = 
  | 'Home Bred' 
  | 'Purchased' 
  | 'Loan' 
  | 'Sold' 
  | 'Breeding Pair' 
  | 'Quarantine' 
  | 'Deceased';

export type DnaStatus = 
  | 'DNA Certified Male' 
  | 'DNA Certified Female' 
  | 'Sex-Linked Confirmed' 
  | 'Breeding Proven' 
  | 'Pending / Unknown';

export type LovebirdSpecies = 
  | 'Agapornis roseicollis (Peach-faced)' 
  | 'Agapornis fischeri (Fischer\'s)' 
  | 'Agapornis personatus (Masked)' 
  | 'Agapornis lilianae (Nyasa)' 
  | 'Agapornis nigrigenis (Black-cheeked)'
  | 'Agapornis canus (Madagascar)'
  | 'Agapornis taranta (Abyssinian)'
  | 'Agapornis pullarius (Red-headed)'
  | 'Agapornis swindernianus (Black-collared)';

export interface BirdGenotype {
  baseColor: 'Green' | 'Blue 1' | 'Blue 2' | 'Parblue B1B2';
  darkFactors: 0 | 1 | 2; // 0 = Normal, 1 = Dark Green/Cobalt, 2 = Olive/Mauve
  violetFactors: 0 | 1 | 2; // 0 = None, 1 = Single Violet, 2 = Double Violet
  sexLinked: {
    ino: boolean; // Lutino / Albino
    cinnamon: boolean;
    opaline: boolean;
    pallid: boolean;
  };
  sexLinkedSplits?: {
    ino?: boolean;
    cinnamon?: boolean;
    opaline?: boolean;
    pallid?: boolean;
  };
  autosomalRecessive: {
    orangeFaced?: boolean;
    marbled?: boolean; // Australian Cinnamon
    dilute?: boolean;
    bronzeFallow?: boolean;
    paleFallow?: boolean;
    recessivePied?: boolean;
    slaty?: boolean;
  };
  autosomalRecessiveSplits?: {
    blue1?: boolean;
    blue2?: boolean;
    b1b2?: boolean;
    orangeFaced?: boolean;
    marbled?: boolean;
    dilute?: boolean;
    bronzeFallow?: boolean;
    paleFallow?: boolean;
    recessivePied?: boolean;
    slaty?: boolean;
  };
  dominantTraits: {
    dominantPied?: boolean;
    edgedDilute?: boolean;
    euwing?: boolean;
    mist?: boolean;
  };
}

export interface Bird {
  id: string;
  ringNumber: string; // Official band ID, e.g. AV-2025-014
  name: string;
  species: LovebirdSpecies;
  sex: BirdSex;
  dnaStatus: DnaStatus;
  status: BirdStatus;
  mutationDescription: string; // e.g. "D Green Opaline / Ino"
  genotype?: BirdGenotype;
  hatchDate: string; // YYYY-MM-DD
  cageNumber: string; // e.g. Flight 3, Cage B-12
  photoUrl?: string;
  fatherRing?: string; // Sire ring
  motherRing?: string; // Dam ring
  weightGrams?: number;
  breederName: string;
  sourceAviary?: string; // Aviary/facility name for purchased or loan birds
  loanTerms?: string; // Terms or duration if on breeding loan
  parentPairId?: string; // Linked parent pair ID for home-bred birds
  purchasePrice?: number;
  purchaseDate?: string;
  soldPrice?: number;
  soldDate?: string;
  soldTo?: string;
  notes?: string;
  createdAt: string;
}

export interface Egg {
  id: string;
  eggNumber: number;
  laidDate: string; // YYYY-MM-DD
  expectedHatchDate: string; // ~21-23 days after laid
  actualHatchDate?: string;
  candlingStatus: 'Pending' | 'Fertile' | 'Infertile' | 'Dead in Shell' | 'Broken';
  candlingDate?: string; // usually day 6-7
  bandingDate?: string; // day 8-10 after hatch
  bandingRingAssigned?: string;
  addedToFlockId?: string; // linked Bird ID if added
  notes?: string;
}

export interface Clutch {
  id: string;
  pairId: string;
  clutchNumber: number;
  startDate: string;
  nestBoxNumber: string;
  eggs: Egg[];
  status: 'In Progress' | 'Completed' | 'Abandoned';
  notes?: string;
}

export interface BreedingPair {
  id: string;
  pairName: string;
  cageNumber: string;
  cockBirdId: string; // Male bird ID
  henBirdId: string; // Female bird ID
  dateFormed: string;
  status: 'Active' | 'Resting' | 'Retired';
  totalClutches: number;
  totalChicksRaised: number;
  notes?: string;
}

export interface HealthRecord {
  id: string;
  birdRingNumber: string;
  date: string;
  recordType: 'Vaccination' | 'Deworming' | 'Weight Check' | 'Vet Visit' | 'Quarantine Check' | 'Medication' | 'General';
  title: string;
  description: string;
  veterinarian?: string;
  weightGrams?: number;
  nextDueDate?: string; // triggers automated reminder
  status: 'Completed' | 'Scheduled' | 'Overdue';
}

export interface FeedingSchedule {
  id: string;
  title: string;
  dietCategory: 'Base Seeds' | 'Germinated & Sprouts' | 'Eggfood & Softfood' | 'Fresh Greens & Veggies' | 'Calcium & Minerals' | 'Supplements & Vitamins';
  frequency: 'Daily' | 'Twice Daily' | '3 Times / Week' | 'Weekly' | 'Breeding Season Only';
  timeOfDay: 'Morning (07:30)' | 'Noon (12:00)' | 'Evening (17:00)' | 'All Day';
  targetGroup: 'Entire Aviary' | 'Breeding Flights' | 'Weaning Nursery' | 'Quarantine' | 'Resting Birds';
  instructions: string;
  active: boolean;
}

export interface FeedingLog {
  id: string;
  date: string; // YYYY-MM-DD
  scheduleId: string;
  completedAt: string;
  completedBy: string;
  notes?: string;
}

export interface AutomatedReminder {
  id: string;
  title: string;
  date: string;
  type: 'candling' | 'hatch' | 'banding' | 'health' | 'feeding' | 'weaning';
  severity: 'normal' | 'urgent' | 'info';
  relatedId?: string;
  details: string;
  dismissed: boolean;
}

export interface AviaryConfig {
  aviaryName: string;
  breederName: string;
  societyRingPrefix: string;
  logoUrl: string;
  contactEmail: string;
  contactPhone: string;
  location: string;
  masterPasswordHash: string; // Default master password
  enabledModules: {
    dashboard: boolean;
    flock: boolean;
    breeding: boolean;
    genetics: boolean;
    pedigree: boolean;
    feeding: boolean;
    health: boolean;
    registry: boolean;
    finance: boolean;
  };
  currencySymbol: string;
  lastCloudSyncTimestamp: string;
}

export type TransactionType = 
  | 'Bird Purchase' 
  | 'Bird Sale' 
  | 'Feed & Nutrition' 
  | 'Veterinary & Meds' 
  | 'Aviary Equipment' 
  | 'DNA Testing' 
  | 'Rings & Banding' 
  | 'Other Expense' 
  | 'Other Revenue';

export interface FinanceTransaction {
  id: string;
  type: TransactionType;
  category: 'Income' | 'Expense';
  title: string;
  amount: number;
  date: string; // YYYY-MM-DD
  birdId?: string;
  birdRingNumber?: string;
  partyName?: string; // Buyer, Seller, Breeder or Vendor
  aviaryName?: string; // Aviary associated with purchase/sale
  notes?: string;
  createdAt: string;
}

export interface UserSession {
  isAuthenticated: boolean;
  isMasterLoggedIn: boolean;
  userIdentifier: string; // Email or Mobile
  authMethod: 'biometric' | 'credentials' | 'pin';
  loginTime: string;
}

export interface GeneticOutcome {
  sex: 'Cock (Male)' | 'Hen (Female)' | 'Any';
  percentage: number;
  phenotypeName: string;
  genotypeNotation: string;
  colorHexPreview: string;
  secondaryColorHex?: string;
  splitGenes: string[];
}
