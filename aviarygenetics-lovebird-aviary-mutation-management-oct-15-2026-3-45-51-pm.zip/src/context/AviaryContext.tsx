import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { 
  Bird, 
  BreedingPair, 
  Clutch, 
  Egg, 
  FeedingSchedule, 
  FeedingLog, 
  HealthRecord, 
  AviaryConfig, 
  UserSession, 
  AutomatedReminder,
  FinanceTransaction 
} from '../types/aviary';
import { 
  INITIAL_BIRDS, 
  INITIAL_PAIRS, 
  INITIAL_CLUTCHES, 
  INITIAL_FEEDING_SCHEDULES, 
  INITIAL_HEALTH_RECORDS, 
  INITIAL_AVIARY_CONFIG,
  INITIAL_FINANCE_TRANSACTIONS 
} from '../data/initialData';

interface AviaryContextType {
  birds: Bird[];
  pairs: BreedingPair[];
  clutches: Clutch[];
  feedingSchedules: FeedingSchedule[];
  feedingLogs: FeedingLog[];
  healthRecords: HealthRecord[];
  config: AviaryConfig;
  session: UserSession;
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncTime: string;
  reminders: AutomatedReminder[];
  
  // Bird operations
  addBird: (bird: Omit<Bird, 'id' | 'createdAt'>) => Bird;
  updateBird: (id: string, updates: Partial<Bird>) => void;
  deleteBird: (id: string) => void;
  addHomeBredBirdFromPair: (
    pairId: string, 
    eggId?: string, 
    overrides?: Partial<Bird>
  ) => Bird | null;

  // Breeding pair operations
  addBreedingPair: (pair: Omit<BreedingPair, 'id' | 'totalClutches' | 'totalChicksRaised'>) => BreedingPair;
  updateBreedingPair: (id: string, updates: Partial<BreedingPair>) => void;
  deleteBreedingPair: (id: string) => void;

  // Clutch & Egg operations
  addClutch: (pairId: string, nestBox: string) => Clutch;
  addEggToClutch: (clutchId: string, eggDate?: string) => Egg | null;
  updateEgg: (clutchId: string, eggId: string, updates: Partial<Egg>) => void;
  deleteEgg: (clutchId: string, eggId: string) => void;

  // Health operations
  addHealthRecord: (record: Omit<HealthRecord, 'id'>) => HealthRecord;
  updateHealthRecord: (id: string, updates: Partial<HealthRecord>) => void;
  deleteHealthRecord: (id: string) => void;

  // Feeding operations
  addFeedingSchedule: (sched: Omit<FeedingSchedule, 'id'>) => FeedingSchedule;
  updateFeedingSchedule: (id: string, updates: Partial<FeedingSchedule>) => void;
  toggleFeedingSchedule: (id: string) => void;
  logFeedingCompletion: (scheduleId: string, notes?: string) => void;

  // Finance operations
  transactions: FinanceTransaction[];
  addTransaction: (tx: Omit<FinanceTransaction, 'id' | 'createdAt'>) => FinanceTransaction;
  updateTransaction: (id: string, updates: Partial<FinanceTransaction>) => void;
  deleteTransaction: (id: string) => void;

  // Configuration & Master login
  updateConfig: (updates: Partial<AviaryConfig>) => void;
  loginUser: (identifier: string, method: 'biometric' | 'credentials' | 'pin') => void;
  logoutUser: () => void;
  loginMaster: (password: string) => boolean;
  logoutMaster: () => void;

  // Sync & Backup
  syncCloudData: () => Promise<{ success: boolean; message: string }>;
  exportAviaryDataJson: () => string;
  importAviaryDataJson: (jsonStr: string) => boolean;
  dismissReminder: (id: string) => void;
  resetToDemoData: () => void;
}

const STORAGE_KEYS = {
  BIRDS: 'aviary_birds_v1',
  PAIRS: 'aviary_pairs_v1',
  CLUTCHES: 'aviary_clutches_v1',
  FEEDING_SCHEDS: 'aviary_feeding_scheds_v1',
  FEEDING_LOGS: 'aviary_feeding_logs_v1',
  HEALTH: 'aviary_health_v1',
  CONFIG: 'aviary_config_v1',
  SESSION: 'aviary_session_v1',
  DISMISSED_REMINDERS: 'aviary_dismissed_reminders_v1',
  TRANSACTIONS: 'aviary_transactions_v1',
};

const AviaryContext = createContext<AviaryContextType | undefined>(undefined);

export const AviaryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Safe load helper
  const loadStored = <T,>(key: string, fallback: T): T => {
    try {
      const data = localStorage.getItem(key);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    return fallback;
  };

  const [birds, setBirds] = useState<Bird[]>(() => loadStored(STORAGE_KEYS.BIRDS, INITIAL_BIRDS));
  const [pairs, setPairs] = useState<BreedingPair[]>(() => loadStored(STORAGE_KEYS.PAIRS, INITIAL_PAIRS));
  const [clutches, setClutches] = useState<Clutch[]>(() => loadStored(STORAGE_KEYS.CLUTCHES, INITIAL_CLUTCHES));
  const [feedingSchedules, setFeedingSchedules] = useState<FeedingSchedule[]>(() => 
    loadStored(STORAGE_KEYS.FEEDING_SCHEDS, INITIAL_FEEDING_SCHEDULES)
  );
  const [feedingLogs, setFeedingLogs] = useState<FeedingLog[]>(() => 
    loadStored(STORAGE_KEYS.FEEDING_LOGS, [])
  );
  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>(() => 
    loadStored(STORAGE_KEYS.HEALTH, INITIAL_HEALTH_RECORDS)
  );
  const [transactions, setTransactions] = useState<FinanceTransaction[]>(() => 
    loadStored(STORAGE_KEYS.TRANSACTIONS, INITIAL_FINANCE_TRANSACTIONS)
  );
  const [config, setConfig] = useState<AviaryConfig>(() => 
    loadStored(STORAGE_KEYS.CONFIG, INITIAL_AVIARY_CONFIG)
  );
  const [session, setSession] = useState<UserSession>(() => 
    loadStored(STORAGE_KEYS.SESSION, {
      isAuthenticated: true,
      isMasterLoggedIn: false,
      userIdentifier: 'breeder@auroracrest.com',
      authMethod: 'biometric',
      loginTime: new Date().toISOString(),
    })
  );
  const [dismissedReminders, setDismissedReminders] = useState<string[]>(() => 
    loadStored(STORAGE_KEYS.DISMISSED_REMINDERS, [])
  );

  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>(config.lastCloudSyncTimestamp || new Date().toISOString());

  // Listen to network status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BIRDS, JSON.stringify(birds));
  }, [birds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAIRS, JSON.stringify(pairs));
  }, [pairs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CLUTCHES, JSON.stringify(clutches));
  }, [clutches]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEEDING_SCHEDS, JSON.stringify(feedingSchedules));
  }, [feedingSchedules]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEEDING_LOGS, JSON.stringify(feedingLogs));
  }, [feedingLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HEALTH, JSON.stringify(healthRecords));
  }, [healthRecords]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DISMISSED_REMINDERS, JSON.stringify(dismissedReminders));
  }, [dismissedReminders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  // Compute Automated Reminders for Breeding Cycles and Health Checks
  const reminders = useMemo(() => {
    const list: AutomatedReminder[] = [];
    const today = new Date().toISOString().split('T')[0];

    // Check eggs in clutches
    clutches.forEach(c => {
      if (c.status === 'In Progress') {
        const pair = pairs.find(p => p.id === c.pairId);
        const pairName = pair ? pair.pairName : `Pair ${c.pairId}`;

        c.eggs.forEach(egg => {
          // Candling reminder
          if (egg.candlingStatus === 'Pending' && egg.candlingDate) {
            const diffDays = Math.ceil((new Date(egg.candlingDate).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
            if (diffDays <= 2 && diffDays >= -3) {
              list.push({
                id: `rem-candle-${egg.id}`,
                title: diffDays === 0 ? `Candling Due Today (Egg #${egg.eggNumber})` : `Candling in ${diffDays} day(s) (Egg #${egg.eggNumber})`,
                date: egg.candlingDate,
                type: 'candling',
                severity: diffDays <= 0 ? 'urgent' : 'normal',
                details: `${pairName} · Laid ${egg.laidDate} · Candling Day 6 check for fertile veins`,
                dismissed: dismissedReminders.includes(`rem-candle-${egg.id}`),
              });
            }
          }

          // Hatching reminder
          if (egg.candlingStatus === 'Fertile' && !egg.actualHatchDate) {
            const diffDays = Math.ceil((new Date(egg.expectedHatchDate).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
            if (diffDays <= 3 && diffDays >= -2) {
              list.push({
                id: `rem-hatch-${egg.id}`,
                title: diffDays === 0 ? `Hatch Expected Today! (Egg #${egg.eggNumber})` : `Hatch in ${diffDays} day(s) (Egg #${egg.eggNumber})`,
                date: egg.expectedHatchDate,
                type: 'hatch',
                severity: diffDays <= 0 ? 'urgent' : 'normal',
                details: `${pairName} · Expecting pip & hatch (Day 21-23)`,
                dismissed: dismissedReminders.includes(`rem-hatch-${egg.id}`),
              });
            }
          }

          // Banding reminder for hatched chicks
          if (egg.actualHatchDate && !egg.bandingRingAssigned && egg.bandingDate) {
            const diffDays = Math.ceil((new Date(egg.bandingDate).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
            if (diffDays <= 3 && diffDays >= -3) {
              list.push({
                id: `rem-band-${egg.id}`,
                title: diffDays === 0 ? `Closed Ring Banding Due Today! (Egg #${egg.eggNumber})` : `Banding Ring in ${diffDays} day(s)`,
                date: egg.bandingDate,
                type: 'banding',
                severity: 'urgent',
                details: `${pairName} · Chick hatched ${egg.actualHatchDate} · Ideal ring window: Day 8-10`,
                dismissed: dismissedReminders.includes(`rem-band-${egg.id}`),
              });
            }
          }
        });
      }
    });

    // Health records nextDueDate
    healthRecords.forEach(h => {
      if (h.nextDueDate && h.status !== 'Completed') {
        const diffDays = Math.ceil((new Date(h.nextDueDate).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays <= 5 && diffDays >= -5) {
          list.push({
            id: `rem-health-${h.id}`,
            title: diffDays === 0 ? `${h.recordType} Due Today!` : `${h.recordType} Due: ${h.title}`,
            date: h.nextDueDate,
            type: 'health',
            severity: diffDays <= 1 ? 'urgent' : 'normal',
            details: `Ring #${h.birdRingNumber} · ${h.description}`,
            dismissed: dismissedReminders.includes(`rem-health-${h.id}`),
          });
        }
      }
    });

    return list.filter(r => !r.dismissed);
  }, [clutches, pairs, healthRecords, dismissedReminders]);

  // Transaction operations
  const addTransaction = (txData: Omit<FinanceTransaction, 'id' | 'createdAt'>): FinanceTransaction => {
    const newTx: FinanceTransaction = {
      ...txData,
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
    };
    setTransactions(prev => [newTx, ...prev]);
    return newTx;
  };

  const updateTransaction = (id: string, updates: Partial<FinanceTransaction>) => {
    setTransactions(prev => prev.map(t => (t.id === id ? { ...t, ...updates } : t)));
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  // Operations
  const addBird = (birdData: Omit<Bird, 'id' | 'createdAt'>): Bird => {
    const newBird: Bird = {
      ...birdData,
      id: `bird-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
    };
    setBirds(prev => [newBird, ...prev]);

    // Automatically record finance transaction if purchased or sold with amount
    if (newBird.status === 'Purchased' && newBird.purchasePrice && newBird.purchasePrice > 0) {
      addTransaction({
        type: 'Bird Purchase',
        category: 'Expense',
        title: `Acquisition: ${newBird.name} (${newBird.ringNumber})`,
        amount: newBird.purchasePrice,
        date: newBird.purchaseDate || newBird.createdAt.split('T')[0],
        birdId: newBird.id,
        birdRingNumber: newBird.ringNumber,
        partyName: newBird.breederName,
        aviaryName: newBird.sourceAviary,
        notes: `Acquisition recorded for ${newBird.name}`,
      });
    } else if (newBird.status === 'Sold' && newBird.soldPrice && newBird.soldPrice > 0) {
      addTransaction({
        type: 'Bird Sale',
        category: 'Income',
        title: `Sale: ${newBird.name} (${newBird.ringNumber})`,
        amount: newBird.soldPrice,
        date: newBird.soldDate || newBird.createdAt.split('T')[0],
        birdId: newBird.id,
        birdRingNumber: newBird.ringNumber,
        partyName: newBird.soldTo,
        notes: `Sale recorded for ${newBird.name}`,
      });
    }

    return newBird;
  };

  const updateBird = (id: string, updates: Partial<Bird>) => {
    setBirds(prev => prev.map(b => (b.id === id ? { ...b, ...updates } : b)));

    // If status changed to Purchased or Sold, or price updated, adjust finance
    const currentBird = birds.find(b => b.id === id);
    if (!currentBird) return;
    const effectiveStatus = updates.status || currentBird.status;

    if (effectiveStatus === 'Purchased' && (updates.purchasePrice || currentBird.purchasePrice)) {
      const price = updates.purchasePrice !== undefined ? updates.purchasePrice : currentBird.purchasePrice;
      if (price && price > 0) {
        const existingTx = transactions.find(t => t.birdId === id && t.type === 'Bird Purchase');
        if (existingTx) {
          updateTransaction(existingTx.id, {
            amount: price,
            partyName: updates.breederName || currentBird.breederName,
            aviaryName: updates.sourceAviary || currentBird.sourceAviary,
          });
        } else {
          addTransaction({
            type: 'Bird Purchase',
            category: 'Expense',
            title: `Acquisition: ${updates.name || currentBird.name} (${currentBird.ringNumber})`,
            amount: price,
            date: updates.purchaseDate || currentBird.purchaseDate || new Date().toISOString().split('T')[0],
            birdId: id,
            birdRingNumber: currentBird.ringNumber,
            partyName: updates.breederName || currentBird.breederName,
            aviaryName: updates.sourceAviary || currentBird.sourceAviary,
            notes: `Updated acquisition price for ${currentBird.ringNumber}`,
          });
        }
      }
    } else if (effectiveStatus === 'Sold' && (updates.soldPrice || currentBird.soldPrice)) {
      const price = updates.soldPrice !== undefined ? updates.soldPrice : currentBird.soldPrice;
      if (price && price > 0) {
        const existingTx = transactions.find(t => t.birdId === id && t.type === 'Bird Sale');
        if (existingTx) {
          updateTransaction(existingTx.id, {
            amount: price,
            partyName: updates.soldTo || currentBird.soldTo,
          });
        } else {
          addTransaction({
            type: 'Bird Sale',
            category: 'Income',
            title: `Sale: ${updates.name || currentBird.name} (${currentBird.ringNumber})`,
            amount: price,
            date: updates.soldDate || currentBird.soldDate || new Date().toISOString().split('T')[0],
            birdId: id,
            birdRingNumber: currentBird.ringNumber,
            partyName: updates.soldTo || currentBird.soldTo,
            notes: `Updated sale revenue for ${currentBird.ringNumber}`,
          });
        }
      }
    }
  };

  const deleteBird = (id: string) => {
    setBirds(prev => prev.filter(b => b.id !== id));
  };

  // Add Home Bred Bird directly under pair / egg
  const addHomeBredBirdFromPair = (
    pairId: string, 
    eggId?: string, 
    overrides?: Partial<Bird>
  ): Bird | null => {
    const pair = pairs.find(p => p.id === pairId);
    if (!pair) return null;

    const cock = birds.find(b => b.id === pair.cockBirdId);
    const hen = birds.find(b => b.id === pair.henBirdId);

    // Generate consecutive band number
    const year = new Date().getFullYear();
    const count = birds.filter(b => b.ringNumber.includes(`${year}`)).length + 1;
    const autoRingNumber = `${config.societyRingPrefix}-${String(count).padStart(3, '0')}`;

    let eggData: Egg | undefined;
    if (eggId) {
      for (const c of clutches) {
        const found = c.eggs.find(e => e.id === eggId);
        if (found) {
          eggData = found;
          break;
        }
      }
    }

    const hatchDate = eggData?.actualHatchDate || eggData?.expectedHatchDate || new Date().toISOString().split('T')[0];

    const newBird: Bird = {
      id: `bird-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      ringNumber: eggData?.bandingRingAssigned || autoRingNumber,
      name: `Offspring of ${pair.pairName}`,
      species: cock?.species || 'Agapornis roseicollis (Peach-faced)',
      sex: 'Unknown',
      dnaStatus: 'Pending / Unknown',
      status: 'Home Bred',
      mutationDescription: 'Pending first moult inspection',
      hatchDate,
      cageNumber: pair.cageNumber,
      photoUrl: cock?.photoUrl || '/src/assets/images/lovebird_green_peachfaced_1792053490772.jpg',
      fatherRing: cock?.ringNumber || 'Unknown Sire',
      motherRing: hen?.ringNumber || 'Unknown Dam',
      breederName: config.aviaryName,
      weightGrams: 45.0,
      notes: `Directly registered home-bred offspring from ${pair.pairName}${eggData ? ` (Egg #${eggData.eggNumber})` : ''}.`,
      createdAt: new Date().toISOString(),
      ...overrides,
    };

    setBirds(prev => [newBird, ...prev]);

    // If egg linked, update egg
    if (eggId) {
      setClutches(prev => prev.map(c => ({
        ...c,
        eggs: c.eggs.map(e => e.id === eggId ? { ...e, addedToFlockId: newBird.id, bandingRingAssigned: newBird.ringNumber } : e),
      })));
    }

    // Increment pair chicks count
    setPairs(prev => prev.map(p => p.id === pairId ? { ...p, totalChicksRaised: p.totalChicksRaised + 1 } : p));

    return newBird;
  };

  const addBreedingPair = (pairData: Omit<BreedingPair, 'id' | 'totalClutches' | 'totalChicksRaised'>): BreedingPair => {
    const newPair: BreedingPair = {
      ...pairData,
      id: `pair-${Date.now()}`,
      totalClutches: 0,
      totalChicksRaised: 0,
    };
    setPairs(prev => [newPair, ...prev]);

    // Update the birds status to 'Breeding Pair'
    setBirds(prev => prev.map(b => {
      if (b.id === pairData.cockBirdId || b.id === pairData.henBirdId) {
        return { ...b, status: 'Breeding Pair', cageNumber: pairData.cageNumber };
      }
      return b;
    }));

    return newPair;
  };

  const updateBreedingPair = (id: string, updates: Partial<BreedingPair>) => {
    setPairs(prev => prev.map(p => (p.id === id ? { ...p, ...updates } : p)));
  };

  const deleteBreedingPair = (id: string) => {
    setPairs(prev => prev.filter(p => p.id !== id));
  };

  const addClutch = (pairId: string, nestBox: string): Clutch => {
    const existing = clutches.filter(c => c.pairId === pairId);
    const newClutch: Clutch = {
      id: `clutch-${Date.now()}`,
      pairId,
      clutchNumber: existing.length + 1,
      startDate: new Date().toISOString().split('T')[0],
      nestBoxNumber: nestBox,
      eggs: [],
      status: 'In Progress',
    };
    setClutches(prev => [newClutch, ...prev]);
    setPairs(prev => prev.map(p => p.id === pairId ? { ...p, totalClutches: p.totalClutches + 1 } : p));
    return newClutch;
  };

  const addEggToClutch = (clutchId: string, eggDate?: string): Egg | null => {
    const laid = eggDate || new Date().toISOString().split('T')[0];
    const laidDateObj = new Date(laid);
    
    // Candling Day 6
    const candleObj = new Date(laidDateObj);
    candleObj.setDate(candleObj.getDate() + 6);
    
    // Expected Hatch Day 22
    const hatchObj = new Date(laidDateObj);
    hatchObj.setDate(hatchObj.getDate() + 22);

    // Banding Day 31 (9 days after hatch)
    const bandObj = new Date(laidDateObj);
    bandObj.setDate(bandObj.getDate() + 31);

    const targetClutch = clutches.find(c => c.id === clutchId);
    if (!targetClutch) return null;

    const newEgg: Egg = {
      id: `egg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      eggNumber: targetClutch.eggs.length + 1,
      laidDate: laid,
      candlingDate: candleObj.toISOString().split('T')[0],
      expectedHatchDate: hatchObj.toISOString().split('T')[0],
      bandingDate: bandObj.toISOString().split('T')[0],
      candlingStatus: 'Pending',
    };

    setClutches(prev => prev.map(c => {
      if (c.id === clutchId) {
        return { ...c, eggs: [...c.eggs, newEgg] };
      }
      return c;
    }));

    return newEgg;
  };

  const updateEgg = (clutchId: string, eggId: string, updates: Partial<Egg>) => {
    setClutches(prev => prev.map(c => {
      if (c.id === clutchId) {
        return {
          ...c,
          eggs: c.eggs.map(e => e.id === eggId ? { ...e, ...updates } : e),
        };
      }
      return c;
    }));
  };

  const deleteEgg = (clutchId: string, eggId: string) => {
    setClutches(prev => prev.map(c => {
      if (c.id === clutchId) {
        return {
          ...c,
          eggs: c.eggs.filter(e => e.id !== eggId),
        };
      }
      return c;
    }));
  };

  const addHealthRecord = (record: Omit<HealthRecord, 'id'>): HealthRecord => {
    const newRecord: HealthRecord = {
      ...record,
      id: `health-${Date.now()}`,
    };
    setHealthRecords(prev => [newRecord, ...prev]);

    // If weight updated, also update bird weight
    if (record.weightGrams) {
      const bird = birds.find(b => b.ringNumber === record.birdRingNumber);
      if (bird) {
        updateBird(bird.id, { weightGrams: record.weightGrams });
      }
    }

    return newRecord;
  };

  const updateHealthRecord = (id: string, updates: Partial<HealthRecord>) => {
    setHealthRecords(prev => prev.map(h => (h.id === id ? { ...h, ...updates } : h)));
  };

  const deleteHealthRecord = (id: string) => {
    setHealthRecords(prev => prev.filter(h => h.id !== id));
  };

  const addFeedingSchedule = (sched: Omit<FeedingSchedule, 'id'>): FeedingSchedule => {
    const newSched: FeedingSchedule = {
      ...sched,
      id: `feed-${Date.now()}`,
    };
    setFeedingSchedules(prev => [...prev, newSched]);
    return newSched;
  };

  const updateFeedingSchedule = (id: string, updates: Partial<FeedingSchedule>) => {
    setFeedingSchedules(prev => prev.map(s => (s.id === id ? { ...s, ...updates } : s)));
  };

  const toggleFeedingSchedule = (id: string) => {
    setFeedingSchedules(prev => prev.map(s => (s.id === id ? { ...s, active: !s.active } : s)));
  };

  const logFeedingCompletion = (scheduleId: string, notes?: string) => {
    const today = new Date().toISOString().split('T')[0];
    const newLog: FeedingLog = {
      id: `log-${Date.now()}`,
      date: today,
      scheduleId,
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      completedBy: session.userIdentifier || config.breederName,
      notes,
    };
    setFeedingLogs(prev => [newLog, ...prev]);
  };

  const updateConfig = (updates: Partial<AviaryConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }));
  };

  const loginUser = (identifier: string, method: 'biometric' | 'credentials' | 'pin') => {
    setSession({
      isAuthenticated: true,
      isMasterLoggedIn: false,
      userIdentifier: identifier,
      authMethod: method,
      loginTime: new Date().toISOString(),
    });
  };

  const logoutUser = () => {
    setSession({
      isAuthenticated: false,
      isMasterLoggedIn: false,
      userIdentifier: '',
      authMethod: 'credentials',
      loginTime: '',
    });
  };

  const loginMaster = (password: string): boolean => {
    if (password === config.masterPasswordHash || password === 'master123') {
      setSession(prev => ({ ...prev, isMasterLoggedIn: true }));
      return true;
    }
    return false;
  };

  const logoutMaster = () => {
    setSession(prev => ({ ...prev, isMasterLoggedIn: false }));
  };

  const syncCloudData = async (): Promise<{ success: boolean; message: string }> => {
    setIsSyncing(true);
    // Simulate real cloud sync with latency and payload packaging
    await new Promise(r => setTimeout(r, 1100));
    const now = new Date().toISOString();
    setLastSyncTime(now);
    setConfig(prev => ({ ...prev, lastCloudSyncTimestamp: now }));
    setIsSyncing(false);
    return {
      success: true,
      message: `Flock & lineage database synced with cloud storage. ${birds.length} birds, ${clutches.length} clutches encrypted and backed up.`,
    };
  };

  const exportAviaryDataJson = (): string => {
    const bundle = {
      version: '1.0',
      exportDate: new Date().toISOString(),
      config,
      birds,
      pairs,
      clutches,
      feedingSchedules,
      feedingLogs,
      healthRecords,
      transactions,
    };
    return JSON.stringify(bundle, null, 2);
  };

  const importAviaryDataJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.birds && Array.isArray(parsed.birds)) setBirds(parsed.birds);
      if (parsed.pairs && Array.isArray(parsed.pairs)) setPairs(parsed.pairs);
      if (parsed.clutches && Array.isArray(parsed.clutches)) setClutches(parsed.clutches);
      if (parsed.feedingSchedules && Array.isArray(parsed.feedingSchedules)) setFeedingSchedules(parsed.feedingSchedules);
      if (parsed.healthRecords && Array.isArray(parsed.healthRecords)) setHealthRecords(parsed.healthRecords);
      if (parsed.transactions && Array.isArray(parsed.transactions)) setTransactions(parsed.transactions);
      if (parsed.config) setConfig(prev => ({ ...prev, ...parsed.config }));
      return true;
    } catch {
      return false;
    }
  };

  const dismissReminder = (id: string) => {
    setDismissedReminders(prev => [...prev, id]);
  };

  const resetToDemoData = () => {
    setBirds(INITIAL_BIRDS);
    setPairs(INITIAL_PAIRS);
    setClutches(INITIAL_CLUTCHES);
    setFeedingSchedules(INITIAL_FEEDING_SCHEDULES);
    setHealthRecords(INITIAL_HEALTH_RECORDS);
    setTransactions(INITIAL_FINANCE_TRANSACTIONS);
    setConfig(INITIAL_AVIARY_CONFIG);
    setDismissedReminders([]);
  };

  return (
    <AviaryContext.Provider
      value={{
        birds,
        pairs,
        clutches,
        feedingSchedules,
        feedingLogs,
        healthRecords,
        transactions,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        config,
        session,
        isOnline,
        isSyncing,
        lastSyncTime,
        reminders,
        addBird,
        updateBird,
        deleteBird,
        addHomeBredBirdFromPair,
        addBreedingPair,
        updateBreedingPair,
        deleteBreedingPair,
        addClutch,
        addEggToClutch,
        updateEgg,
        deleteEgg,
        addHealthRecord,
        updateHealthRecord,
        deleteHealthRecord,
        addFeedingSchedule,
        updateFeedingSchedule,
        toggleFeedingSchedule,
        logFeedingCompletion,
        updateConfig,
        loginUser,
        logoutUser,
        loginMaster,
        logoutMaster,
        syncCloudData,
        exportAviaryDataJson,
        importAviaryDataJson,
        dismissReminder,
        resetToDemoData,
      }}
    >
      {children}
    </AviaryContext.Provider>
  );
};

export const useAviary = () => {
  const context = useContext(AviaryContext);
  if (!context) throw new Error('useAviary must be used within an AviaryProvider');
  return context;
};
